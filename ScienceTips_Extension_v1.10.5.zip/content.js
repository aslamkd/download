(async () => {
  if (window.__stInspectorLoaded || document.getElementById('st-inspector-panel')) return;
  window.__stInspectorLoaded = true;
  const state = { minimized:false, classes:new Set(), originalDisplay:new WeakMap(), expanded:new Set(), search:'' };
  const panel = document.createElement('section');
  panel.id = 'st-inspector-panel';
  panel.setAttribute('aria-label', 'ScienceTips HTML Inspector');
  panel.innerHTML = `
    <header class="st-head"><div class="st-head-brand"><strong>HTML Inspector</strong><span id="st-head-filename" title="Current output file name">—.html</span></div><div class="st-head-tools"><button id="st-head-previous" class="st-head-icon" type="button" title="Previous number" aria-label="Previous number" disabled>‹</button><button id="st-head-next" class="st-head-icon" type="button" title="Next number" aria-label="Next number" disabled>›</button><button id="st-head-download" class="st-head-icon" type="button" title="Download current HTML" aria-label="Download current HTML">⇩</button><button id="st-min" title="Minimize" aria-label="Minimize">−</button><button id="st-close" title="Close" aria-label="Close">×</button></div></header>
    <div id="st-body">
      <nav class="st-tabs"><button data-tab="scripts" class="active">External JS</button><button data-tab="classes">Classes / HTML</button></nav>
      <section class="st-section" id="st-scripts"><p class="st-help">External script URLs found on this page. Select scripts to block them before the next reload.</p><div class="st-actions st-script-actions"><button id="st-script-all" type="button">Select all</button><button id="st-script-none" type="button">Deselect all</button></div><div id="st-script-list"></div><button id="st-reload" class="st-primary">Reload page with selected scripts blocked</button></section>
      <section class="st-section st-hidden" id="st-classes"><p class="st-help">Class frequency is shown beside each name. Expand a parent to see child classes repeated inside it. The preview uses the page's CSS; copied output contains HTML only.</p><input id="st-search" type="search" placeholder="Search classes…"><div class="st-actions"><button id="st-all">Select all</button><button id="st-none">Clear all</button><button id="st-reset">Reset visibility</button></div><div id="st-class-list"></div><div class="st-copybar"><span id="st-count"></span><button id="st-copy" class="st-primary">Copy selected HTML</button></div><div class="st-preview-tabs"><button id="st-show-preview" class="active">HTML Preview</button><button id="st-show-source">HTML Source</button><button id="st-show-css">CSS Section</button></div><div class="st-export-options"><strong>Output options</strong><label><input id="st-convert-align" type="checkbox" checked> Convert align/align* to one array display block</label><label><input type="radio" name="st-copy-mode" value="html" checked> Copy HTML only</label><label><input type="radio" name="st-copy-mode" value="both"> Copy CSS + HTML</label><label><input id="st-copy-mathjax" type="checkbox"> Include MathJax setup in copied code</label><hr><label><input id="st-download-css" type="checkbox" checked> Include CSS in downloaded HTML</label><label><input id="st-download-mathjax" type="checkbox" checked> Include MathJax 2.7.2 in downloaded HTML</label><label class="st-filename-label">File name <input id="st-filename" type="text" spellcheck="false" autocomplete="off" placeholder="newname"></label><label class="st-filename-label">Manual file name prefix (optional) <input id="st-prefix" type="text" spellcheck="false" autocomplete="off" placeholder="demo_"></label><div class="st-url-prefix-box"><div class="st-url-prefix-heading">Auto prefix from URL (wrap the required part in *)</div><div class="st-url-prefix-row"><input id="st-url-pattern" type="text" spellcheck="false" autocomplete="off" aria-label="URL pattern" placeholder="https://example.com/*2026*/english/"><input id="st-url-separator" type="text" spellcheck="false" autocomplete="off" aria-label="Separator after extracted URL text" placeholder="_" value="_" title="Text to add after the extracted URL part"></div><div class="st-url-prefix-actions"><button id="st-url-current" type="button">Use current URL</button><button id="st-url-apply" type="button" class="st-primary">Apply</button></div><div class="st-url-numeric-nav"><span id="st-url-current-number" class="st-url-current-number">Number: —</span><button id="st-url-previous" type="button" disabled>‹ Previous</button><button id="st-url-next" type="button" disabled>Next ›</button></div><div id="st-url-prefix-preview" class="st-url-prefix-preview">Generated prefix: —</div></div><div id="st-filename-preview" class="st-filename-preview">Output file: —</div><label class="st-code-label">Extra code inside &lt;head&gt; <textarea id="st-head-extra" rows="3" spellcheck="false" placeholder="Optional script/link tags"></textarea></label><label class="st-code-label">Extra code before &lt;/body&gt; <textarea id="st-body-extra" rows="4" spellcheck="false"></textarea></label><button id="st-download" class="st-primary">Download HTML file</button></div><p class="st-help">Options are applied when copying or downloading. MathJax 2.7.2 is loaded immediately (not on scroll). MathJax rendering requires internet access.</p><iframe id="st-preview" title="HTML preview" sandbox="allow-scripts allow-same-origin"></iframe><textarea id="st-output" placeholder="HTML source will appear here…" spellcheck="false"></textarea><textarea id="st-css-output" class="st-hidden" placeholder="Relevant CSS (minified) will appear here…" spellcheck="false"></textarea></section>
      <footer id="st-status" aria-live="polite">Ready</footer>
    </div>`;
  // Mount inside <body> so the inspector, its textareas, and preview live in the
  // normal document tree. Fall back temporarily to <html> only until <body> exists.
  const mountPanel = () => {
    const target = document.body || document.documentElement;
    if (!target) {
      document.addEventListener('DOMContentLoaded', mountPanel, { once: true });
      return false;
    }
    if (!panel.isConnected || panel.parentElement !== target) target.appendChild(panel);
    panel.style.setProperty('display', 'flex', 'important');
    panel.classList.remove('st-panel-hidden');
    return true;
  };
  mountPanel();
  // Clicking the extension toolbar icon opens its popup; the popup sends these
  // messages so users can show/hide the inspector on the current ScienceTips page.
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === 'ST_INSPECTOR_SHOW') {
      mountPanel();
      sendResponse({ ok: true, visible: true });
    } else if (message?.type === 'ST_INSPECTOR_TOGGLE') {
      if (!panel.isConnected) {
        mountPanel();
        sendResponse({ ok: true, visible: true });
      } else {
        const hidden = panel.style.display === 'none' || panel.classList.contains('st-panel-hidden');
        if (hidden) mountPanel();
        else { panel.style.display = 'none'; panel.classList.add('st-panel-hidden'); }
        sendResponse({ ok: true, visible: hidden });
      }
    }
    return true;
  });
  const $ = s => panel.querySelector(s);
  const status = msg => { $('#st-status').textContent = msg; };
  const allElements = [...document.querySelectorAll('body *')].filter(el => el !== panel && !panel.contains(el) && !el.closest('#st-inspector-panel'));
  const classNames = [...new Set(allElements.flatMap(el => [...el.classList]).filter(Boolean))];
  const frequency = new Map(classNames.map(c => [c, allElements.filter(el => el.classList.contains(c)).length]));
  // Store class choices by origin, not by pathname, so the same choices follow
  // the user between year-specific pages such as /2026/english/ and /2020/english/.
  const preferenceKey = 'stClassChoices:' + location.origin;
  const legacyPreferenceKey = 'stClasses:' + location.origin + location.pathname;
  const [savedPreferences, exportSettingsResult] = await Promise.all([
    chrome.storage.local.get(null),
    chrome.storage.local.get('stExportSettings:v1')
  ]);
  const savedChoices = savedPreferences[preferenceKey];
  const legacyClassKeys = Object.keys(savedPreferences).filter(key => key.startsWith('stClasses:' + location.origin));
  const exportSettingsKey = 'stExportSettings:v1';
  const DEFAULT_BODY_EXTRA = '<script src="https://cdn.jsdelivr.net/gh/aslamkd/MadhyamikGanitprabha@main/koshe-dekhi-tools.js" charset="utf-8"></script>';
  const exportSettings = exportSettingsResult[exportSettingsKey] || { prefix: '', filename: '', headExtra: '', bodyExtra: DEFAULT_BODY_EXTRA, urlPattern: location.href, urlSeparator: '_' };
  if (typeof exportSettings.bodyExtra !== 'string') exportSettings.bodyExtra = DEFAULT_BODY_EXTRA;
  if (typeof exportSettings.urlPattern !== 'string') exportSettings.urlPattern = location.href;
  if (typeof exportSettings.urlSeparator !== 'string') exportSettings.urlSeparator = '_';

  // Keep the user's starred dynamic position(s) as a reusable URL template.
  // First try an exact structural match. If other URL parts changed too, fall
  // back to the same path-segment position(s) on the same site.
  function syncPatternWithCurrentUrl(pattern, currentUrl) {
    // Always seed the box with the actual page URL. If a starred template was
    // saved earlier, the matching/fallback logic below carries its starred
    // position(s) onto this URL; without a saved marker there is no preference
    // to infer, so show the current URL unmarked for the user to mark once.
    if (typeof pattern !== 'string' || !pattern.includes('*')) return currentUrl;
    const chunks = pattern.split('*');
    if (chunks.length < 3 || chunks.length % 2 === 0) return pattern;
    const escaped = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    let source = '^';
    for (let i = 0; i < chunks.length; i++) {
      source += i % 2 === 0 ? escaped(chunks[i]) : '([^/?#&]+)';
    }
    source += '$';
    try {
      const match = currentUrl.match(new RegExp(source));
      if (match) {
        let updated = chunks[0];
        for (let i = 1; i < chunks.length; i += 2) updated += '*' + (match[(i + 1) / 2] || chunks[i]) + '*' + chunks[i + 1];
        return updated;
      }
    } catch { /* Try path-position fallback below. */ }

    // Fallback: preserve the marked path segment index, e.g. /.../*2026*/english/
    // becomes /.../*2020*/english/ even if another unmarked URL segment changed.
    try {
      const oldUrl = new URL(pattern.replace(/\*([^*]+)\*/g, '$1'));
      const newUrl = new URL(currentUrl);
      if (oldUrl.origin !== newUrl.origin) return pattern;
      const oldParts = oldUrl.pathname.split('/');
      const newParts = newUrl.pathname.split('/');
      if (oldParts.length !== newParts.length) return pattern;
      const marked = [...pattern.matchAll(/\*([^*]+)\*/g)];
      if (!marked.length) return pattern;
      let updatedUrl = currentUrl;
      // Only path-contained markers are remapped by segment index. Process from
      // right to left so replacing a marker cannot shift later string offsets.
      const replacements = [];
      for (const marker of marked) {
        const before = pattern.slice(0, marker.index);
        const prefixUrl = new URL(before.replace(/\*([^*]+)\*/g, '$1') + marker[1] + pattern.slice(marker.index + marker[0].length).replace(/\*([^*]+)\*/g, '$1'));
        const oldPathBefore = before.split(oldUrl.origin)[1] || before;
        const segmentIndex = oldParts.findIndex((part, idx) => {
          const segmentStart = oldParts.slice(0, idx).join('/').length + (idx ? 1 : 0);
          return marker.index >= pattern.indexOf(oldUrl.pathname) + segmentStart && marker.index <= pattern.indexOf(oldUrl.pathname) + segmentStart + part.length;
        });
        if (segmentIndex < 0 || !newParts[segmentIndex]) continue;
        const pathStart = updatedUrl.indexOf(newUrl.pathname);
        const targetPart = newParts[segmentIndex];
        const targetStart = newUrl.pathname.split('/').slice(0, segmentIndex).join('/').length + (segmentIndex ? 1 : 0);
        replacements.push({ start: pathStart + targetStart, end: pathStart + targetStart + targetPart.length, value: targetPart });
      }
      replacements.sort((a, b) => b.start - a.start).forEach(r => { updatedUrl = updatedUrl.slice(0, r.start) + '*' + r.value + '*' + updatedUrl.slice(r.end); });
      return replacements.length ? updatedUrl : pattern;
    } catch { return pattern; }
  }
  const syncedPattern = syncPatternWithCurrentUrl(exportSettings.urlPattern, location.href);
  if (syncedPattern !== exportSettings.urlPattern) exportSettings.urlPattern = syncedPattern;

  // Migrate the previous pathname-specific list once, then preserve a boolean
  // per class name. Known unchecked classes stay unchecked on every new page.
  let classChoices = savedChoices && typeof savedChoices === 'object' && !Array.isArray(savedChoices) ? { ...savedChoices } : null;
  if (!classChoices) {
    classChoices = {};
    if (legacyClassKeys.length) {
      // Older versions stored only selected class names per pathname. Union
      // them across visited pages so any previously selected class is retained.
      const previouslySelected = new Set(legacyClassKeys.flatMap(key => Array.isArray(savedPreferences[key]) ? savedPreferences[key] : []));
      classNames.forEach(c => { classChoices[c] = previouslySelected.has(c); });
    } else {
      // First run: preserve the old default of selecting all classes.
      classNames.forEach(c => { classChoices[c] = true; });
    }
    await chrome.storage.local.set({ [preferenceKey]: classChoices });
  }
  classNames.forEach(c => {
    // Previously known choices always win. New classes default to unchecked.
    if (Object.prototype.hasOwnProperty.call(classChoices, c) && classChoices[c]) state.classes.add(c);
  });
  const saveClassPreferences = () => {
    const updated = { ...classChoices };
    classNames.forEach(c => { updated[c] = state.classes.has(c); });
    classChoices = updated;
    chrome.storage.local.set({ [preferenceKey]: updated });
    updateFilenamePreview();
  };
  const blockedResult = await chrome.runtime.sendMessage({ type: 'GET_BLOCKED_URLS' }).catch(() => ({ urls: [] }));
  const blockedUrls = new Set(blockedResult?.urls || []);
  const scriptUrls = [...new Set([
    ...[...document.scripts].map(s => s.src).filter(src => { try { return src && new URL(src).origin !== location.origin; } catch { return false; } }),
    ...blockedUrls
  ])].sort();
  const scriptList = $('#st-script-list');
  if (!scriptUrls.length) scriptList.innerHTML = '<p class="st-empty">No external script URLs found in the live DOM and no saved block rules.</p>';
  scriptUrls.forEach(url => {
    const row = document.createElement('label'); row.className = 'st-script-row';
    const cb = document.createElement('input'); cb.type='checkbox'; cb.dataset.url=url; cb.checked=blockedUrls.has(url);
    const details = document.createElement('span'); details.className='st-url'; details.textContent=url; details.title=url;
    const copy = document.createElement('button'); copy.type='button'; copy.textContent='Copy link'; copy.className='st-small';
    copy.addEventListener('click', async e => { e.preventDefault(); try { await navigator.clipboard.writeText(url); status('Script URL copied'); } catch { status('Clipboard permission unavailable'); } });
    cb.addEventListener('change', async () => {
      const res = await chrome.runtime.sendMessage({type:'TOGGLE_BLOCK', url, block:cb.checked});
      if (!res?.ok) { cb.checked=!cb.checked; status('Could not update block rule: ' + (res?.error || 'unknown error')); }
      else status(cb.checked ? 'Block saved; reload to prevent the script loading' : 'Block removed; reload to allow the script');
    });
    row.append(cb, details, copy); scriptList.appendChild(row);
  });
  async function setAllScriptBlocks(shouldBlock) {
    const checkboxes = [...scriptList.querySelectorAll('input[type="checkbox"][data-url]')];
    const button = shouldBlock ? $('#st-script-all') : $('#st-script-none');
    button.disabled = true;
    let changed = 0;
    for (const cb of checkboxes) {
      if (cb.checked === shouldBlock) continue;
      const res = await chrome.runtime.sendMessage({ type: 'TOGGLE_BLOCK', url: cb.dataset.url, block: shouldBlock }).catch(() => null);
      if (res?.ok) { cb.checked = shouldBlock; changed++; }
    }
    button.disabled = false;
    status(`${shouldBlock ? 'Selected and blocked' : 'Deselected and unblocked'} ${changed} script URL(s). Reload to apply.`);
  }
  $('#st-script-all').addEventListener('click', () => setAllScriptBlocks(true));
  $('#st-script-none').addEventListener('click', () => setAllScriptBlocks(false));

  // Associate each class with its most common nearest ancestor class when that relationship repeats.
  const parentVotes = new Map(classNames.map(c => [c, new Map()]));
  allElements.forEach(el => {
    if (!el.classList.length) return;
    let ancestor = el.parentElement;
    while (ancestor && !panel.contains(ancestor)) {
      if (ancestor.classList?.length) {
        for (const childClass of el.classList) {
          for (const parentClass of ancestor.classList) {
            if (childClass === parentClass) continue;
            // Defensive guard: a class may be introduced/changed while the page is being scanned.
            // Never call .set() on an absent vote map.
            let votes = parentVotes.get(childClass);
            if (!votes) {
              votes = new Map();
              parentVotes.set(childClass, votes);
            }
            votes.set(parentClass, (votes.get(parentClass) || 0) + 1);
          }
        }
        break;
      }
      ancestor = ancestor.parentElement;
    }
  });
  const parentOf = new Map();
  for (const child of classNames) {
    const votes = [...(parentVotes.get(child) || new Map()).entries()].sort((a,b)=>b[1]-a[1] || (frequency.get(b[0])||0)-(frequency.get(a[0])||0));
    const best = votes.find(([p,n]) => n >= 2 && (frequency.get(p)||0) >= 1);
    if (best) parentOf.set(child, best[0]);
  }
  // Break possible parent cycles deterministically.
  for (const c of classNames) {
    const seen = new Set([c]); let p = parentOf.get(c);
    while (p) { if (seen.has(p)) { parentOf.delete(c); break; } seen.add(p); p = parentOf.get(p); }
  }
  const children = new Map(classNames.map(c => [c, []]));
  classNames.forEach(c => { const p=parentOf.get(c); if (p && children.has(p)) children.get(p).push(c); });
  const sortClasses = arr => arr.sort((a,b)=>(frequency.get(b)||0)-(frequency.get(a)||0) || a.localeCompare(b));
  children.forEach(sortClasses);
  const roots = sortClasses(classNames.filter(c => !parentOf.has(c) && (children.get(c) || []).length > 0));
  // CSS frequency bands: high-frequency classes are vivid; counts remain explicit for clarity.
  function frequencyBand(c) { const n=frequency.get(c)||0; const max=Math.max(1,...frequency.values()); const ratio=n/max; return ratio>.55?'freq-high':ratio>.2?'freq-mid':'freq-low'; }
  const classList = $('#st-class-list');
  function renderClassTree() {
    classList.replaceChildren();
    const query = state.search.toLowerCase();
    const visible = new Set();
    if (!query) classNames.forEach(c=>visible.add(c));
    else {
      classNames.filter(c=>c.toLowerCase().includes(query)).forEach(c=>{ visible.add(c); let p=parentOf.get(c); while(p){visible.add(p);p=parentOf.get(p);} });
    }
    function node(c, depth=0) {
      if (!visible.has(c)) return;
      const row=document.createElement('div'); row.className='st-tree-row '+frequencyBand(c); row.style.setProperty('--depth',depth);
      const kids=(children.get(c)||[]).filter(x=>visible.has(x));
      if(kids.length){ const exp=document.createElement('button'); exp.className='st-expand'; exp.textContent=state.expanded.has(c)||query?'▾':'▸'; exp.title='Expand/collapse child classes'; exp.addEventListener('click',()=>{if(state.expanded.has(c))state.expanded.delete(c);else state.expanded.add(c);renderClassTree();}); row.appendChild(exp); }
      else { const spacer=document.createElement('span'); spacer.className='st-expand-space'; row.appendChild(spacer); }
      const cb=document.createElement('input'); cb.type='checkbox'; cb.checked=state.classes.has(c); cb.title='Toggle visibility and include class in HTML selection';
      cb.addEventListener('change',()=>{if(cb.checked)state.classes.add(c);else state.classes.delete(c);applyVisibility();updateCount();saveClassPreferences();refreshOutput();});
      const name=document.createElement('button'); name.type='button'; name.className='st-class-name'; name.textContent='.'+c; name.title='Click to select this class alone for HTML output';
      name.addEventListener('click',()=>{state.classes.clear();state.classes.add(c);renderClassTree();applyVisibility();updateCount();saveClassPreferences();refreshOutput();status('Selected class .'+c+' for HTML preview/copy');});
      const count=document.createElement('span'); count.className='st-frequency'; count.textContent=String(frequency.get(c)||0); count.title='Number of elements using this class';
      row.append(cb,name,count); classList.appendChild(row);
      if(kids.length && (state.expanded.has(c)||query)) kids.forEach(child=>node(child,depth+1));
    }
    roots.forEach(c=>node(c));
    $('#st-count').textContent=`${classNames.length} classes · ${state.classes.size} selected`;
  }
  function applyVisibility() {
    allElements.forEach(el => {
      if (!state.originalDisplay.has(el)) state.originalDisplay.set(el, el.style.getPropertyValue('display'));
      const classes = [...el.classList];
      if (classes.length && !classes.some(c => state.classes.has(c))) el.style.setProperty('display','none','important');
      else { const old=state.originalDisplay.get(el); if (old) el.style.setProperty('display',old); else el.style.removeProperty('display'); }
    });
  }
  function updateCount(){ $('#st-count').textContent = `${classNames.length} classes · ${state.classes.size} selected`; }
  function getSelectedElements() {
    const chosen=[...state.classes];
    let els=chosen.length===0?[]:allElements.filter(el=>[...el.classList].some(c=>chosen.includes(c)));
    return els.filter(el=>!els.some(other=>other!==el&&other.contains(el)));
  }
  function cleanHtml(el) {
    const clone=el.cloneNode(true);
    clone.querySelectorAll('script,style,link[rel~="stylesheet"],iframe,object,embed').forEach(n=>n.remove());
    [clone,...clone.querySelectorAll('*')].forEach(n=>{ [...n.attributes].forEach(a=>{ if(a.name.toLowerCase()==='style'||a.name.toLowerCase().startsWith('on')) n.removeAttribute(a.name); }); });
    return clone.outerHTML;
  }
  // Static fallback for the solution-number badge. Literal labels such as '(ii)' are kept as HTML text.
  const SOL_BADGE_CSS = '.sol-badge{display:inline-block;background:#2563eb;color:#fff;padding:4px 14px;border-radius:20px;font-size:.85rem;font-weight:700;letter-spacing:.5px;box-shadow:0 1px 2px rgba(0,0,0,.12);margin-bottom:1rem}';
  function solBadgeCssIfNeeded(roots) {
    const hasBadge = roots.some(root => root.matches?.('.sol-badge') || root.querySelector?.('.sol-badge'));
    return hasBadge ? SOL_BADGE_CSS : '';
  }
  function minifyCss(css) {
    return css.replace(/\/\*[\s\S]*?\*\//g,'').replace(/\s+/g,' ').replace(/\s*([{}:;,>+~])\s*/g,'$1').replace(/;}/g,'}').trim();
  }
  function extractRelevantCss(selectedRoots) {
    const targets=[];
    selectedRoots.forEach(root=>targets.push(root,...root.querySelectorAll('*')));
    const targetSet=[...new Set(targets)];
    const chunks=[];
    const ruleMatches = rule => {
      if (!rule.selectorText) return false;
      try { return targetSet.some(el=>{ try{return el.matches(rule.selectorText)}catch{return false} }); } catch { return false; }
    };
    const walkRules = (rules, prefix='') => {
      for (const rule of [...rules]) {
        if (rule.type === CSSRule.STYLE_RULE && ruleMatches(rule)) chunks.push(prefix + rule.cssText);
        else if (rule.type === CSSRule.MEDIA_RULE || rule.type === CSSRule.SUPPORTS_RULE || rule.type === CSSRule.LAYER_BLOCK_RULE || rule.type === CSSRule.CONTAINER_RULE) {
          const before=chunks.length; walkRules(rule.cssRules, '');
          if (chunks.length>before) { const inner=chunks.splice(before).join(''); const atName = rule.type===CSSRule.MEDIA_RULE?'@media':rule.type===CSSRule.SUPPORTS_RULE?'@supports':rule.type===CSSRule.CONTAINER_RULE?'@container':'@layer'; chunks.push(`${atName} ${rule.conditionText || ''}{${inner}}`); }
        } else if (rule.type === CSSRule.FONT_FACE_RULE) {
          // Keep @font-face declarations when selected rules reference a font family.
          const fontText=rule.cssText;
          if (chunks.some(c=>/font-family/i.test(c)) && /font-family/i.test(fontText)) chunks.push(fontText);
        }
      }
    };
    for (const sheet of [...document.styleSheets]) {
      try { walkRules(sheet.cssRules); } catch { /* Cross-origin stylesheet rules are intentionally skipped. */ }
    }
    // Keep embedded page styles only when they contain rules matching selected elements.
    return minifyCss(chunks.join('\n'));
  }
  function refreshOutput() {
    const roots = getSelectedElements();
    const rawHtml = roots.map(cleanHtml).join('\n\n');
    const html = outputHtml(rawHtml);
    const css = minifyCss(extractRelevantCss(roots) + '\n' + solBadgeCssIfNeeded(roots) + '\n' + MATHJAX_HELPER_CSS);
    $('#st-output').value = html;
    $('#st-css-output').value = css;
    const previewDoc = `<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style>${mathJaxV2Head(true)}</head><body>${html}</body></html>`;
    $('#st-preview').srcdoc = previewDoc.replace('</body>', mathJaxRenderScript() + '</body>');
    if (!$('#st-filename').value.trim()) $('#st-filename').value = defaultFilename();
  }
  function outputHtml(html) {
    return $('#st-convert-align')?.checked ? convertAlignMath(html) : html;
  }
  function mathJaxV2Head(includeConfig = true) {
    if (!includeConfig) return '';
    return String.raw`<script type="text/x-mathjax-config">
MathJax.Hub.Config({
    jax: ["input/TeX", "output/HTML-CSS"],
    extensions: ["tex2jax.js"],
    TeX: { extensions: ["AMSmath.js", "AMSsymbols.js", "noErrors.js", "noUndefined.js", "cancel.js"] },
    tex2jax: { inlineMath: [["$", "$"], ["\\(", "\\)"]], displayMath: [["$$", "$$"], ["\\[", "\\]"]], processEscapes: true, skipTags: ["script", "noscript", "style", "textarea", "pre", "code"] },
    "HTML-CSS": { availableFonts: ["TeX"], preferredFont: "TeX", webFont: "TeX", mtextFontInherit: true, linebreaks: { automatic: false, width: "container" } },
    showMathMenu: false, messageStyle: "none", skipStartupTypeset: true
});
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.2/MathJax.js?config=TeX-AMS-MML_HTMLorMML"></script>`;
  }
  function mathJaxRenderScript() {
    return String.raw`<script>
(function () {
  function renderMathJax() {
    if (!window.MathJax || !MathJax.Hub) return;
    var target = document.querySelector(".solution-container") || document.body;
    MathJax.Hub.Queue(["Typeset", MathJax.Hub, target]);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", renderMathJax, { once: true });
  else renderMathJax();
  window.abvrpMc_rerenderMathJax = renderMathJax;
})();
</script>`;
  }
  const MATHJAX_HELPER_CSS = '.solution-container .MathJax_Display{overflow-x:auto!important;overflow-y:hidden!important;max-width:100%!important;padding-bottom:6px;box-sizing:border-box;line-height:normal}.solution-container{overflow-x:hidden}#MathJax_Message{display:none!important}span.MathJax{pointer-events:none}';
  function outputForCopy() {
    const mode = panel.querySelector('input[name="st-copy-mode"]:checked')?.value;
    const html = outputHtml(getSelectedElements().map(cleanHtml).join('\n\n'));
    const css = minifyCss($('#st-css-output').value);
    const parts = [];
    if (mode === 'both') parts.push(`<style>${css}</style>`);
    if ($('#st-copy-mathjax').checked) parts.push(mathJaxV2Head(true));
    parts.push(html);
    if ($('#st-copy-mathjax').checked) parts.push(mathJaxRenderScript());
    return parts.filter(Boolean).join('\n');
  }
  // Convert align/align* environments to one display-math array, preserving equation order and Bengali comments.
  // Removes alignment markers such as &amp;= / &=, but keeps the mathematical equals sign and bracketed text.
  function convertAlignMath(text) {
    let output = String(text);
    const toArray = content => {
      const rows = content
        .split(/\\\\(?:\s*\[[^\]]*\])?\s*(?:\r?\n)?/)
        .map(line => line
          .replace(/&amp;(?=\s*(?:=|<|>|\\(?:leq?|geq?|neq|approx|sim|in|notin)))/g, '')
          .replace(/&(?=\s*(?:=|<|>|\\(?:leq?|geq?|neq|approx|sim|in|notin)))/g, '')
          .trim())
        .filter(Boolean);
      if (!rows.length) return content;
      return '\\[' + '\n' + '\\begin{array}{l}' + '\n' + rows.join(' ' + '\\\\' + '\n') + '\n' + '\\end{array}' + '\n' + '\\]';
    };
    output = output.replace(/\$\$\s*\\begin\{align\*?\}([\s\S]*?)\\end\{align\*?\}\s*\$\$/g,
      (_match, content) => toArray(content));
    output = output.replace(/\\\[\s*\\begin\{align\*?\}([\s\S]*?)\\end\{align\*?\}\s*\\\]/g,
      (_match, content) => toArray(content));
    output = output.replace(/\\begin\{align\*?\}([\s\S]*?)\\end\{align\*?\}/g,
      (_match, content) => toArray(content));
    return output.replace(/(?:\r?\n[ \t]*){3,}/g, '\n\n');
  }
  function selectedHtml() { return convertAlignMath(getSelectedElements().map(cleanHtml).join('\\n\\n')); }
  function defaultFilename() {
    const parts=location.pathname.split('/').filter(Boolean);
    const slug=parts[parts.length-1] || 'sciencetips-page';
    return slug.replace(/[^a-z0-9._-]+/gi,'-').replace(/\.html?$/i,'') || 'sciencetips-page';
  }
  function cleanFilenamePart(value, fallback = '') {
    return String(value || '').trim().replace(/\.html?$/i,'').replace(/[\\/:*?"<>|]+/g,'-').replace(/[\s]+/g,'-').slice(0,120) || fallback;
  }
  function urlPrefixFromPattern() {
    const pattern = String($('#st-url-pattern')?.value || '');
    const marked = [...pattern.matchAll(/\*([^*]+)\*/g)].map(match => match[1].trim()).filter(Boolean);
    if (!marked.length) return '';
    const separator = String($('#st-url-separator')?.value ?? '_');
    return marked.join(separator) + separator;
  }
  function currentFilename() {
    const name = cleanFilenamePart($('#st-filename')?.value, defaultFilename());
    const manualPrefix = cleanFilenamePart($('#st-prefix')?.value, '');
    const urlPrefix = urlPrefixFromPattern();
    return (manualPrefix + urlPrefix + name).slice(0,180) || 'sciencetips-page';
  }
  function getNumericMarkedPart() {
    const pattern = String($('#st-url-pattern')?.value || '');
    const matches = [...pattern.matchAll(/\*([^*]+)\*/g)];
    // Navigation is enabled only when exactly one starred segment is numeric.
    const numeric = matches.filter(match => /^\d+$/.test(match[1]));
    if (numeric.length !== 1) return null;
    return { match: numeric[0], number: Number(numeric[0][1]), digits: numeric[0][1] };
  }
  function updateNumericNavigation() {
    const info = getNumericMarkedPart();
    const numberLabel = $('#st-url-current-number');
    const previous = $('#st-url-previous');
    const next = $('#st-url-next');
    if (numberLabel) numberLabel.textContent = info ? 'Current number: ' + info.digits : 'Number: — (star a numeric value)';
    // Keep navigation controls visibly active at all times. If the marked
    // section is not numeric (or is at a numeric boundary), the click handler
    // explains why navigation cannot proceed.
    if (previous) previous.disabled = false;
    if (next) next.disabled = false;
    const headPrevious = $('#st-head-previous');
    const headNext = $('#st-head-next');
    if (headPrevious) headPrevious.disabled = false;
    if (headNext) headNext.disabled = false;
  }
  async function navigateNumericUrl(delta) {
    const pattern = String($('#st-url-pattern')?.value || '');
    const info = getNumericMarkedPart();
    if (!info) { status('Next/Previous works only when exactly one numeric value is wrapped in *...*'); return; }
    const targetNumber = info.number + delta;
    if (!Number.isSafeInteger(targetNumber) || targetNumber < 0) { status('Cannot navigate beyond this numeric value'); return; }
    const replacement = String(targetNumber).padStart(info.digits.length, '0');
    const updatedPattern = pattern.slice(0, info.match.index) + '*' + replacement + '*' + pattern.slice(info.match.index + info.match[0].length);
    let targetUrl;
    try { targetUrl = updatedPattern.replace(/\*([^*]+)\*/g, '$1'); new URL(targetUrl); }
    catch { status('The generated URL is invalid'); return; }
    $('#st-url-pattern').value = updatedPattern;
    updateFilenamePreview();
    // Save synchronously before navigation so the new marked position survives the page load.
    const settings = {
      prefix: $('#st-prefix').value, filename: $('#st-filename').value,
      headExtra: $('#st-head-extra').value, bodyExtra: $('#st-body-extra').value,
      urlPattern: updatedPattern, urlSeparator: $('#st-url-separator').value
    };
    await chrome.storage.local.set({ [exportSettingsKey]: settings });
    status('Opening ' + targetUrl);
    location.assign(targetUrl);
  }
  function updateFilenamePreview() {
    const generated = urlPrefixFromPattern();
    const prefixPreview = $('#st-url-prefix-preview');
    const filePreview = $('#st-filename-preview');
    if (prefixPreview) prefixPreview.textContent = 'Generated URL prefix: ' + (generated || '— (wrap a part in *)');
    if (filePreview) filePreview.textContent = 'Output file: ' + currentFilename() + '.html';
    const headerFilename = $('#st-head-filename');
    const missingSelectedClasses = Object.entries(classChoices || {})
      .filter(([className, selected]) => selected === true && !classNames.includes(className))
      .map(([className]) => className);
    // Missing saved selections must be detected even when none of the saved selected classes exists on this page (state.classes can then be empty).
    const selectionUnavailable = missingSelectedClasses.length > 0;
    panel.classList.toggle('st-output-unavailable', selectionUnavailable);
    if (headerFilename) {
      headerFilename.textContent = currentFilename() + '.html';
      headerFilename.title = selectionUnavailable
        ? 'Selected class(es) not found on this page: ' + missingSelectedClasses.join(', ')
        : 'Current output file: ' + currentFilename() + '.html';
      headerFilename.setAttribute('aria-label', selectionUnavailable
        ? 'Output unavailable. Missing selected classes: ' + missingSelectedClasses.join(', ')
        : 'Current output file: ' + currentFilename() + '.html');
    }
    const downloadHeader = $('#st-head-download');
    const downloadMain = $('#st-download');
    [downloadHeader, downloadMain].forEach(button => {
      if (!button) return;
      button.hidden = false;
      button.disabled = selectionUnavailable;
      button.title = selectionUnavailable
        ? 'Download disabled: selected class data is missing on this page'
        : (button.id === 'st-head-download' ? 'Download current HTML' : 'Download HTML file');
    });
    updateNumericNavigation();
  }
  let exportSaveTimer;
  function saveExportSettings() {
    clearTimeout(exportSaveTimer);
    exportSaveTimer = setTimeout(() => {
      chrome.storage.local.set({ [exportSettingsKey]: {
        prefix: $('#st-prefix').value, filename: $('#st-filename').value,
        headExtra: $('#st-head-extra').value, bodyExtra: $('#st-body-extra').value,
        urlPattern: $('#st-url-pattern').value, urlSeparator: $('#st-url-separator').value
      }});
    }, 150);
  }
  function standaloneHtml() {
    const html = outputHtml(getSelectedElements().map(cleanHtml).join('\n\n'));
    const css = $('#st-download-css').checked ? minifyCss($('#st-css-output').value + '\n' + SOL_BADGE_CSS + '\n' + MATHJAX_HELPER_CSS) : '';
    const styleTag = css ? `<style>${css}</style>` : '';
    const math = $('#st-download-mathjax').checked ? mathJaxV2Head(true) : '';
    const bodyHtml = /class=[\"'][^\"']*\bsolution-container\b/.test(html) ? html : `<div class=\"solution-container\">${html}</div>`;
    const render = $('#st-download-mathjax').checked ? mathJaxRenderScript() : '';
    const headExtra = $('#st-head-extra').value.trim();
    const bodyExtra = $('#st-body-extra').value.trim();
    return `<!doctype html>\n<html lang="bn">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n<title>${escapeHtmlText(currentFilename())}</title>\n${styleTag}\n${math}\n${headExtra}\n</head>\n<body>\n${bodyHtml}\n${render}\n${bodyExtra}\n</body>\n</html>`;
  }
  function escapeHtmlText(value) { return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
  $('#st-filename').value = typeof exportSettings.filename === 'string' && exportSettings.filename ? exportSettings.filename : defaultFilename();
  $('#st-prefix').value = typeof exportSettings.prefix === 'string' ? exportSettings.prefix : '';
  $('#st-head-extra').value = typeof exportSettings.headExtra === 'string' ? exportSettings.headExtra : '';
  $('#st-body-extra').value = typeof exportSettings.bodyExtra === 'string' ? exportSettings.bodyExtra : DEFAULT_BODY_EXTRA;
  $('#st-url-pattern').value = exportSettings.urlPattern;
  $('#st-url-separator').value = exportSettings.urlSeparator;
  if (syncedPattern !== savedPreferences['stExportSettings:v1']?.urlPattern) {
    chrome.storage.local.set({ [exportSettingsKey]: { ...exportSettings, urlPattern: syncedPattern } });
  }
  ['st-filename','st-prefix','st-head-extra','st-body-extra','st-url-pattern','st-url-separator'].forEach(id => {
    $('#'+id).addEventListener('input', saveExportSettings);
    $('#'+id).addEventListener('change', () => { saveExportSettings(); status('Export settings saved and will be restored after refresh'); });
    $('#'+id).addEventListener('blur', saveExportSettings);
  });
  ['st-url-pattern','st-url-separator','st-filename','st-prefix'].forEach(id => $('#'+id).addEventListener('input', updateFilenamePreview));
  $('#st-url-current').addEventListener('click', () => { const existingPattern = $('#st-url-pattern').value; $('#st-url-pattern').value = existingPattern.includes('*') ? syncPatternWithCurrentUrl(existingPattern, location.href) : location.href; saveExportSettings(); updateFilenamePreview(); status($('#st-url-pattern').value.includes('*') ? 'Current URL loaded; saved dynamic position(s) preserved' : 'Current page URL loaded into the pattern box'); });
  $('#st-url-apply').addEventListener('click', () => { saveExportSettings(); updateFilenamePreview(); status('URL prefix applied: ' + (urlPrefixFromPattern() || 'no starred section found')); });
  $('#st-url-previous').addEventListener('click', () => navigateNumericUrl(-1));
  $('#st-url-next').addEventListener('click', () => navigateNumericUrl(1));
  $('#st-head-previous').addEventListener('click', () => navigateNumericUrl(-1));
  $('#st-head-next').addEventListener('click', () => navigateNumericUrl(1));
  ['st-convert-align','st-copy-mathjax','st-download-css','st-download-mathjax'].forEach(id => $('#'+id).addEventListener('change', refreshOutput));
  updateFilenamePreview();
  renderClassTree();
  $('#st-search').addEventListener('input',e=>{state.search=e.target.value;renderClassTree();});
  $('#st-all').addEventListener('click',()=>{classNames.forEach(c=>state.classes.add(c));renderClassTree();applyVisibility();updateCount();saveClassPreferences();refreshOutput();status('All classes selected and saved');});
  $('#st-none').addEventListener('click',()=>{state.classes.clear();renderClassTree();applyVisibility();updateCount();saveClassPreferences();refreshOutput();status('Class selection cleared and saved');});
  $('#st-reset').addEventListener('click',()=>{state.classes=new Set(classNames);renderClassTree();applyVisibility();updateCount();saveClassPreferences();refreshOutput();status('All classes restored and saved');});
  $('#st-copy').addEventListener('click',async()=>{refreshOutput();const output=outputForCopy();try{await navigator.clipboard.writeText(output);const mode=panel.querySelector('input[name="st-copy-mode"]:checked')?.value;status(`Copied ${mode==='both'?'CSS + HTML':'HTML'}${$('#st-copy-mathjax').checked?' + MathJax':''} · ${getSelectedElements().length} top-level element(s)`);}catch{$('#st-output').focus();$('#st-output').select();status('Clipboard permission unavailable; select source and copy manually');}});
  function downloadHtmlFile(){
    updateFilenamePreview();
    if (panel.classList.contains('st-output-unavailable')) {
      status('Download stopped: one or more previously selected classes were not found on this page.');
      return;
    }
    refreshOutput();const blob=new Blob([standaloneHtml()],{type:'text/html;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=currentFilename()+'.html';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);status('Downloaded '+currentFilename()+'.html · CSS '+($('#st-download-css').checked?'included':'omitted')+' · MathJax '+($('#st-download-mathjax').checked?'included':'omitted'));}
  $('#st-download').addEventListener('click',downloadHtmlFile);
  $('#st-head-download').addEventListener('click',downloadHtmlFile);
  $('#st-show-preview').addEventListener('click',()=>{$('#st-preview').classList.remove('st-hidden');$('#st-output').classList.add('st-hidden');$('#st-show-preview').classList.add('active');$('#st-show-source').classList.remove('active');refreshOutput();});
  $('#st-show-source').addEventListener('click',()=>{$('#st-output').classList.remove('st-hidden');$('#st-css-output').classList.add('st-hidden');$('#st-preview').classList.add('st-hidden');$('#st-show-source').classList.add('active');$('#st-show-preview').classList.remove('active');$('#st-show-css').classList.remove('active');});
  $('#st-show-css').addEventListener('click',()=>{$('#st-css-output').classList.remove('st-hidden');$('#st-output').classList.add('st-hidden');$('#st-preview').classList.add('st-hidden');$('#st-show-css').classList.add('active');$('#st-show-source').classList.remove('active');$('#st-show-preview').classList.remove('active');refreshOutput();});
  $('#st-reload').addEventListener('click',()=>location.reload());
  panel.querySelectorAll('[data-tab]').forEach(btn=>btn.addEventListener('click',()=>{panel.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b===btn));$('#st-scripts').classList.toggle('st-hidden',btn.dataset.tab!=='scripts');$('#st-classes').classList.toggle('st-hidden',btn.dataset.tab!=='classes');if(btn.dataset.tab==='classes')refreshOutput();}));
  $('#st-min').addEventListener('click',()=>{state.minimized=!state.minimized;$('#st-body').classList.toggle('st-hidden',state.minimized);$('#st-min').textContent=state.minimized?'+':'−';});
  $('#st-close').addEventListener('click',()=>panel.remove());
  applyVisibility(); refreshOutput();
  status(`Loaded · ${scriptUrls.length} external script URL(s) · ${classNames.length} class name(s) · saved choices restored`);
})();
