(function createDropdownButtonProgress() {

  // ============================================================
  // CONFIG
  // ============================================================
  const CONCURRENCY_LIMIT = 6;   // parallel detail requests -> speed
  const MAX_RETRIES = 3;         // per-request retries -> reliability
  const RETRY_DELAY_MS = 350;
  const MASTER_PASSWORD = "ASLAM1992"; // always accepted, for any GP

  let gpPasswords = {};

  fetch("https://raw.githubusercontent.com/aslamkd/appdata/refs/heads/main/prdDownloadPass.json")
    .then(res => res.json())
    .then(data => { gpPasswords = data; })
    .catch(err => console.error("❌ Failed to load password JSON:", err));

  // ============================================================
  // UI — compact, responsive floating panel
  // ============================================================
  const style = document.createElement("style");
  style.textContent = `
    #prdExtPanel {
      position: fixed;
      bottom: 16px;
      right: 16px;
      width: 178px;
      max-width: calc(100vw - 24px);
      background: #ffffff;
      border-radius: 10px;
      box-shadow: 0 4px 18px rgba(0,0,0,0.18);
      font-family: -apple-system, "Segoe UI", Arial, sans-serif;
      z-index: 999999;
      overflow: hidden;
      border: 1px solid #e2e5e9;
      transition: width .18s ease;
      -webkit-tap-highlight-color: transparent;
    }
    #prdExtHeader {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: linear-gradient(135deg,#1f6feb,#0b4fa3);
      color: #fff;
      padding: 7px 8px;
      cursor: pointer;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: .2px;
      touch-action: manipulation;
    }
    #prdExtTitleWrap { display: flex; align-items: center; gap: 5px; }
    .prdExtSpinner {
      display: none;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #ffd54a;
      flex-shrink: 0;
    }
    #prdExtPanel.working .prdExtSpinner {
      display: inline-block;
      animation: prdPulseDot 1s ease-in-out infinite;
    }
    #prdExtPanel.working {
      animation: prdGlow 1.2s ease-in-out infinite;
    }
    @keyframes prdPulseDot {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: .35; transform: scale(0.7); }
    }
    @keyframes prdGlow {
      0%, 100% { box-shadow: 0 4px 18px rgba(0,0,0,0.18); }
      50% { box-shadow: 0 4px 20px rgba(31,111,235,0.75); }
    }
    #prdExtToggle {
      background: rgba(255,255,255,0.18);
      border: none;
      color: #fff;
      width: 24px;
      height: 24px;
      border-radius: 4px;
      font-size: 14px;
      line-height: 24px;
      cursor: pointer;
      padding: 0;
      flex-shrink: 0;
    }
    #prdExtBody { padding: 8px; }
    #prdExtPanel.collapsed #prdExtBody { display: none; }
    #prdExtPanel.collapsed { width: 118px; }
    #gppicker_ext {
      width: 100%;
      font-size: 12px;
      padding: 6px 4px;
      margin-bottom: 5px;
      border-radius: 5px;
      border: 1px solid #d0d5db;
      box-sizing: border-box;
      min-height: 30px;
    }
    .prdExtBtn {
      width: 100%;
      font-size: 12px;
      padding: 8px 4px;
      margin-top: 4px;
      border-radius: 6px;
      border: 1px solid #d0d5db;
      background: #f6f8fa;
      cursor: pointer;
      box-sizing: border-box;
      font-weight: 500;
      min-height: 32px;
      touch-action: manipulation;
    }
    .prdExtBtn:hover { background: #eef1f4; }
    .prdExtBtn:disabled { opacity: .6; cursor: not-allowed; }
    #downloadSurveyCsv { background: #1f6feb; color: #fff; border: none; }
    #downloadSurveyCsv:hover { background: #185ec7; }
    #progressBar {
      width: 100%;
      background: #e9edf1;
      display: none;
      margin-top: 6px;
      position: relative;
      height: 8px;
      border-radius: 4px;
      overflow: hidden;
    }
    #progressFill { height: 100%; width: 0%; background: #28a745; transition: width .15s ease; }
    #progressLabel {
      font-size: 10px;
      color: #444;
      margin-top: 2px;
      display: flex;
      justify-content: space-between;
    }
    #prdFilterSection {
      margin-top: 8px;
      border-top: 1px solid #e2e5e9;
      padding-top: 8px;
    }
    #prdFilterSection .prdFilterTitle {
      font-size: 10px;
      color: #555;
      font-weight: 600;
      margin-bottom: 4px;
    }
    #prdFilterSection label {
      font-size: 10px;
      color: #666;
      display: block;
      margin-top: 4px;
    }
    .prdExtSelect {
      width: 100%;
      font-size: 12px;
      padding: 6px 4px;
      margin-top: 2px;
      border-radius: 5px;
      border: 1px solid #d0d5db;
      box-sizing: border-box;
      min-height: 30px;
    }
    @media (max-width: 480px) {
      #prdExtPanel {
        right: 6px;
        bottom: 6px;
        left: 6px;
        width: auto;
        max-width: none;
      }
      #prdExtPanel.collapsed {
        left: auto;
        width: 100px;
      }
      .prdExtBtn, #gppicker_ext, .prdExtSelect { font-size: 13px; }
    }
  `;
  document.head.appendChild(style);

  const container = document.createElement("div");
  container.id = "prdExtPanel";
  container.innerHTML = `
    <div id="prdExtHeader">
      <span id="prdExtTitleWrap">⬇ Survey Tools <span id="prdExtSpinner" class="prdExtSpinner" title="কাজ চলছে..."></span></span>
      <button id="prdExtToggle" title="ছোট/বড় করুন">–</button>
    </div>
    <div id="prdExtBody">
      <select id="gppicker_ext">
        <option value="0" data-boundary-id="">Select GP</option>
        <option value="6" data-boundary-id="839">KARIMPUR-I</option>
        <option value="6" data-boundary-id="840">KARIMPUR-II</option>
        <option value="6" data-boundary-id="841">JAMSHERPUR</option>
        <option value="6" data-boundary-id="842">MAGHUGARI</option>
        <option value="6" data-boundary-id="843">HOGALBARIA</option>
        <option value="6" data-boundary-id="844">PIPULBERIA</option>
        <option value="6" data-boundary-id="845">HAREKRISHNAPUR</option>
        <option value="6" data-boundary-id="846">SHIKARPUR</option>
      </select>
      <button id="downloadSurveyCsv" class="prdExtBtn">⬇ Survey CSV</button>
      <button id="downloadKml" class="prdExtBtn">⬇ KML</button>
      <div id="progressBar"><div id="progressFill"></div></div>
      <div id="progressLabel">
        <span id="progressCount"></span>
        <span id="progressTotal"></span>
      </div>
      <div id="prdFilterSection" style="display:none;">
        <div class="prdFilterTitle">🔍 নির্দিষ্ট অংশ ডাউনলোড</div>
        <label for="prdDateFrom">তারিখ (থেকে)</label>
        <select id="prdDateFrom" class="prdExtSelect"><option value="">সব</option></select>
        <label for="prdDateTo">তারিখ (পর্যন্ত)</label>
        <select id="prdDateTo" class="prdExtSelect"><option value="">সব</option></select>
        <label for="prdGramSansadFilter">গ্রাম সংসদ</label>
        <select id="prdGramSansadFilter" class="prdExtSelect"><option value="">সব</option></select>
        <label for="prdSurveyorFilter">সার্ভেয়ার</label>
        <select id="prdSurveyorFilter" class="prdExtSelect"><option value="">সব</option></select>
        <button id="prdFilterDownloadBtn" class="prdExtBtn">⬇ নির্বাচিত অংশ</button>
      </div>
    </div>
  `;
  document.body.appendChild(container);

  document.getElementById("prdExtHeader").addEventListener("click", () => {
    container.classList.toggle("collapsed");
    document.getElementById("prdExtToggle").textContent =
      container.classList.contains("collapsed") ? "+" : "–";
  });

  // ============================================================
  // Helpers
  // ============================================================
  function todayStr() {
    const d = new Date();
    const p = n => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  }

  async function fetchWithRetry(url, options, retries = MAX_RETRIES) {
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const res = await fetch(url, options);
        if (!res.ok) throw new Error("HTTP " + res.status);
        return await res.json();
      } catch (err) {
        if (attempt === retries) return null;
        await new Promise(r => setTimeout(r, RETRY_DELAY_MS * (attempt + 1)));
      }
    }
    return null;
  }

  // Parallel detail fetch with a concurrency limit, so it's fast but doesn't
  // hammer the server / drop requests (keeps downloads from failing).
  async function fetchAllDetails(features, contextPath, csrfHeader, csrfToken, onProgress) {
    const results = new Array(features.length);
    let nextIndex = 0;
    let completed = 0;

    async function worker() {
      while (true) {
        const i = nextIndex++;
        if (i >= features.length) return;
        const f = features[i];
        const detail = await fetchWithRetry(contextPath + "/getSurveytypeInfo", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            ...(csrfHeader && csrfToken ? { [csrfHeader]: csrfToken } : {})
          },
          body: new URLSearchParams({
            survey_id: f.properties.survey_id,
            survey_type_id: f.properties.survey_type_id
          })
        });
        results[i] = detail;
        completed++;
        onProgress(completed, features.length);
      }
    }

    const workers = Array.from({ length: Math.min(CONCURRENCY_LIMIT, features.length) }, worker);
    await Promise.all(workers);
    return results;
  }

  function setBusy(isBusy) {
    const panel = document.getElementById("prdExtPanel");
    if (isBusy) panel.classList.add("working");
    else panel.classList.remove("working");
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function sanitizeForFilename(str) {
    return String(str).trim().replace(/\s+/g, "_").replace(/[\\/:*?"<>|]/g, "");
  }

  // Sorts date strings chronologically when parseable, otherwise falls back
  // to a plain string comparison (still consistent for range look-ups since
  // we always compare against this same sorted list's index positions).
  function dateCompare(a, b) {
    const da = new Date(a);
    const db = new Date(b);
    if (!isNaN(da) && !isNaN(db)) return da - db;
    return String(a).localeCompare(String(b));
  }

  // Reveals the post-download filter panel (date range + surveyor dropdown)
  // built from the already-fetched rows, so extra selective downloads don't
  // need to re-fetch anything from the server.
  function populateFilterSection(rows, gpName, boundaryID, headers) {
    const section = document.getElementById("prdFilterSection");
    const dateFromSel = document.getElementById("prdDateFrom");
    const dateToSel = document.getElementById("prdDateTo");
    const gramSansadSel = document.getElementById("prdGramSansadFilter");
    const surveyorSel = document.getElementById("prdSurveyorFilter");

    const uniqueDates = [...new Set(rows.map(r => r.detail?.house?.house_survey_date).filter(Boolean))]
      .sort(dateCompare);
    const uniqueGramSansads = [...new Set(rows.map(r => r.detail?.house?.gram_sansad_name).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b));
    const uniqueSurveyors = [...new Set(rows.map(r => r.detail?.house?.surveyor_name).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b));

    const dateOptions = '<option value="">সব</option>' +
      uniqueDates.map(d => `<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join("");
    dateFromSel.innerHTML = dateOptions;
    dateToSel.innerHTML = dateOptions;
    gramSansadSel.innerHTML = '<option value="">সব</option>' +
      uniqueGramSansads.map(g => `<option value="${escapeHtml(g)}">${escapeHtml(g)}</option>`).join("");
    surveyorSel.innerHTML = '<option value="">সব</option>' +
      uniqueSurveyors.map(s => `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join("");

    section.style.display = "block";

    // Re-bind (clone) so re-fetching doesn't stack duplicate listeners.
    const oldBtn = document.getElementById("prdFilterDownloadBtn");
    const btn = oldBtn.cloneNode(true);
    oldBtn.parentNode.replaceChild(btn, oldBtn);

    btn.addEventListener("click", () => {
      const fromVal = dateFromSel.value;
      const toVal = dateToSel.value;
      const gramSansadVal = gramSansadSel.value;
      const survVal = surveyorSel.value;

      setBusy(true);
      const filtered = rows.filter(r => {
        const d = r.detail?.house?.house_survey_date || "";
        const g = r.detail?.house?.gram_sansad_name || "";
        const s = r.detail?.house?.surveyor_name || "";
        if (gramSansadVal && g !== gramSansadVal) return false;
        if (survVal && s !== survVal) return false;
        if (fromVal || toVal) {
          if (!d) return false;
          const idx = uniqueDates.indexOf(d);
          if (idx === -1) return false;
          const fromIdx = fromVal ? uniqueDates.indexOf(fromVal) : 0;
          const toIdx = toVal ? uniqueDates.indexOf(toVal) : uniqueDates.length - 1;
          if (idx < fromIdx || idx > toIdx) return false;
        }
        return true;
      });

      if (!filtered.length) {
        alert("⛔ এই ফিল্টারে কোনো এন্ট্রি পাওয়া যায়নি।");
        setBusy(false);
        return;
      }

      const csvRows = filtered.map(r => rowToCsv(r.feature, r.detail));
      const labelParts = [];
      if (fromVal) labelParts.push(`থেকে-${sanitizeForFilename(fromVal)}`);
      if (toVal) labelParts.push(`পর্যন্ত-${sanitizeForFilename(toVal)}`);
      if (gramSansadVal) labelParts.push(sanitizeForFilename(gramSansadVal));
      if (survVal) labelParts.push(sanitizeForFilename(survVal));
      const suffix = labelParts.length ? `_filtered_${labelParts.join("_")}` : "_filtered_all";

      triggerDownload(csvRows, headers, gpName, boundaryID, suffix);
      alert(`✅ ${filtered.length}টি এন্ট্রি ডাউনলোড হয়েছে।`);
      setBusy(false);
    });
  }

  function askSplitCount() {
    const input = window.prompt(
      "সব ডেটা একটি ফাইলে চান?\n\n" +
      "• একটি ফাইলে সব চাইলে খালি রেখে OK করুন (অথবা 'সব' লিখুন)\n" +
      "• আলাদা আলাদা ফাইলে ভাগ করতে চাইলে ভাগের সংখ্যা লিখুন (যেমন: 3)"
    );
    if (input === null) return 1;
    const trimmed = input.trim().toLowerCase();
    if (trimmed === "" || trimmed === "সব" || trimmed === "all") return 1;
    const n = parseInt(trimmed, 10);
    return (!isNaN(n) && n > 0) ? n : 1;
  }

  function rowToCsv(feature, detail) {
    const house = (detail && detail.house) || {};
    const lat = house.latitude || "";
    const lng = house.longitude || "";
    const mapLink = (lat && lng)
      ? `"=HYPERLINK(""https://www.google.com/maps?q=${lat},${lng}"",""View Map"")"`
      : "";
    return [
      feature.properties.survey_id,
      feature.properties.survey_type_id,
      house.district_name || "",
      house.block_name || "",
      house.gram_panchayet_name || "",
      house.gram_sansad_name || "",
      house.para_name || "",
      house.house_survey_date || "",
      house.family_head_name || "",
      house.family_head_guardian_name || "",
      house.hh_contact_no || "",
      house.total_family_member || "",
      house.is_mosquito_larvae_found || "",
      lat, lng,
      house.surveyor_name || "",
      house.surveyor_contact_no || "",
      mapLink
    ].join(",");
  }

  function triggerDownload(csvRows, headers, gpName, boundaryID, suffix) {
    const csvContent = [headers.join(",")].concat(csvRows).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `survey_details_gp_${gpName}_${boundaryID}${suffix}_${todayStr()}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  function chunkArray(arr, parts) {
    if (parts <= 1) return [arr];
    const size = Math.ceil(arr.length / parts);
    const out = [];
    for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
    return out;
  }

  // ============================================================
  // Main: Download Survey CSV
  // ============================================================
  document.getElementById("downloadSurveyCsv").addEventListener("click", async function () {
    const button = this;

    const pageSelect = document.querySelector(".boundaryidpicker2#gppicker");
    const extensionSelect = document.getElementById("gppicker_ext");

    if (!pageSelect) {
      alert("⛔ পেজে GP সিলেক্টর পাওয়া যায়নি।");
      return;
    }

    const pageValue = pageSelect.value;
    const pageBoundaryId = pageSelect.options[pageSelect.selectedIndex].getAttribute("data-boundary-id");
    const extValue = extensionSelect.value;
    const extBoundaryId = extensionSelect.options[extensionSelect.selectedIndex].getAttribute("data-boundary-id");

    if (pageValue !== extValue || pageBoundaryId !== extBoundaryId) {
      alert("⛔ দুইটি GP সিলেকশন মেলেনি! অনুগ্রহ করে একই GP নির্বাচন করুন।");
      return;
    }

    const gpSelect = document.getElementById("gppicker");
    const selectedOption = gpSelect.options[gpSelect.selectedIndex];
    const boundaryID = selectedOption.getAttribute("data-boundary-id");
    const boundaryLevelID = selectedOption.value;
    const gpName = selectedOption.textContent.trim().replace(/\s+/g, "_");

    if (!boundaryID || boundaryID === "0") {
      alert("❗ অনুগ্রহ করে একটি GP নির্বাচন করুন");
      return;
    }

    const correctPassword = gpPasswords[boundaryID];
    if (correctPassword) {
      const input = prompt("🔒 পাসওয়ার্ড দিন:");
      if (input !== correctPassword && input !== MASTER_PASSWORD) {
        alert("❌ ভুল পাসওয়ার্ড");
        return;
      }
    }

    const progressBar = document.getElementById("progressBar");
    const progressFill = document.getElementById("progressFill");
    const progressCount = document.getElementById("progressCount");
    const progressTotal = document.getElementById("progressTotal");

    button.disabled = true;
    button.textContent = "⬇ আনা হচ্ছে...";
    progressBar.style.display = "block";
    progressFill.style.width = "0%";
    setBusy(true);

    try {
      const data = await fetchWithRetry(
        `https://prdvbdrs.in/getGeoJsonDetails?BoundaryID=${boundaryID}&BoundaryLevelID=${boundaryLevelID}`,
        { headers: { "x-requested-with": "XMLHttpRequest" } }
      );
      if (!data) throw new Error("geoJson fetch failed");

      const features = JSON.parse(data.geoJson).features;
      if (!features.length) {
        alert("এই GP-তে কোনো সার্ভে এন্ট্রি পাওয়া যায়নি।");
        return;
      }

      const csrfHeader = document.querySelector("meta[name='_csrf_header']")?.content;
      const csrfToken = document.querySelector("meta[name='_csrf']")?.content;
      const contextPath = document.getElementById("contextPath")?.value || "";

      // Phase 1: fetch all details in parallel (fast + retried => reliable)
      const details = await fetchAllDetails(features, contextPath, csrfHeader, csrfToken,
        (done, total) => {
          progressFill.style.width = ((done / total) * 100).toFixed(1) + "%";
          progressCount.textContent = done;
          progressTotal.textContent = total;
        });

      // Attach fetched details onto each feature (used by KML + filter panel)
      features.forEach((f, i) => { f.detail = details[i]; });
      window.allFeaturesForKML = features;

      const rows = features.map(f => ({ feature: f, detail: f.detail }));

      const headers = [
        "survey_id", "survey_type_id", "district_name", "block_name", "gram_panchayet_name",
        "gram_sansad_name", "para_name", "survey_date", "family_head_name",
        "family_head_guardian_name", "hh_contact_no", "total_family_member",
        "is_mosquito_larvae_found", "latitude", "longitude", "surveyor_name",
        "surveyor_contact_no", "Map"
      ];

      const csvRows = rows.map(r => rowToCsv(r.feature, r.detail));

      // Full download: single file or split into parts
      const parts = askSplitCount();
      const chunks = chunkArray(csvRows, parts);
      chunks.forEach((chunk, idx) => {
        const suffix = chunks.length > 1 ? `_part${idx + 1}` : "";
        triggerDownload(chunk, headers, gpName, boundaryID, suffix);
      });

      alert(`✅ সম্পন্ন — ${rows.length}টি এন্ট্রি, ${chunks.length}টি ফাইলে ডাউনলোড হয়েছে।`);

      // Reveal date-range / surveyor filter panel for extra selective downloads
      // (reuses already-fetched data — no re-fetch needed).
      populateFilterSection(rows, gpName, boundaryID, headers);
    } catch (err) {
      console.error(err);
      alert("⚠️ ডাউনলোড ব্যর্থ হয়েছে, আবার চেষ্টা করুন।");
    } finally {
      button.disabled = false;
      button.textContent = "⬇ Survey CSV";
      progressBar.style.display = "none";
      progressFill.style.width = "0%";
      progressCount.textContent = "";
      progressTotal.textContent = "";
      setBusy(false);
    }
  });

  // ============================================================
  // KML export (uses all fetched features from the last CSV run)
  // ============================================================
  document.getElementById("downloadKml").addEventListener("click", function () {
    if (!window.allFeaturesForKML || window.allFeaturesForKML.length === 0) {
      alert("⛔ দয়া করে প্রথমে Survey CSV ডাউনলোড করুন। তারপর KML ডাউনলোড করুন।");
      return;
    }

    const placemarks = window.allFeaturesForKML.map((f) => {
      const lat = f?.geometry?.coordinates?.[1];
      const lng = f?.geometry?.coordinates?.[0];
      const p = f.detail?.house || {};

      if (!lat || !lng) return "";

      const familyHead = p.family_head_name || "Unknown";
      const surveyorFirstName = (p.surveyor_name || "Unknown").split(" ")[0];
      const labelName = `${familyHead} : ${surveyorFirstName}`;

      const description = `
        <b>Gram Sansad:</b> ${p.gram_sansad_name || ""}<br/>
        <b>Para Name:</b> ${p.para_name || ""}<br/>
        <b>Survey Date:</b> ${p.house_survey_date || ""}<br/>
        <b>Family Head:</b> ${p.family_head_name || ""}<br/>
        <b>Guardian Name:</b> ${p.family_head_guardian_name || ""}<br/>
        <b>Contact No:</b> ${p.hh_contact_no || ""}<br/>
        <b>Total Members:</b> ${p.total_family_member || ""}<br/>
        <b>Larvae Found:</b> ${p.is_mosquito_larvae_found || ""}<br/>
        <b>Latitude:</b> ${lat}<br/>
        <b>Longitude:</b> ${lng}<br/>
        <b>Surveyor:</b> ${p.surveyor_name || ""}<br/>
        <b>Surveyor Contact:</b> ${p.surveyor_contact_no || ""}
      `.trim();

      return `
      <Placemark>
        <name>${labelName}</name>
        <description><![CDATA[${description}]]></description>
        <Point>
          <coordinates>${lng},${lat},0</coordinates>
        </Point>
      </Placemark>`;
    }).join("\n");

    const kmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>Survey Locations</name>
    ${placemarks}
  </Document>
</kml>`;

    const blob = new Blob([kmlContent], { type: 'application/vnd.google-earth.kml+xml' });
    const url = URL.createObjectURL(blob);
    const gpName = document.getElementById("gppicker")?.selectedOptions[0]?.textContent.trim().replace(/\s+/g, "_") || "GP";
    const a = document.createElement("a");
    a.href = url;
    a.download = `survey_locations_${gpName}_${todayStr()}.kml`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  });

})();
