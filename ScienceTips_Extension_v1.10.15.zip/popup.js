const $ = id => document.getElementById(id);
let activeTab = null;
let supported = false;
async function init(){
  const tabs = await chrome.tabs.query({active:true,currentWindow:true});
  activeTab = tabs[0] || null;
  try { const u = new URL(activeTab?.url || ''); supported = u.protocol === 'https:' && u.hostname === 'www.sciencetips.in'; } catch {}
  $('status').textContent = supported ? 'ScienceTips পেজ পাওয়া গেছে। Inspector চালু করতে নিচের বাটনে ক্লিক করুন।' : 'বর্তমান ট্যাব ScienceTips নয়। ScienceTips পেজ খুলুন।';
  $('toggle').disabled = !supported; $('show').disabled = !supported;
}
async function send(type){
  if(!supported || !activeTab?.id) return;
  try {
    const res = await chrome.tabs.sendMessage(activeTab.id,{type});
    $('status').textContent = res?.ok ? (res.visible ? 'Inspector দেখানো হচ্ছে।' : 'Inspector লুকানো হয়েছে।') : 'Inspector পাওয়া যায়নি। পেজটি একবার reload করুন।';
  } catch(e) {
    $('status').textContent = 'Content script পাওয়া যায়নি। ScienceTips পেজ reload করে আবার চেষ্টা করুন.';
  }
}
$('toggle').addEventListener('click',()=>send('ST_INSPECTOR_TOGGLE'));
$('show').addEventListener('click',()=>send('ST_INSPECTOR_SHOW'));
$('open').addEventListener('click',()=>chrome.tabs.create({url:'https://www.sciencetips.in/wbbse-solutions/class-10/math/koshe-dekhi-1.1/'}));
init();