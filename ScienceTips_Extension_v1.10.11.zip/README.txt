ScienceTips HTML Inspector & Script Blocker v1.10.1

Scope
- Runs on any HTTPS page under https://www.sciencetips.in/.

Features
- Detect external JavaScript URLs and persistently block selected URLs before reload/navigation.
- Save selected CSS class choices per page across reloads.
- Show class frequency counts and expandable parent/child class groupings.
- Preview selected HTML with matching page CSS where browser permissions allow access.
- View HTML Source or the minified CSS Section separately.
- Choose whether align/align* environments are converted to a single \[ \begin{array}{l} ... \end{array} \] display block, one equation per row, with alignment ampersands removed. This option affects copy and download.
- Copy HTML only or minified CSS + HTML. Optionally include the MathJax 2.7.2 setup in copied output.
- Download a standalone HTML file with editable filename and manual prefix. A URL pattern box extracts text surrounded by asterisks (for example `https://www.sciencetips.in/question-paper/madhyamik-question-paper/*2026*/english/`) and adds the chosen separator (default `_`), so `newname` becomes `2026_newname.html`. The pattern, separator, filename, manual prefix, and custom export code persist across refreshes and extension updates that retain Chrome storage.
- Add optional extra code inside the downloaded file’s `<head>` and custom code immediately before `</body>`. The body field defaults to the MadhyamikGanitprabha koshe-dekhi-tools.js script and can be edited or cleared.
- Selected/cleared class choices persist per page across refreshes; when a saved selection exists, other classes remain unselected.
- Independently choose whether downloaded HTML includes extracted CSS and whether it includes MathJax 3. MathJax uses https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.2/MathJax.js?config=TeX-AMS-MML_HTMLorMML and runs a direct typeset queue on page load without waiting for scroll.
- Adds #MathJax_Message{display:none}span.MathJax{pointer-events:none} to extracted CSS when CSS is included.

Install
1. Extract the ZIP to a folder.
2. Open chrome://extensions in desktop Chrome.
3. Enable Developer mode.
4. Click Load unpacked and select the extracted folder.
5. Open or reload a page under https://www.sciencetips.in/.
6. Click the extension toolbar icon to open its popup, then use Show/Hide Inspector.

If the popup says the content script is unavailable, reload the ScienceTips tab once and click the extension icon again.

Important notes
- MathJax needs internet access because it loads from jsDelivr.
- Cross-origin stylesheets may not be readable by the browser and their rules can be omitted. Complex selectors, pseudo-elements, inherited styles, or rules dependent on the original page context can affect standalone appearance.
- Blocking a script takes effect on subsequent loads; reload after changing a block rule.
- ZIP integrity and JavaScript syntax are checked, but this package has not been live-tested in Chrome.


Version 1.7.0 conversion fix:
- Uses robust align/align* environment matching for both \[...\] and $$...$$ wrappers, as well as unwrapped environments.
- Removes alignment ampersands and converts each row to one inline MathJax $ ... $ expression.
- Prevents leftover display wrappers from producing stray $$ $$ delimiters.

Version 1.8.0 conversion update:
- Matches the exact $$ \begin{align*} ... \end{align*} $$ pattern from the provided example.
- Also handles \[ ... \] wrappers and bare align environments.
- Splits rows at LaTeX line breaks, removes &amp; / &, and outputs one $ ... $ expression per row.
- Prevents leftover $$ wrappers around converted rows.

Version 1.8.2: Adds static .sol-badge CSS (no CSS variables) to exported CSS and preserves literal badge labels such as (ii).


Version 1.8.3: Preserves leading bracketed labels such as (ii), (a), and [1] as literal text outside MathJax; uses a single <br> between converted equations instead of blank lines to prevent equations running together and causing unnecessary horizontal overflow.

Version 1.9.0 updates:
- Converts align/align* equations to a single display-mode array with one equation per row.
- Removes alignment markers before relation operators and preserves Bengali comments such as \mbox{[2 দিয়ে ভাগ করে]}.
- Uses MathJax 2.7.2 configuration and an immediate explicit typesetting queue for copied/downloaded output.
- Adds horizontal scrolling for long display equations.

Version 1.9.0 updates:
- Converts align/align* equations to one display-mode array with one equation per row.
- Removes alignment markers such as &amp;= and &= while preserving mathematical operators and Bengali comments like \mbox{[2 দিয়ে ভাগ করে]}.
- Uses the requested MathJax 2.7.2 configuration and explicit immediate typesetting queue.
- Adds horizontal scrolling for long display equations and permits scripts in the sandboxed preview for MathJax rendering.

Version 1.9.1 click fix:
- Adds a toolbar popup so clicking the extension icon has a visible action.
- Popup can show/hide the Inspector on the active ScienceTips page and open the example page.
- Adds message handling to reattach the panel if it was closed.


Version 1.9.3 UI updates:
- Header minimize/close controls stay aligned at the top right.
- Inspector content is stacked vertically instead of appearing beside the header.
- External JS tab includes Select all and Deselect all controls for block rules.
- Class tree lists only parent classes that have child classes; expand a parent to view children.


Version 1.9.5 updates:
- Adds a persistent filename prefix field and preserves the filename field across refreshes.
- Adds persistent custom HTML/script fields for the downloaded document head and immediately before the closing body tag.
- Defaults the body-end code to the requested koshe-dekhi-tools.js script; it can be removed or replaced.
- Retains saved class selection per page across refreshes and extension replacement when Chrome storage is preserved.


Version 1.9.7 updates:
- Automatically updates starred URL values when a newly opened URL matches the saved URL pattern (for example 2026 to 2020).
- Saves class selection state by class name across pages on the same site, so selected and unchecked classes are remembered across year-specific URLs. New class names default to selected.
- Keeps export settings and all prior features.


Version 1.9.8 update:
- The Auto prefix from URL box is synchronized with the currently opened URL while preserving the asterisk-marked dynamic position(s).
- Use current URL no longer discards existing asterisk markers; it updates the marked value from the current URL.
- If exact static URL context changes, the extension attempts to preserve marked path-segment positions on the same origin when the path structure has the same segment count.


Version 1.9.9 additions:
- Added Previous and Next buttons beside the URL pattern controls.
- The currently marked numeric value is always displayed.
- Previous/Next are enabled only when exactly one *...* segment contains digits; the buttons decrement/increment that value, preserve its digit width, save the updated pattern, and open the resulting URL in the current tab.


Version 1.10.0 update: compact header now displays the current generated HTML output filename beside “HTML Inspector”, with small quick-download, previous-number, and next-number icon buttons. The navigation buttons are enabled only when the starred URL part is numeric. The existing full controls remain available in the export settings.


Version 1.10.1 update: the complete generated output filename is displayed in small text directly below “HTML Inspector” in the header, saving horizontal space. Quick previous/next/download icons and minimize/close controls remain alongside it.


Version 1.10.2 update: Auto prefix from URL now loads the current page URL automatically when the inspector opens. If a starred URL pattern was saved previously, its starred position(s) are remapped onto the current URL and retained. On first use, when no starred position has ever been saved, the current URL appears unmarked so the user can wrap the desired part in * once.


Version 1.10.3
- If a class that was saved as selected is missing from the current page while other classes remain selected, the output filename in the header turns red and both download controls are hidden. The download function also refuses to download until the missing-class condition is resolved. Hover over the red filename to see which saved selected classes are missing.


v1.10.4 changes:
- Previous/Next controls stay active at all times; clicks require a single numeric starred URL segment to navigate.
- Header filename text turns red only when selected classes are missing; no red background or border.
- Download controls are green when available and remain visible but disabled if selected class data is missing.


v1.10.5 fix:
- Missing saved selected classes are now detected even if none of the previously selected classes exists on the current page (the current selection set may be empty). The filename text turns red and both download controls are disabled until the selected classes are available.


Version 1.10.6 updates:
- Adds a persistent preset URL list (one URL per line). Header and panel Previous/Next buttons navigate through this list in order, wrapping at the ends. If the list is empty, numeric *...* navigation remains available.
- Saves the URL list together with export settings across refreshes.
- Downloaded HTML includes the MathJax 2.7.2 configuration and immediate typesetting queue, responsive table overflow CSS, and a compact responsive table fitting script before the closing body tag. The existing user-editable body-end script (including koshe-dekhi-tools.js by default) is still included.
- Keeps class selections stored by class name and preserves the filename/prefix and extra head/body code.


Version 1.10.7 update
- A small list icon beside “HTML Inspector” opens a quick editor for the preset URL list. Paste one URL per line and choose Save list. The list is saved to Chrome storage and is also reflected in the existing Preset URL list field.


Version 1.10.8 update
- Preset URL list accepts one entry per line in the format: Title, URL
- URL may be absolute (https://...) or relative (/path/to/page/). Relative URLs use the current site's origin.
- Next/Previous navigates through entries in the saved order.
- When the current page matches a saved entry, its title is used as the output HTML filename (sanitized for filesystem compatibility). Existing manual and URL-based prefixes continue to apply.
- Example: কষে দেখি 1.1, /wbbse-solutions/class-7/math/koshe-dekhi-1.1/

Version 1.10.9
- Added a separate editable "Additional CSS" textarea.
- Default CSS: body{font-family:system-ui,-apple-system,"Noto Serif Bengali","Segoe UI",sans-serif;}
- Additional CSS is saved in chrome.storage.local, restored across page navigation/refresh, and included in every downloaded HTML file independently of the extracted-page-CSS checkbox.
- Clearing the Additional CSS box omits this extra style block from downloaded files.

Version 1.10.11 update: downloaded HTML now loads Noto Serif Bengali from Google Fonts, and the default Additional CSS puts Noto Serif Bengali first (body{font-family:"Noto Serif Bengali",serif;}). Internet access is required to fetch the web font; browser fallback is serif if the font service is unavailable.
