(() => {
  "use strict";
  if (window.__PRD_VBD_UNIFIED__) return;
  window.__PRD_VBD_UNIFIED__ = true;

  const CONCURRENCY_LIMIT = 6, MAX_RETRIES = 3, RETRY_DELAY_MS = 400;
  const STORAGE_KEY = "prd_vbd_unified_records_v2";
  const MASTER_PASSWORD = "ASLAM1992";
  const OTHER_PASSWORD = "741152";
  let gpPasswords = {}, records = [], activeGP = "", activeBoundary = "";
  let leafletMap = null, leafletLayer = null, chartInstance = null;
  let busy = false;

  fetch("https://raw.githubusercontent.com/aslamkd/appdata/refs/heads/main/prdDownloadPass.json")
    .then(r => r.ok ? r.json() : {})
    .then(d => { gpPasswords = d || {}; }).catch(() => {});

  const GP_OPTIONS = [
    ["839","KARIMPUR-I"],["840","KARIMPUR-II"],["841","JAMSHERPUR"],
    ["842","MAGHUGARI"],["843","HOGALBARIA"],["844","PIPULBERIA"],
    ["845","HAREKRISHNAPUR"],["846","SHIKARPUR"]
  ];

  const css = `
  #vbdx-root,#vbdx-root *{box-sizing:border-box}
  #vbdx-root{position:fixed;z-index:2147483646;right:16px;bottom:16px;width:300px;max-width:calc(100vw - 20px);font:14px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;color:#172033}
  #vbdx-root button,#vbdx-root input,#vbdx-root select{font:inherit}
  #vbdx-root .vx-shell{background:#fff;border:1px solid #dbe3ef;border-radius:16px;box-shadow:0 12px 40px #0f172a30;overflow:hidden}
  #vbdx-root .vx-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:11px 13px;background:linear-gradient(120deg,#123c75,#1769aa);color:#fff;cursor:move}
  #vbdx-root .vx-brand{font-weight:800;font-size:14px;letter-spacing:.1px;display:flex;align-items:center;gap:8px}
  #vbdx-root .vx-dot{width:8px;height:8px;border-radius:50%;background:#22c55e;display:inline-block}
  #vbdx-root .vx-head-actions{display:flex;gap:5px}
  #vbdx-root .vx-iconbtn{border:0;background:#ffffff24;color:white;border-radius:8px;width:29px;height:28px;cursor:pointer;font-weight:800}
  #vbdx-root .vx-body{padding:12px;max-height:70vh;overflow:auto}
  #vbdx-root .vx-field{display:block;margin:0 0 8px}
  #vbdx-root .vx-field span{display:block;font-size:11px;color:#53627a;font-weight:700;margin-bottom:4px}
  #vbdx-root select,#vbdx-root input[type=date],#vbdx-root input[type=text]{width:100%;min-width:0;border:1px solid #cbd5e1;border-radius:9px;background:#fff;padding:8px 9px;color:#172033;outline:none}
  #vbdx-root .vx-btn{border:1px solid #d3dce8;background:#f8fafc;color:#243247;border-radius:9px;padding:9px 11px;cursor:pointer;font-weight:700;font-size:12px}
  #vbdx-root .vx-btn:disabled{opacity:.55;cursor:not-allowed}
  #vbdx-root .vx-primary{background:#1769aa;color:#fff;border-color:#1769aa}
  #vbdx-root .vx-green{background:#12805c;color:#fff;border-color:#12805c}
  #vbdx-root .vx-red{background:#fff1f2;color:#be123c;border-color:#fecdd3}
  #vbdx-root .vx-actions{display:grid;grid-template-columns:1fr 1fr;gap:7px}
  #vbdx-root .vx-progress{height:8px;border-radius:20px;background:#e8eef6;overflow:hidden;margin:9px 0 4px}
  #vbdx-root .vx-progress>i{display:block;height:100%;width:0;background:linear-gradient(90deg,#0d9488,#22c55e);transition:width .15s}
  #vbdx-root .vx-progressline{display:flex;justify-content:space-between;font-size:11px;color:#64748b}
  #vbdx-root .vx-status{font-size:11px;color:#475569;margin:7px 0;min-height:16px}
  #vbdx-root .vx-filter{border-top:1px solid #e5eaf1;margin-top:10px;padding-top:10px}
  #vbdx-root .vx-filtergrid{display:grid;grid-template-columns:1fr 1fr;gap:7px}
  #vbdx-root .vx-launch{width:100%;margin-top:10px}
  #vbdx-root.vx-collapsed{width:166px}
  #vbdx-root.vx-collapsed .vx-body{display:none}
  #vbdx-root.vx-full{inset:8px!important;width:auto!important;max-width:none!important;bottom:8px!important;right:8px!important;left:8px!important;top:8px!important}
  #vbdx-root.vx-full .vx-shell{height:100%;display:flex;flex-direction:column;border-radius:14px}
  #vbdx-root.vx-full .vx-head{flex:0 0 auto}
  #vbdx-root.vx-full .vx-dashboard{display:block}
  #vbdx-root.vx-full .vx-body{max-height:none;flex:1;overflow:auto;padding:14px;background:#f3f6fb}
  #vbdx-root .vx-dashboard{display:none}
  #vbdx-root.vx-full .vx-dashboard{display:block}
  #vbdx-root .vx-topbar{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:12px}
  #vbdx-root .vx-title{font-size:20px;font-weight:900;color:#142d4e}
  #vbdx-root .vx-subtitle{font-size:11px;color:#64748b}
  #vbdx-root .vx-card{background:#fff;border:1px solid #e1e8f0;border-radius:13px;padding:13px;box-shadow:0 3px 12px #0f172a08;min-width:0}
  #vbdx-root .vx-filters{display:grid;grid-template-columns:repeat(6,minmax(125px,1fr));gap:8px;margin-bottom:12px}
  #vbdx-root .vx-filters label{font-size:11px;font-weight:800;color:#52627a}
  #vbdx-root .vx-stats{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:9px;margin-bottom:12px}
  #vbdx-root .vx-stat small{font-size:11px;color:#64748b;font-weight:700}
  #vbdx-root .vx-stat strong{display:block;font-size:24px;color:#173b68;margin-top:4px;overflow-wrap:anywhere}
  #vbdx-root .vx-grid2{display:grid;grid-template-columns:1.15fr .85fr;gap:12px;margin-bottom:12px}
  #vbdx-root .vx-section-title{font-size:14px;font-weight:900;color:#203653;margin-bottom:10px}
  #vbdx-root .vx-tablewrap{width:100%;overflow:auto;border:1px solid #d7e0eb;border-radius:9px}
  #vbdx-root table{border-collapse:collapse;width:100%;font-size:12px;background:#fff}
  #vbdx-root th,#vbdx-root td{border:1px solid #cbd5e1;padding:7px 8px;text-align:left;white-space:nowrap}
  #vbdx-root th{background:#eaf1f8;color:#243b59;font-weight:900}
  #vbdx-root td.num,#vbdx-root th.num{text-align:center;font-variant-numeric:tabular-nums}
  #vbdx-root tfoot td{background:#f0f5fa;font-weight:900}
  #vbdx-root .vx-muted{color:#64748b}
  #vbdx-root .vx-pill{display:inline-block;border-radius:20px;background:#eaf2ff;color:#18569b;padding:3px 8px;font-size:10px;font-weight:800}
  #vbdx-root .vx-report-actions{display:flex;flex-wrap:wrap;gap:7px;margin:10px 0}
  #vbdx-root #vx-map{height:330px;border-radius:10px;overflow:hidden;background:#e8eef5}
  #vbdx-root .vx-mapwrap{position:relative}
  #vbdx-root .vx-mapfull{position:fixed!important;inset:0!important;height:100vh!important;z-index:2147483647!important;border-radius:0!important}
  #vbdx-root .vx-map-btn{position:absolute;right:8px;top:8px;z-index:500;background:#fff;border:1px solid #ccd5e1;border-radius:7px;padding:6px 9px;font-weight:800;cursor:pointer}
  #vbdx-root .vx-chart{height:270px;position:relative}
  #vbdx-root .vx-chart canvas{width:100%!important;height:100%!important}
  #vbdx-root .vx-empty{padding:25px;text-align:center;color:#64748b}
  #vbdx-root .vx-modal{display:none;position:fixed;inset:0;background:#0b172acc;z-index:2147483647;padding:14px;overflow:auto}
  #vbdx-root .vx-modal.open{display:block}
  #vbdx-root .vx-modalbox{background:#fff;border-radius:12px;max-width:1200px;margin:0 auto;padding:16px;box-shadow:0 20px 60px #0005}
  #vbdx-root .vx-modalhead{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px}
  #vbdx-root .vx-modalbody{overflow:auto;max-height:75vh}
  #vbdx-root .vx-toast{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);background:#132c49;color:#fff;padding:10px 15px;border-radius:9px;z-index:2147483647;font-size:12px;box-shadow:0 5px 20px #0003}
  @media(max-width:850px){#vbdx-root .vx-filters{grid-template-columns:repeat(2,minmax(0,1fr))}#vbdx-root .vx-grid2{grid-template-columns:1fr}#vbdx-root .vx-stats{grid-template-columns:repeat(2,minmax(0,1fr))}}
  @media(max-width:520px){#vbdx-root{right:7px;bottom:7px}#vbdx-root.vx-collapsed{width:150px}#vbdx-root.vx-full{inset:0!important}#vbdx-root.vx-full .vx-shell{border-radius:0}#vbdx-root.vx-full .vx-body{padding:9px}#vbdx-root .vx-filters{grid-template-columns:1fr 1fr}#vbdx-root .vx-title{font-size:17px}#vbdx-root .vx-stat strong{font-size:21px}#vbdx-root .vx-card{padding:10px}}
  @media print{body>*{visibility:hidden!important}#vx-print-root,#vx-print-root *{visibility:visible!important}#vx-print-root{position:absolute;left:0;top:0;width:100%;background:#fff}}
  `;
  const style = document.createElement("style"); style.textContent = css; document.head.appendChild(style);

  const root = document.createElement("div"); root.id = "vbdx-root";
  root.innerHTML = `
  <div class="vx-shell">
    <div class="vx-head" id="vx-drag">
      <div class="vx-brand"><span class="vx-dot"></span> PRD • VBD Survey Suite <span id="vx-busy-dot" style="display:none">⏳</span></div>
      <div class="vx-head-actions">
        <button class="vx-iconbtn" id="vx-full" title="ফুল স্ক্রিন">⛶</button>
        <button class="vx-iconbtn" id="vx-min" title="মিনিমাইজ">−</button>
      </div>
    </div>
    <div class="vx-body">
      <div id="vx-downloader">
        <label class="vx-field"><span>গ্রাম পঞ্চায়েত নির্বাচন</span><select id="vx-gp"><option value="">GP নির্বাচন করুন</option>${GP_OPTIONS.map(([id,n])=>`<option value="${id}">${n}</option>`).join("")}<option value="OTHER">OTHER</option></select></label>
        <div class="vx-actions">
          <button class="vx-btn vx-primary" id="vx-download">⬇ সম্পূর্ণ সার্ভে ডাউনলোড</button>
          <button class="vx-btn" id="vx-kml">🌐 KML ডাউনলোড</button>
        </div>
        <div class="vx-progress"><i id="vx-progress"></i></div>
        <div class="vx-progressline"><span id="vx-progress-count">অপেক্ষমাণ</span><span id="vx-progress-total">0%</span></div>
        <div class="vx-status" id="vx-status">ডাউনলোডের পর তথ্য অটোমেটিক অ্যানালাইসিসে যুক্ত হবে।</div>
        <div class="vx-filter">
          <div style="font-weight:900;font-size:12px;margin-bottom:7px">ডাউনলোড করা ডেটা থেকে বাছাই করে CSV</div>
          <div class="vx-filtergrid">
            <label class="vx-field"><span>তারিখ থেকে</span><select id="vx-dfrom"><option value="">সব</option></select></label>
            <label class="vx-field"><span>তারিখ পর্যন্ত</span><select id="vx-dto"><option value="">সব</option></select></label>
            <label class="vx-field"><span>সংসদ</span><select id="vx-dsansad"><option value="">সব</option></select></label>
            <label class="vx-field"><span>সার্ভেয়ার</span><select id="vx-dsurveyor"><option value="">সব</option></select></label>
          </div>
          <button class="vx-btn vx-green" id="vx-selective" style="width:100%">নির্বাচিত ডেটা CSV</button>
        </div>
        <div style="display:flex;gap:7px;margin-top:9px">
          <button class="vx-btn" id="vx-open-analysis" style="flex:1">📊 অ্যানালাইসিস খুলুন</button>
          <button class="vx-btn vx-red" id="vx-clear">ডেটা মুছুন</button>
        </div>
      </div>

      <section class="vx-dashboard" id="vx-dashboard">
        <div class="vx-topbar">
          <div><div class="vx-title">ভেক্টর কন্ট্রোল সার্ভে অ্যানালাইসিস</div><div class="vx-subtitle" id="vx-heading-sub">ডাউনলোড করা লোকাল ডেটার রিপোর্ট ও জিও-লোকেশন</div></div>
          <div style="display:flex;gap:6px;flex-wrap:wrap"><button class="vx-btn" id="vx-back">← ডাউনলোডার</button><button class="vx-btn" id="vx-expand-map">ম্যাপ দেখুন</button></div>
        </div>
        <div class="vx-filters">
          <label>পঞ্চায়েত<select id="vx-fgp"><option value="">সকল পঞ্চায়েত</option></select></label>
          <label>সার্ভেয়ার<select id="vx-fsurveyor"><option value="">সকল সার্ভেয়ার</option></select></label>
          <label>তারিখ থেকে<input type="date" id="vx-fdatefrom"></label>
          <label>তারিখ পর্যন্ত<input type="date" id="vx-fdateto"></label>
          <label>গ্রাম সংসদ<select id="vx-fsansad"><option value="">সকল সংসদ</option></select></label>
          <label>ডেটা সার্চ<input type="text" id="vx-search" placeholder="নাম / ID / পাড়া"></label>
        </div>
        <div class="vx-stats">
          <div class="vx-card vx-stat"><small>মোট সার্ভে</small><strong id="vx-total">0</strong></div>
          <div class="vx-card vx-stat"><small>লার্ভা পজিটিভ</small><strong id="vx-larvae">0</strong></div>
          <div class="vx-card vx-stat"><small>সন্দেহজনক কাছাকাছি</small><strong id="vx-clusters">0</strong></div>
          <div class="vx-card vx-stat"><small>এলাকার ব্যাসার্ধ</small><strong id="vx-radius">0 km</strong></div>
          <div class="vx-card vx-stat"><small>সার্ভেয়ার</small><strong id="vx-surveyor-count">0</strong></div>
          <div class="vx-card vx-stat"><small>সংসদ</small><strong id="vx-sansad-count">0</strong></div>
        </div>
        <div class="vx-grid2" style="margin-bottom:12px">
          <div class="vx-card"><div class="vx-section-title">📅 সবচেয়ে বেশি কাছাকাছি সার্ভে (তারিখ)</div><div id="vx-cluster-date" class="vx-muted">—</div></div>
          <div class="vx-card"><div class="vx-section-title">🕵️ সবচেয়ে বেশি কাছাকাছি সার্ভে (সার্ভেয়ার)</div><div id="vx-cluster-surveyor" class="vx-muted">—</div></div>
        </div>
        <div class="vx-card" style="margin-bottom:12px"><div class="vx-section-title">⚠️ ২০-এর কম সার্ভে (দিন অনুযায়ী)</div><div class="vx-tablewrap"><table><thead><tr><th>তারিখ</th><th class="num">সংখ্যা</th></tr></thead><tbody id="vx-low-activity"></tbody></table></div></div>
        <div class="vx-card" style="margin-bottom:12px">
          <div class="vx-section-title">📅 দিনভিত্তিক সার্ভেয়ার রিভিউ</div>
          <div class="vx-subtitle" style="margin-bottom:8px">কলামে তারিখের দিন (১–৩১), সারিতে সার্ভেয়ারের নাম; ডানদিকে ও নিচে মোট সংখ্যা।</div>
          <div class="vx-tablewrap" id="vx-matrix-wrap"><div class="vx-empty">ডেটা লোড হলে রিভিউ দেখা যাবে।</div></div>
          <div class="vx-report-actions">
            <button class="vx-btn vx-primary" id="vx-matrix-image">রিভিউ ছবি ডাউনলোড</button>
            <button class="vx-btn" id="vx-matrix-share">ছবি শেয়ার</button>
          </div>
        </div>
        <div class="vx-grid2">
          <div class="vx-card">
            <div class="vx-section-title">সার্ভেয়ার পারফরম্যান্স</div>
            <div class="vx-tablewrap"><table><thead><tr><th>সার্ভেয়ার</th><th class="num">মোট সার্ভে</th><th class="num">সক্রিয় দিন</th><th class="num">গড়/দিন</th></tr></thead><tbody id="vx-performance"></tbody></table></div>
          </div>
          <div class="vx-card">
            <div class="vx-section-title">সংসদ ভিত্তিক অগ্রগতি</div>
            <div class="vx-chart"><canvas id="vx-chart"></canvas></div>
          </div>
        </div>
        <div class="vx-grid2">
          <div class="vx-card">
            <div class="vx-section-title">জিও-লোকেশন ম্যাপ</div>
            <div class="vx-mapwrap"><button class="vx-map-btn" id="vx-map-full">⛶ Fullscreen</button><div id="vx-map"></div></div>
            <div class="vx-subtitle" style="margin-top:7px">লাল: লার্ভা পজিটিভ • নীল: অন্যান্য সার্ভে</div>
          </div>
          <div class="vx-card">
            <div class="vx-section-title">তারিখ অনুযায়ী সার্ভে</div>
            <div class="vx-tablewrap"><table><thead><tr><th>তারিখ</th><th class="num">সার্ভে সংখ্যা</th></tr></thead><tbody id="vx-date-summary"></tbody></table></div>
          </div>
        </div>
        <div class="vx-card">
          <div class="vx-topbar"><div class="vx-section-title" style="margin:0">বিস্তারিত সার্ভে তালিকা</div><span class="vx-pill" id="vx-visible-count">0 records</span></div>
          <div class="vx-report-actions">
            <button class="vx-btn vx-primary" id="vx-preview-pdf">PDF প্রিভিউ / প্রিন্ট</button>
            <button class="vx-btn vx-green" id="vx-export-csv">ফিল্টার করা CSV</button>
          </div>
          <div class="vx-tablewrap"><table><thead><tr><th>তারিখ</th><th>সার্ভেয়ার</th><th>পরিবার প্রধান</th><th>অভিভাবক</th><th>সংসদ</th><th>পাড়া</th><th>লার্ভা</th><th>ম্যাপ</th></tr></thead><tbody id="vx-detail-body"></tbody></table></div>
        </div>
      </section>
    </div>
  </div>
  <div class="vx-modal" id="vx-preview-modal"><div class="vx-modalbox">
    <div class="vx-modalhead"><div><b style="font-size:17px">রিপোর্ট প্রিভিউ</b><div class="vx-subtitle">এই টেবিলটি PDF হিসেবে প্রিন্ট / Save as PDF করতে পারবেন।</div></div>
      <div class="vx-report-actions" style="margin:0"><button class="vx-btn vx-primary" id="vx-print">PDF / প্রিন্ট</button><button class="vx-btn" id="vx-preview-map">ম্যাপ দেখুন</button><button class="vx-btn vx-red" id="vx-close-preview">বন্ধ</button></div>
    </div><div class="vx-modalbody" id="vx-preview-content"></div>
  </div></div>
  <div class="vx-modal" id="vx-map-modal"><div class="vx-modalbox"><div class="vx-modalhead"><b>সার্ভে লোকেশন ম্যাপ</b><button class="vx-btn vx-red" id="vx-close-map">বন্ধ</button></div><div id="vx-map-large" style="height:70vh;border-radius:10px"></div></div></div>
  `;
  document.body.appendChild(root);

  const $ = id => root.querySelector("#" + id);
  const safe = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const norm = v => String(v ?? "").trim();
  const today = () => new Date().toISOString().slice(0,10);
  const filename = s => norm(s).replace(/\s+/g,"_").replace(/[\\/:*?"<>|]/g,"");
  function parseDate(s) {
    s=norm(s); if(!s) return null;
    let m=s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);
    if(m) return `${m[3]}-${m[2].padStart(2,"0")}-${m[1].padStart(2,"0")}`;
    m=s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if(m) return `${m[1]}-${m[2].padStart(2,"0")}-${m[3].padStart(2,"0")}`;
    const d=new Date(s); return isNaN(d)?null:d.toISOString().slice(0,10);
  }
  const dateLabel = iso => { if(!iso)return ""; const [y,m,d]=iso.split("-"); return `${d}/${m}/${y}`; };
  function csvCell(v){ const s=String(v??""); return `"${s.replace(/"/g,'""')}"`; }
  function downloadBlob(blob,name){ const u=URL.createObjectURL(blob),a=document.createElement("a");a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),3000); }
  function toast(msg){const t=document.createElement("div");t.className="vx-toast";t.textContent=msg;root.appendChild(t);setTimeout(()=>t.remove(),2800);}
  function setStatus(s){$("vx-status").textContent=s;}
  function setBusy(v){busy=v;$("vx-busy-dot").style.display=v?"inline":"none";$("vx-download").disabled=v;$("vx-download").textContent=v?"ডাউনলোড চলছে…":"⬇ সম্পূর্ণ সার্ভে ডাউনলোড";}
  let dbPromise=null;
  function openDB(){if(!window.indexedDB)return Promise.reject(new Error("IndexedDB unavailable"));if(dbPromise)return dbPromise;dbPromise=new Promise((resolve,reject)=>{const req=indexedDB.open("PRD_VBD_SURVEY_DB",1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains("kv"))req.result.createObjectStore("kv");};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});return dbPromise;}
  async function readStore(){try{const db=await openDB();const value=await new Promise((resolve,reject)=>{const tx=db.transaction("kv","readonly"),req=tx.objectStore("kv").get("state");req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});if(value){records=Array.isArray(value.records)?value.records:[];activeGP=value.gp||"";activeBoundary=value.boundary||"";return;}}catch(e){}try{const x=JSON.parse(localStorage.getItem(STORAGE_KEY)||"{}");records=Array.isArray(x.records)?x.records:[];activeGP=x.gp||"";activeBoundary=x.boundary||"";}catch{records=[];}}
  async function saveStore(){const state={records,gp:activeGP,boundary:activeBoundary,updated:new Date().toISOString()};try{const db=await openDB();await new Promise((resolve,reject)=>{const tx=db.transaction("kv","readwrite");tx.objectStore("kv").put(state,"state");tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});}catch(e){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}catch(err){setStatus("লোকাল স্টোরেজ পূর্ণ: ডেটা সেভ করা যায়নি। CSV এক্সপোর্ট করে ডেটা মুছুন।");}}}
  async function clearStore(){localStorage.removeItem(STORAGE_KEY);try{const db=await openDB();await new Promise((resolve,reject)=>{const tx=db.transaction("kv","readwrite");tx.objectStore("kv").delete("state");tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});}catch(e){}}
  function setProgress(done,total){$("vx-progress").style.width=(total?done/total*100:0)+"%";$("vx-progress-count").textContent=`${done} / ${total}`;$("vx-progress-total").textContent=(total?Math.round(done/total*100):0)+"%";}

  async function fetchRetry(url,options,retries=MAX_RETRIES){
    for(let i=0;i<=retries;i++){try{const r=await fetch(url,options);if(!r.ok)throw Error("HTTP "+r.status);return await r.json();}catch(e){if(i===retries)return null;await new Promise(r=>setTimeout(r,RETRY_DELAY_MS*(i+1)));}}return null;
  }
  async function fetchDetails(features,contextPath,csrfHeader,csrfToken){
    const out=new Array(features.length);let next=0,done=0;
    async function worker(){while(true){const i=next++;if(i>=features.length)return;const f=features[i];out[i]=await fetchRetry(contextPath+"/getSurveytypeInfo",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded",...(csrfHeader&&csrfToken?{[csrfHeader]:csrfToken}:{})},body:new URLSearchParams({survey_id:f.properties.survey_id,survey_type_id:f.properties.survey_type_id})});done++;setProgress(done,features.length);}}
    await Promise.all(Array.from({length:Math.min(CONCURRENCY_LIMIT,features.length)},worker));return out;
  }
  function toRecord(feature,detail,gp){
    const h=detail?.house||{},p=feature?.properties||{},coords=feature?.geometry?.coordinates||[];
    const lat=Number(h.latitude||coords[1]),lng=Number(h.longitude||coords[0]);
    return {id:norm(p.survey_id),typeId:norm(p.survey_type_id),district:norm(h.district_name),block:norm(h.block_name),gp:norm(h.gram_panchayet_name||gp),sansad:norm(h.gram_sansad_name),para:norm(h.para_name),date:norm(h.house_survey_date),dateISO:parseDate(h.house_survey_date),head:norm(h.family_head_name),guardian:norm(h.family_head_guardian_name),phone:norm(h.hh_contact_no),members:norm(h.total_family_member),larvae:norm(h.is_mosquito_larvae_found),lat:Number.isFinite(lat)?lat:null,lng:Number.isFinite(lng)?lng:null,surveyor:norm(h.surveyor_name),surveyorPhone:norm(h.surveyor_contact_no),boundary:activeBoundary};
  }
  function recordKey(r){return r.id?`${r.boundary||""}:${r.id}`:[r.date,r.surveyor,r.head,r.sansad,r.lat,r.lng].join("|");}
  function dateSort(a,b){return (parseDate(a)||"9999").localeCompare(parseDate(b)||"9999");}
  function currentFiltered(){
    const gp=$("vx-fgp").value,s=$("vx-fsurveyor").value,sa=$("vx-fsansad").value,from=$("vx-fdatefrom").value,to=$("vx-fdateto").value,q=norm($("vx-search").value).toLowerCase();
    return records.filter(r=>(!gp||r.gp===gp)&&(!s||r.surveyor===s)&&(!sa||r.sansad===sa)&&(!from||(r.dateISO||parseDate(r.date))>=from)&&(!to||(r.dateISO||parseDate(r.date))<=to)&&(!q||[r.id,r.head,r.guardian,r.para,r.surveyor,r.sansad].join(" ").toLowerCase().includes(q)));
  }
  function fillSelect(el,values,first){const old=el.value;el.innerHTML=`<option value="">${first}</option>`+[...new Set(values.filter(Boolean))].sort((a,b)=>a.localeCompare(b,"bn",{numeric:true})).map(v=>`<option value="${safe(v)}">${safe(v)}</option>`).join("");if([...el.options].some(o=>o.value===old))el.value=old;}
  function refreshDownloadFilters(){
    const dates=[...new Set(records.map(r=>r.date).filter(Boolean))].sort(dateSort);
    for(const id of ["vx-dfrom","vx-dto"]){const el=$(id),old=el.value;el.innerHTML='<option value="">সব</option>'+dates.map(d=>`<option value="${safe(d)}">${safe(d)}</option>`).join("");if(dates.includes(old))el.value=old;}
    fillSelect($("vx-dsansad"),records.map(r=>r.sansad),"সব");fillSelect($("vx-dsurveyor"),records.map(r=>r.surveyor),"সব");
  }
  function refreshDashboardFilters(){
    fillSelect($("vx-fgp"),records.map(r=>r.gp),"সকল পঞ্চায়েত");
    if(activeGP&&[...$("vx-fgp").options].some(o=>o.value===activeGP))$("vx-fgp").value=activeGP;
    fillSelect($("vx-fsurveyor"),records.map(r=>r.surveyor),"সকল সার্ভেয়ার");
    fillSelect($("vx-fsansad"),records.map(r=>r.sansad),"সকল সংসদ");
    const dates=records.map(r=>r.dateISO||parseDate(r.date)).filter(Boolean).sort();
    if(dates.length){$("vx-fdatefrom").min=dates[0];$("vx-fdatefrom").max=dates.at(-1);$("vx-fdateto").min=dates[0];$("vx-fdateto").max=dates.at(-1);}
  }
  function getDayRange(data){
    const dates=data.map(r=>r.dateISO||parseDate(r.date)).filter(Boolean).sort();
    if(!dates.length)return {start:null,end:null,days:[]};
    const from=$("vx-fdatefrom").value||dates[0],to=$("vx-fdateto").value||dates.at(-1);
    const start=from.slice(0,7),end=to.slice(0,7);
    // Show every calendar day (1..28/29/30/31) for the selected month(s).
    const monthStart=`${start}-01`;
    const lastDay=new Date(Number(end.slice(0,4)),Number(end.slice(5,7)),0).getDate();
    const monthEnd=`${end}-${String(lastDay).padStart(2,"0")}`;
    const days=[];let cursor=new Date(monthStart+"T12:00:00"),last=new Date(monthEnd+"T12:00:00");
    while(cursor<=last&&days.length<370){days.push(cursor.toISOString().slice(0,10));cursor.setDate(cursor.getDate()+1);}
    return {start:from,end:to,days};
  }
  function renderMatrix(data){
    const range=getDayRange(data);
    if(!range.days.length){$("vx-matrix-wrap").innerHTML='<div class="vx-empty">তারিখের তথ্য পাওয়া যায়নি।</div>';return;}
    const by={};data.forEach(r=>{const d=r.dateISO||parseDate(r.date);if(!d||!range.days.includes(d))return;(by[r.surveyor||"নাম নেই"]??={});by[r.surveyor||"নাম নেই"][d]=(by[r.surveyor||"নাম নেই"][d]||0)+1;});
    const names=Object.keys(by).sort((a,b)=>a.localeCompare(b,"bn",{numeric:true}));
    const totals=range.days.map(d=>names.reduce((n,s)=>n+(by[s][d]||0),0));
    let html=`<div style="padding:8px 10px;font-weight:900;text-align:center;background:#f7fafc;border-bottom:1px solid #cbd5e1">${safe($("vx-fgp").value||"সকল পঞ্চায়েত")} — ${dateLabel(range.start)} থেকে ${dateLabel(range.end)}</div><table><thead><tr><th>সার্ভেয়ারের নাম</th>${range.days.map(d=>`<th class="num">${Number(d.slice(8,10))}</th>`).join("")}<th class="num">মোট</th></tr></thead><tbody>`;
    names.forEach(n=>{const total=range.days.reduce((v,d)=>v+(by[n][d]||0),0);html+=`<tr><td><b>${safe(n)}</b></td>${range.days.map(d=>`<td class="num">${by[n][d]||"—"}</td>`).join("")}<td class="num"><b>${total}</b></td></tr>`;});
    html+=`</tbody><tfoot><tr><td>সর্বমোট</td>${totals.map(v=>`<td class="num">${v||"—"}</td>`).join("")}<td class="num">${totals.reduce((a,b)=>a+b,0)}</td></tr></tfoot></table>`;
    $("vx-matrix-wrap").innerHTML=html;
  }
  function distance(lat1,lon1,lat2,lon2){const R=6371,dLat=(lat2-lat1)*Math.PI/180,dLon=(lon2-lon1)*Math.PI/180,a=Math.sin(dLat/2)**2+Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));}
  function findClusterRecords(data){const found=new Set(),grid=new Map(),cell=0.000135;for(const r of data){if(r.lat==null||r.lng==null)continue;const gx=Math.floor(r.lat/cell),gy=Math.floor(r.lng/cell);for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++){const bucket=grid.get(`${r.surveyor}|${gx+dx}|${gy+dy}`)||[];for(const other of bucket){if(distance(r.lat,r.lng,other.lat,other.lng)<0.015){found.add(r);found.add(other);}}}const key=`${r.surveyor}|${gx}|${gy}`;if(!grid.has(key))grid.set(key,[]);grid.get(key).push(r);}return [...found];}
  function renderDashboard(){
    const data=currentFiltered();$("vx-total").textContent=data.length;
    $("vx-larvae").textContent=data.filter(r=>/^(yes|হ্যাঁ|1|true)$/i.test(r.larvae)).length;
    $("vx-surveyor-count").textContent=new Set(data.map(r=>r.surveyor).filter(Boolean)).size;
    $("vx-sansad-count").textContent=new Set(data.map(r=>r.sansad).filter(Boolean)).size;
    const clusters=findClusterRecords(data), clusterDate={},clusterSurveyor={},dayTotals={};
    clusters.forEach(r=>{clusterDate[r.date]=(clusterDate[r.date]||0)+1;clusterSurveyor[r.surveyor]=(clusterSurveyor[r.surveyor]||0)+1;});
    $("vx-clusters").textContent=clusters.length;
    const coords=data.filter(r=>r.lat!=null&&r.lng!=null);
    if(coords.length>1){let minLat=Infinity,maxLat=-Infinity,minLng=Infinity,maxLng=-Infinity;coords.forEach(r=>{minLat=Math.min(minLat,r.lat);maxLat=Math.max(maxLat,r.lat);minLng=Math.min(minLng,r.lng);maxLng=Math.max(maxLng,r.lng);});$("vx-radius").textContent=distance(minLat,minLng,maxLat,maxLng).toFixed(2)+" km";}else $("vx-radius").textContent="0 km";
    const topDate=Object.entries(clusterDate).sort((a,b)=>b[1]-a[1])[0],topSurveyor=Object.entries(clusterSurveyor).sort((a,b)=>b[1]-a[1])[0];
    $("vx-cluster-date").innerHTML=topDate?`<b style="font-size:20px;color:#b7791f">${safe(topDate[0])}</b><br>মোট ${topDate[1]}টি কাছাকাছি অবস্থানের রেকর্ড`:"কোনো ক্লাস্টার পাওয়া যায়নি";
    $("vx-cluster-surveyor").innerHTML=topSurveyor?`<b style="font-size:18px;color:#be185d">${safe(topSurveyor[0]||"নাম নেই")}</b><br>মোট ${topSurveyor[1]}টি কাছাকাছি অবস্থানের রেকর্ড`:"কোনো ক্লাস্টার পাওয়া যায়নি";
    data.forEach(r=>dayTotals[r.date||"তারিখ নেই"]=(dayTotals[r.date||"তারিখ নেই"]||0)+1);
    $("vx-low-activity").innerHTML=Object.entries(dayTotals).filter(x=>x[1]<20).sort((a,b)=>dateSort(a[0],b[0])).map(([d,n])=>`<tr><td>${safe(d)}</td><td class="num" style="color:#dc2626;font-weight:900">${n}</td></tr>`).join("")||'<tr><td colspan="2">২০-এর কম সার্ভে নেই</td></tr>';
    $("vx-visible-count").textContent=`${data.length} records`;
    $("vx-heading-sub").textContent=`${$("vx-fgp").value||"সকল পঞ্চায়েত"} • লোকালি সংরক্ষিত ${records.length}টি রেকর্ড`;
    renderMatrix(data);
    const surv={};data.forEach(r=>{const n=r.surveyor||"নাম নেই";(surv[n]??={total:0,days:new Set()}).total++;const d=r.dateISO||parseDate(r.date);if(d)surv[n].days.add(d);});
    $("vx-performance").innerHTML=Object.entries(surv).sort((a,b)=>b[1].total-a[1].total).map(([n,v])=>`<tr><td>${safe(n)}</td><td class="num">${v.total}</td><td class="num">${v.days.size}</td><td class="num">${v.days.size?(v.total/v.days.size).toFixed(1):"0"}</td></tr>`).join("")||'<tr><td colspan="4" class="vx-muted">কোনো তথ্য নেই</td></tr>';
    const sans={};data.forEach(r=>{if(r.sansad)sans[r.sansad]=(sans[r.sansad]||0)+1;});
    const dates={};data.forEach(r=>{const d=r.date||"তারিখ নেই";dates[d]=(dates[d]||0)+1;});
    $("vx-date-summary").innerHTML=Object.entries(dates).sort((a,b)=>dateSort(a[0],b[0])).map(([d,n])=>`<tr><td>${safe(d)}</td><td class="num">${n}</td></tr>`).join("")||'<tr><td colspan="2">তথ্য নেই</td></tr>';
    const clusterKeys=new Set(clusters.map(recordKey));
    $("vx-detail-body").innerHTML=data.slice().sort((a,b)=>dateSort(a.date,b.date)).map(r=>`<tr${clusterKeys.has(recordKey(r))?' style="background:#fff1f2"':''}><td>${safe(r.date)}</td><td>${safe(r.surveyor)}</td><td>${safe(r.head)}</td><td>${safe(r.guardian)}</td><td>${safe(r.sansad)}</td><td>${safe(r.para)}</td><td>${safe(r.larvae)}</td><td>${r.lat!=null&&r.lng!=null?`<a target="_blank" rel="noopener" href="https://maps.google.com/?q=${r.lat},${r.lng}">ম্যাপ ↗</a>`:"—"}</td></tr>`).join("")||'<tr><td colspan="8" class="vx-empty">কোনো তথ্য পাওয়া যায়নি</td></tr>';
    updateMap(data);updateChart(sans);
  }
  function loadScript(url){return new Promise(resolve=>{const s=document.createElement("script");s.src=url;s.onload=()=>resolve(true);s.onerror=()=>resolve(false);document.head.appendChild(s);});}
  async function updateChart(counts){
    if(!window.Chart){if(!window.__vxChartLoading){window.__vxChartLoading=true;await loadScript("https://cdn.jsdelivr.net/npm/chart.js");}if(!window.Chart){const c=$("vx-chart");if(c)c.innerHTML='<div style="padding:14px;color:#64748b;font-size:12px">চার্ট লাইব্রেরি লোড হয়নি। সংসদভিত্তিক সংখ্যাগুলি নিচের টেবিল/CSV-তে পাওয়া যাবে।</div>';return;}}
    const canvas=$("vx-chart");if(!canvas)return;
    if(chartInstance)chartInstance.destroy();
    chartInstance=new Chart(canvas,{type:"bar",data:{labels:Object.keys(counts),datasets:[{label:"সার্ভে",data:Object.values(counts),backgroundColor:"#4c91d8",borderRadius:5}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});
  }
  async function ensureLeaflet(){
    if(window.L)return true;
    if(!document.querySelector('link[data-vx-leaflet]')){const l=document.createElement("link");l.rel="stylesheet";l.href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";l.dataset.vxLeaflet="1";document.head.appendChild(l);}
    return await loadScript("https://unpkg.com/leaflet@1.9.4/dist/leaflet.js")&&!!window.L;
  }
  async function updateMap(data,targetId="vx-map"){
    const ok=await ensureLeaflet();
    const el=$(targetId);if(!el)return;
    if(!ok){const first=data.find(r=>r.lat!=null&&r.lng!=null);el.innerHTML=first?`<div style="padding:18px;font-size:13px;color:#475569">ইন্টারেক্টিভ ম্যাপ লাইব্রেরি লোড হয়নি। <a target="_blank" rel="noopener" href="https://maps.google.com/?q=${first.lat},${first.lng}">প্রথম লোকেশন Google Maps-এ খুলুন ↗</a><br><br>নিচের বিস্তারিত তালিকার প্রতিটি রেকর্ডের ম্যাপ লিংক ব্যবহার করুন।</div>`:'<div style="padding:18px;color:#64748b">কোনো জিও-লোকেশন পাওয়া যায়নি।</div>';return;}
    if(!el._leaflet_id){const m=window.L.map(el).setView([23.97,88.7],12);window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{attribution:"© OpenStreetMap"}).addTo(m);el._vxMap=m;el._vxLayer=window.L.layerGroup().addTo(m);}
    const m=el._vxMap,layer=el._vxLayer;layer.clearLayers();const bounds=[];
    data.forEach(r=>{if(r.lat==null||r.lng==null)return;const color=/^(yes|হ্যাঁ|1|true)$/i.test(r.larvae)?"#dc2626":"#2563eb";window.L.circleMarker([r.lat,r.lng],{radius:6,color:"#fff",weight:1,fillColor:color,fillOpacity:.88}).bindPopup(`<b>${safe(r.head)}</b><br>${safe(r.surveyor)} | ${safe(r.date)}<br>${safe(r.sansad)}`).addTo(layer);bounds.push([r.lat,r.lng]);});
    if(bounds.length)m.fitBounds(bounds,{padding:[20,20],maxZoom:16});setTimeout(()=>m.invalidateSize(),200);
  }
  function exportCSV(data,name="survey_filtered"){
    const headers=["survey_id","survey_type_id","district_name","block_name","gram_panchayet_name","gram_sansad_name","para_name","survey_date","family_head_name","family_head_guardian_name","hh_contact_no","total_family_member","is_mosquito_larvae_found","latitude","longitude","surveyor_name","surveyor_contact_no","Map"];
    const rows=data.map(r=>[r.id,r.typeId,r.district,r.block,r.gp,r.sansad,r.para,r.date,r.head,r.guardian,r.phone,r.members,r.larvae,r.lat??"",r.lng??"",r.surveyor,r.surveyorPhone,(r.lat!=null&&r.lng!=null?`https://maps.google.com/?q=${r.lat},${r.lng}`:"")].map(csvCell).join(","));
    downloadBlob(new Blob(["\ufeff"+[headers.join(","),...rows].join("\r\n")],{type:"text/csv;charset=utf-8"}),`${filename(name)}_${today()}.csv`);
  }
  function selectedDownloadData(){
    const from=$("vx-dfrom").value,to=$("vx-dto").value,sa=$("vx-dsansad").value,s=$("vx-dsurveyor").value;
    const dates=records.map(r=>r.date).filter(Boolean).sort(dateSort),a=from?dates.indexOf(from):0,b=to?dates.indexOf(to):dates.length-1;
    return records.filter(r=>(r.boundary===activeBoundary)&&(!sa||r.sansad===sa)&&(!s||r.surveyor===s)&&(!from||dates.indexOf(r.date)>=a)&&(!to||dates.indexOf(r.date)<=b));
  }
  function reportHTML(data){
    const gp=$("vx-fgp").value||"সকল পঞ্চায়েত";
    const ds=data.map(r=>r.dateISO||parseDate(r.date)).filter(Boolean).sort();
    const period=ds.length?`${dateLabel(ds[0])} — ${dateLabel(ds.at(-1))}`:"তারিখ অনুপলব্ধ";
    return `<div id="vx-print-root"><style>#vx-print-root{font-family:Arial,sans-serif;color:#111}#vx-print-root h2{text-align:center;margin:0 0 5px;font-size:19px}#vx-print-root p{text-align:center;margin:0 0 14px;font-size:12px}#vx-print-root table{width:100%;border-collapse:collapse;font-size:10px}#vx-print-root th,#vx-print-root td{border:1px solid #64748b;padding:5px;text-align:left}#vx-print-root th{background:#e8eef5}#vx-print-root .rmap{color:#075db5;text-decoration:underline}#vx-print-root .rfoot{margin-top:9px;font-weight:bold;font-size:11px}@media print{@page{size:A4 landscape;margin:10mm}#vx-print-root{width:100%}}</style><h2>${safe(gp)} — ভেক্টর কন্ট্রোল সার্ভে রিপোর্ট</h2><p>সময়সীমা: ${period} | মোট সার্ভে: ${data.length}</p><table><thead><tr><th>তারিখ</th><th>সার্ভেয়ার</th><th>পরিবার প্রধান</th><th>অভিভাবক</th><th>সংসদ</th><th>পাড়া</th><th>লার্ভা</th><th>ম্যাপ</th></tr></thead><tbody>${data.map(r=>`<tr><td>${safe(r.date)}</td><td>${safe(r.surveyor)}</td><td>${safe(r.head)}</td><td>${safe(r.guardian)}</td><td>${safe(r.sansad)}</td><td>${safe(r.para)}</td><td>${safe(r.larvae)}</td><td>${r.lat!=null&&r.lng!=null?`<a class="rmap" href="https://maps.google.com/?q=${r.lat},${r.lng}">ম্যাপ দেখুন</a>`:"—"}</td></tr>`).join("")}</tbody></table><div class="rfoot">সর্বমোট সার্ভে: ${data.length}</div></div>`;
  }
  function openPreview(){const data=currentFiltered();$("vx-preview-content").innerHTML=reportHTML(data);$("vx-preview-modal").classList.add("open");}
  function makeMatrixCanvas(){
    const data=currentFiltered(),range=getDayRange(data);if(!range.days.length)return null;
    const by={};data.forEach(r=>{const d=r.dateISO||parseDate(r.date);if(!d||!range.days.includes(d))return;(by[r.surveyor||"নাম নেই"]??={});by[r.surveyor||"নাম নেই"][d]=(by[r.surveyor||"নাম নেই"][d]||0)+1;});
    const names=Object.keys(by).sort((a,b)=>a.localeCompare(b,"bn",{numeric:true}));
    const colW=36,nameW=170,totalW=65,rowH=34,headH=74,width=nameW+range.days.length*colW+totalW,height=headH+(names.length+1)*rowH+35;
    const scale=2,canvas=document.createElement("canvas");canvas.width=width*scale;canvas.height=height*scale;const c=canvas.getContext("2d");c.scale(scale,scale);c.fillStyle="#fff";c.fillRect(0,0,width,height);
    c.fillStyle="#173b68";c.font="bold 17px sans-serif";c.textAlign="center";c.fillText(`${$("vx-fgp").value||"সকল পঞ্চায়েত"} | ${dateLabel(range.start)} থেকে ${dateLabel(range.end)}`,width/2,25);
    c.font="bold 11px sans-serif";let x=0,y=42;c.fillStyle="#eaf1f8";c.fillRect(0,y,width,32);
    function cell(text,x0,y0,w,h,align="center",bold=false){c.strokeStyle="#9aaabd";c.strokeRect(x0,y0,w,h);c.fillStyle="#243b59";c.font=`${bold?"bold ":""}10px sans-serif`;c.textAlign=align;c.fillText(String(text),align==="left"?x0+6:x0+w/2,y0+h/2+4);}
    cell("সার্ভেয়ার",0,y,nameW,32,"left",true);range.days.forEach((d,i)=>cell(Number(d.slice(8,10)),nameW+i*colW,y,colW,32,"center",true));cell("মোট",nameW+range.days.length*colW,y,totalW,32,"center",true);
    let grand=0;const totals=range.days.map(d=>names.reduce((n,s)=>n+(by[s][d]||0),0));
    names.forEach((n,ri)=>{const yy=y+32+ri*rowH;cell(n,0,yy,nameW,rowH,"left",true);let sum=0;range.days.forEach((d,i)=>{const v=by[n][d]||0;sum+=v;cell(v||"—",nameW+i*colW,yy,colW,rowH);});grand+=sum;cell(sum,nameW+range.days.length*colW,yy,totalW,rowH,"center",true);});
    const yy=y+32+names.length*rowH;cell("সর্বমোট",0,yy,nameW,rowH,"left",true);totals.forEach((v,i)=>cell(v||"—",nameW+i*colW,yy,colW,rowH,"center",true));cell(grand,nameW+range.days.length*colW,yy,totalW,rowH,"center",true);
    return canvas;
  }
  function matrixImage(){const c=makeMatrixCanvas();if(!c){toast("ছবি তৈরির মতো তারিখের ডেটা নেই");return;}c.toBlob(b=>downloadBlob(b,`surveyor_daily_review_${today()}.png`));}
  async function matrixShare(){const c=makeMatrixCanvas();if(!c){toast("ছবি তৈরির মতো ডেটা নেই");return;}c.toBlob(async b=>{const f=new File([b],"surveyor_daily_review.png",{type:"image/png"});if(navigator.canShare?.({files:[f]})){try{await navigator.share({files:[f],title:"Surveyor Daily Review"});}catch(e){}}else{downloadBlob(b,"surveyor_daily_review.png");toast("শেয়ার সাপোর্ট নেই, ছবি ডাউনলোড হয়েছে");}});}
  function openFull(){root.classList.add("vx-full");root.classList.remove("vx-collapsed");$("vx-min").textContent="−";setTimeout(()=>{if(leafletMap)leafletMap.invalidateSize();const m=$("vx-map")._vxMap;if(m)m.invalidateSize();},250);}
  function closeFull(){root.classList.remove("vx-full");}
  function showDashboard(){if(!records.length){toast("আগে সার্ভে ডাউনলোড করুন");return;}openFull();refreshDashboardFilters();renderDashboard();}
  function parseFeaturesData(data){try{return JSON.parse(data.geoJson).features||[];}catch{return [];}}
  async function downloadAll(){
    const ext=$("vx-gp"),boundary=ext.value;if(!boundary){toast("প্রথমে GP নির্বাচন করুন");return;}
    const pageSelect=document.querySelector(".boundaryidpicker2#gppicker")||document.getElementById("gppicker");
    if(!pageSelect){toast("ওয়েব পেজের GP সিলেক্টর পাওয়া যায়নি");return;}
    const opt=pageSelect.options[pageSelect.selectedIndex],pageBoundary=opt?.getAttribute("data-boundary-id"),pageLevel=pageSelect.value;
    if(boundary!=="OTHER"&&(pageBoundary!==boundary)){alert("ওয়েব পেজ ও এক্সটেনশনে একই GP নির্বাচন করুন।");return;}
    const boundaryID=boundary==="OTHER"?pageBoundary:boundary;
    if(!boundaryID||boundaryID==="0"){toast("ওয়েব পেজে GP নির্বাচন করুন");return;}
    const gpName=opt.textContent.trim();
    if(boundary==="OTHER"){const pw=prompt("OTHER GP পাসওয়ার্ড দিন");if(pw!==OTHER_PASSWORD&&pw!==MASTER_PASSWORD){toast("ভুল পাসওয়ার্ড");return;}}
    else if(gpPasswords[boundaryID]){const pw=prompt("পাসওয়ার্ড দিন");if(pw!==gpPasswords[boundaryID]&&pw!==MASTER_PASSWORD){toast("ভুল পাসওয়ার্ড");return;}}
    setBusy(true);setStatus("সার্ভে তালিকা আনা হচ্ছে…");setProgress(0,0);
    try{
      const geo=await fetchRetry(`https://prdvbdrs.in/getGeoJsonDetails?BoundaryID=${encodeURIComponent(boundaryID)}&BoundaryLevelID=${encodeURIComponent(pageLevel)}`,{headers:{"x-requested-with":"XMLHttpRequest"}});
      if(!geo)throw Error("GeoJSON fetch failed");
      const features=parseFeaturesData(geo);if(!features.length){toast("এই GP-তে কোনো সার্ভে পাওয়া যায়নি");return;}
      const csrfHeader=document.querySelector("meta[name='_csrf_header']")?.content,csrfToken=document.querySelector("meta[name='_csrf']")?.content,contextPath=document.getElementById("contextPath")?.value||"";
      const details=await fetchDetails(features,contextPath,csrfHeader,csrfToken);
      activeGP=gpName;activeBoundary=boundaryID;
      const incoming=features.map((f,i)=>toRecord(f,details[i],gpName));
      const merged=new Map();
      records.forEach(r=>merged.set(recordKey(r),r));
      incoming.forEach(r=>merged.set(recordKey(r),r));
      records=[...merged.values()];
      await saveStore();refreshDownloadFilters();refreshDashboardFilters();
      const ok=incoming.filter((r,i)=>!!details[i]).length;
      setStatus(`সম্পূর্ণ: ${incoming.length}টি এন্ট্রি • বিস্তারিত ${ok}টি সফল • লোকাল ডেটায় মোট ${records.length}টি`);
      setProgress(features.length,features.length);
      toast(`${incoming.length}টি সার্ভে ডেটা অ্যানালাইসিসে যুক্ত হয়েছে`);
      // Original full CSV and KML export are preserved as optional outputs.
      exportCSV(incoming,`survey_${filename(gpName)}_download`);
      window.__vxLastFeatures=features.map((f,i)=>({feature:f,detail:details[i]}));
      renderDashboard();
    }catch(e){console.error("VBD download error",e);setStatus("ডাউনলোড ব্যর্থ: "+(e.message||"অজানা সমস্যা"));alert("ডাউনলোড ব্যর্থ হয়েছে। নেটওয়ার্ক ও পেজের GP নির্বাচন পরীক্ষা করে আবার চেষ্টা করুন।");}
    finally{setBusy(false);}
  }
  function downloadKML(){
    if(!records.length){toast("আগে ডেটা ডাউনলোড করুন");return;}
    const esc=s=>String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
    const marks=records.filter(r=>r.lat!=null&&r.lng!=null).map(r=>`<Placemark><name>${esc(r.head)} : ${esc(r.surveyor)}</name><description><![CDATA[সংসদ: ${r.sansad}<br>তারিখ: ${r.date}<br>পরিবার প্রধান: ${r.head}<br>সার্ভেয়ার: ${r.surveyor}<br>লার্ভা: ${r.larvae}]]></description><Point><coordinates>${r.lng},${r.lat},0</coordinates></Point></Placemark>`).join("");
    const xml=`<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>${esc(activeGP)} Survey</name>${marks}</Document></kml>`;
    downloadBlob(new Blob([xml],{type:"application/vnd.google-earth.kml+xml"}),`survey_locations_${filename(activeGP||"GP")}_${today()}.kml`);
  }

  // Header controls and events
  $("vx-min").addEventListener("click",e=>{e.stopPropagation();if(root.classList.contains("vx-full")){closeFull();root.classList.add("vx-collapsed");}else{root.classList.toggle("vx-collapsed");}$("vx-min").textContent=root.classList.contains("vx-collapsed")?"+":"−";});
  $("vx-full").addEventListener("click",()=>root.classList.contains("vx-full")?closeFull():openFull());
  $("vx-drag").addEventListener("dblclick",()=>root.classList.contains("vx-full")?closeFull():openFull());
  $("vx-download").addEventListener("click",downloadAll);
  $("vx-kml").addEventListener("click",downloadKML);
  $("vx-open-analysis").addEventListener("click",showDashboard);
  $("vx-back").addEventListener("click",()=>{closeFull();});
  $("vx-clear").addEventListener("click",async()=>{if(confirm("লোকালি সেভ করা সব সার্ভে ডেটা মুছে ফেলবেন?")){records=[];activeGP="";activeBoundary="";await clearStore();refreshDownloadFilters();renderDashboard();setStatus("লোকাল ডেটা মুছে ফেলা হয়েছে।");toast("ডেটা মুছে ফেলা হয়েছে");}});
  $("vx-selective").addEventListener("click",()=>{const d=selectedDownloadData();if(!d.length){toast("নির্বাচিত ফিল্টারে ডেটা নেই");return;}exportCSV(d,`survey_selected_${filename(activeGP)}`);});
  ["vx-fgp","vx-fsurveyor","vx-fsansad","vx-fdatefrom","vx-fdateto","vx-search"].forEach(id=>$(id).addEventListener(id==="vx-search"?"input":"change",renderDashboard));
  $("vx-export-csv").addEventListener("click",()=>{const d=currentFiltered();if(d.length)exportCSV(d,`vbd_analysis_${filename(activeGP)}`);else toast("এক্সপোর্ট করার ডেটা নেই");});
  $("vx-preview-pdf").addEventListener("click",openPreview);
  $("vx-close-preview").addEventListener("click",()=>$("vx-preview-modal").classList.remove("open"));
  $("vx-print").addEventListener("click",()=>{const w=window.open("","_blank");if(!w){toast("পপ-আপ ব্লক হয়েছে; অনুমতি দিন");return;}w.document.write(`<!doctype html><html lang="bn"><meta charset="utf-8"><title>VBD Report</title><body>${reportHTML(currentFiltered())}<script>window.onload=()=>window.print()<\/script></body></html>`);w.document.close();});
  $("vx-preview-map").addEventListener("click",()=>{$("vx-preview-modal").classList.remove("open");$("vx-map-modal").classList.add("open");updateMap(currentFiltered(),"vx-map-large");});
  $("vx-expand-map").addEventListener("click",()=>{$("vx-map-modal").classList.add("open");updateMap(currentFiltered(),"vx-map-large");});
  $("vx-map-full").addEventListener("click",()=>{$("vx-map").classList.toggle("vx-mapfull");setTimeout(()=>{$("vx-map")._vxMap?.invalidateSize();},250);});
  $("vx-close-map").addEventListener("click",()=>$("vx-map-modal").classList.remove("open"));
  $("vx-matrix-image").addEventListener("click",matrixImage);$("vx-matrix-share").addEventListener("click",matrixShare);

  readStore().then(()=>{refreshDownloadFilters();refreshDashboardFilters();if(records.length){setStatus(`আগের সেভ করা ${records.length}টি রেকর্ড পাওয়া গেছে।`);renderDashboard();}});
  // Drag floating panel by header; full-screen mode stays anchored.
  let drag=null;
  $("vx-drag").addEventListener("pointerdown",e=>{if(root.classList.contains("vx-full")||e.target.closest("button"))return;drag={x:e.clientX,y:e.clientY,right:innerWidth-root.getBoundingClientRect().right,bottom:innerHeight-root.getBoundingClientRect().bottom};$("vx-drag").setPointerCapture(e.pointerId);});
  $("vx-drag").addEventListener("pointermove",e=>{if(!drag)return;root.style.right=Math.max(0,drag.right-(e.clientX-drag.x))+"px";root.style.bottom=Math.max(0,drag.bottom-(e.clientY-drag.y))+"px";});
  $("vx-drag").addEventListener("pointerup",()=>drag=null);
})();
