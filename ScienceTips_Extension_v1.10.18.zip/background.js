const RULE_BASE = 1000;
const RULE_LIMIT = 4000;
const STORAGE_KEY = 'stBlockedScriptUrls';
const BATCH_KEY = 'stBatchDownloadState';
const finalizingDownloads = new Set();

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

async function syncRules(urls) {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const managed = existing.filter(rule => rule.id >= RULE_BASE && rule.id < RULE_LIMIT);
  const unique = [...new Set(urls)].slice(0, RULE_LIMIT - RULE_BASE);
  const addRules = unique.map((url, index) => ({
    id: RULE_BASE + index,
    priority: 1,
    action: { type: 'block' },
    condition: {
      regexFilter: '^' + escapeRegex(url) + '$',
      resourceTypes: ['script']
    }
  }));
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: managed.map(rule => rule.id),
    addRules
  });
  await chrome.storage.local.set({ [STORAGE_KEY]: unique });
  return unique;
}

function normalizedUrl(value) {
  try {
    const url = new URL(String(value).trim());
    url.hash = '';
    if (url.pathname.length > 1) url.pathname = url.pathname.replace(/\/$/, '');
    return url.href;
  } catch { return ''; }
}

async function sendBatchStatus(tabId, text, active, index = 0, total = 0) {
  if (!Number.isInteger(tabId)) return;
  try {
    await chrome.tabs.sendMessage(tabId, { type: 'ST_BATCH_STATUS', text, active, index, total });
  } catch { /* The page may be navigating; its next content-script instance will resume. */ }
}

function encodeHtmlDataUrl(html) {
  const bytes = new TextEncoder().encode(String(html));
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return 'data:text/html;charset=utf-8;base64,' + btoa(binary);
}

async function stopBatch(text = 'Automatic downloads stopped', tabId = null) {
  const data = await chrome.storage.local.get(BATCH_KEY);
  const batch = data[BATCH_KEY];
  if (!batch) return;
  batch.active = false;
  batch.phase = 'stopped';
  await chrome.storage.local.set({ [BATCH_KEY]: batch });
  await sendBatchStatus(tabId ?? batch.tabId, text, false, batch.index || 0, batch.items?.length || 0);
}

async function finishBatchDownload(downloadId) {
  if (finalizingDownloads.has(downloadId)) return;
  finalizingDownloads.add(downloadId);
  try {
  const data = await chrome.storage.local.get(BATCH_KEY);
  const batch = data[BATCH_KEY];
  if (!batch?.active || batch.pendingDownloadId !== downloadId) return;
  const currentIndex = Number(batch.index) || 0;
  const total = batch.items?.length || 0;
  const completedName = batch.items?.[currentIndex]?.title || `item ${currentIndex + 1}`;
  const nextIndex = currentIndex + 1;

  if (nextIndex >= total) {
    batch.active = false;
    batch.phase = 'complete';
    batch.pendingDownloadId = null;
    await chrome.storage.local.set({ [BATCH_KEY]: batch });
    await sendBatchStatus(batch.tabId, `Automatic downloads complete · ${total}/${total} file(s) downloaded`, false, total, total);
    return;
  }

  batch.index = nextIndex;
  batch.pendingDownloadId = null;
  batch.phase = 'navigating';
  await chrome.storage.local.set({ [BATCH_KEY]: batch });
  const next = batch.items[nextIndex];
  await sendBatchStatus(batch.tabId, `Downloaded ${currentIndex + 1}/${total}: ${completedName} · opening ${next.title || 'next page'}`, true, nextIndex, total);
  // The next page is opened only after Chrome marks this file as fully downloaded.
  setTimeout(() => {
    chrome.tabs.update(batch.tabId, { url: next.url }).catch(async error => {
      await stopBatch('Automatic downloads stopped: could not open next page (' + String(error) + ')', batch.tabId);
    });
  }, 650);
  } finally {
    finalizingDownloads.delete(downloadId);
  }
}

chrome.downloads.onChanged.addListener(delta => {
  if (delta.state?.current === 'complete') {
    finishBatchDownload(delta.id).catch(() => {});
  } else if (delta.error?.current) {
    (async () => {
      const data = await chrome.storage.local.get(BATCH_KEY);
      const batch = data[BATCH_KEY];
      if (batch?.active && batch.pendingDownloadId === delta.id) {
        await stopBatch('Automatic downloads stopped: ' + delta.error.current, batch.tabId);
      }
    })().catch(() => {});
  }
});

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  await syncRules(stored[STORAGE_KEY] || []);
});

chrome.runtime.onStartup.addListener(async () => {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  await syncRules(stored[STORAGE_KEY] || []);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'GET_BLOCKED_URLS') {
    chrome.storage.local.get(STORAGE_KEY).then(data => {
      sendResponse({ ok: true, urls: data[STORAGE_KEY] || [] });
    }).catch(error => sendResponse({ ok: false, error: String(error) }));
    return true;
  }

  if (message?.type === 'ST_BATCH_START') {
    (async () => {
      const tabId = sender.tab?.id;
      const currentOrigin = sender.tab?.url ? new URL(sender.tab.url).origin : 'https://www.sciencetips.in';
      if (!Number.isInteger(tabId)) throw new Error('Could not identify the current tab');
      const items = (Array.isArray(message.items) ? message.items : []).map(item => {
        const url = new URL(String(item.url), currentOrigin);
        if (url.origin !== currentOrigin || url.protocol !== 'https:') return null;
        return { title: String(item.title || '').slice(0, 180), url: url.href };
      }).filter(Boolean);
      if (!items.length) throw new Error('No valid same-site preset URLs found');
      const batch = { active: true, phase: 'loading', items, index: 0, tabId, pendingDownloadId: null, startedAt: Date.now() };
      await chrome.storage.local.set({ [BATCH_KEY]: batch });
      await sendBatchStatus(tabId, `Automatic downloads started · ${items.length} item(s)`, true, 0, items.length);
      sendResponse({ ok: true, count: items.length, firstUrl: items[0].url });
    })().catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
    return true;
  }

  if (message?.type === 'ST_BATCH_STOP') {
    stopBatch('Automatic downloads stopped', sender.tab?.id ?? null)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: String(error) }));
    return true;
  }

  if (message?.type === 'ST_BATCH_DOWNLOAD_CURRENT') {
    (async () => {
      const data = await chrome.storage.local.get(BATCH_KEY);
      const batch = data[BATCH_KEY];
      if (!batch?.active) throw new Error('Batch download is not active');
      if (sender.tab?.id !== batch.tabId) throw new Error('Batch is running in a different tab');
      if (Number(message.index) !== Number(batch.index)) throw new Error('The current list index changed; please retry');
      const expected = batch.items?.[batch.index];
      if (!expected || normalizedUrl(expected.url) !== normalizedUrl(message.url)) throw new Error('Current page does not match the next list item');
      if (batch.pendingDownloadId || batch.phase === 'starting') {
        sendResponse({ ok: true, waiting: true });
        return;
      }
      batch.phase = 'starting';
      await chrome.storage.local.set({ [BATCH_KEY]: batch });
      const safeName = String(message.filename || expected.title || 'sciencetips-page.html')
        .replace(/[\\/:*?"<>|]+/g, '-')
        .replace(/[\r\n]+/g, '-')
        .slice(0, 180);
      const url = encodeHtmlDataUrl(message.html || '');
      const downloadId = await chrome.downloads.download({ url, filename: safeName.endsWith('.html') ? safeName : safeName + '.html', saveAs: false, conflictAction: 'uniquify' });
      batch.pendingDownloadId = downloadId;
      batch.phase = 'downloading';
      await chrome.storage.local.set({ [BATCH_KEY]: batch });
      sendResponse({ ok: true, downloadId });
      // Handle the rare case where a tiny data URL completes before pendingDownloadId was saved.
      chrome.downloads.search({ id: downloadId }, results => {
        if (results?.[0]?.state === 'complete') finishBatchDownload(downloadId).catch(() => {});
        else if (results?.[0]?.error) stopBatch('Automatic downloads stopped: ' + results[0].error, batch.tabId).catch(() => {});
      });
    })().catch(async error => {
      await stopBatch('Automatic downloads stopped: ' + String(error?.message || error), sender.tab?.id ?? null).catch(() => {});
      sendResponse({ ok: false, error: String(error?.message || error) });
    });
    return true;
  }

  if (message?.type !== 'TOGGLE_BLOCK') return;
  const url = message.url;
  if (!url || !/^https?:\/\//i.test(url)) {
    sendResponse({ ok: false, error: 'Invalid script URL' });
    return;
  }
  (async () => {
    try {
      const stored = await chrome.storage.local.get(STORAGE_KEY);
      const urls = new Set(stored[STORAGE_KEY] || []);
      if (message.block) urls.add(url); else urls.delete(url);
      const saved = await syncRules([...urls]);
      sendResponse({ ok: true, blocked: saved.includes(url), urls: saved });
    } catch (error) {
      sendResponse({ ok: false, error: String(error) });
    }
  })();
  return true;
});
