const RULE_BASE = 1000;
const RULE_LIMIT = 4000;
const STORAGE_KEY = 'stBlockedScriptUrls';

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

async function syncRules(urls) {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const managed = existing.filter(rule => rule.id >= RULE_BASE && rule.id < RULE_LIMIT);
  const unique = [...new Set(urls)].slice(0, RULE_LIMIT - RULE_BASE);
  const addRules = unique.map((url, index) => ({
    id: RULE_BASE + index,
    priority: 1,
    action: { type: 'block' },
    condition: {
      // Exact URL match; this rule is applied by Chrome before the script can load.
      regexFilter: '^' + escapeRegex(url) + '$',
      resourceTypes: ['script']
    }
  }));
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: managed.map(rule => rule.id),
    addRules
  });
  await chrome.storage.local.set({ [STORAGE_KEY]: unique });
  return unique;
}

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  await syncRules(stored[STORAGE_KEY] || []);
});

chrome.runtime.onStartup.addListener(async () => {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  await syncRules(stored[STORAGE_KEY] || []);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'GET_BLOCKED_URLS') {
    chrome.storage.local.get(STORAGE_KEY).then(data => {
      sendResponse({ ok: true, urls: data[STORAGE_KEY] || [] });
    }).catch(error => sendResponse({ ok: false, error: String(error) }));
    return true;
  }
  if (message?.type !== 'TOGGLE_BLOCK') return;
  const url = message.url;
  if (!url || !/^https?:\/\//i.test(url)) {
    sendResponse({ ok: false, error: 'Invalid script URL' });
    return;
  }
  (async () => {
    try {
      const stored = await chrome.storage.local.get(STORAGE_KEY);
      const urls = new Set(stored[STORAGE_KEY] || []);
      if (message.block) urls.add(url); else urls.delete(url);
      const saved = await syncRules([...urls]);
      sendResponse({ ok: true, blocked: saved.includes(url), urls: saved });
    } catch (error) {
      sendResponse({ ok: false, error: String(error) });
    }
  })();
  return true;
});
