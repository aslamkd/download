(function createDropdownButtonProgress() {
  let gpPasswords = {};

  // Load GP password JSON from GitHub
  fetch("https://raw.githubusercontent.com/aslamkd/appdata/refs/heads/main/prdDownloadPass.json")
    .then(res => res.json())
    .then(data => {
      gpPasswords = data;
    })
    .catch(err => {
      console.error("❌ Failed to load password JSON:", err);
    });

  const container = document.createElement("div");
  container.style.position = "fixed";
  container.style.bottom = "20px";
  container.style.right = "20px";
  container.style.background = "#fff";
  container.style.padding = "10px";
  container.style.border = "1px solid #ccc";
  container.style.zIndex = 9999;
  container.style.fontFamily = "Arial, sans-serif";
  container.style.boxShadow = "0 0 8px rgba(0,0,0,0.2)";

  container.innerHTML = `
    <select id="gppicker_ext" style="margin-bottom:5px;width:200px;">
      <option value="0" data-boundary-id="">Select GP</option>
      <option value="6" data-boundary-id="839">KARIMPUR-I</option>
      <option value="6" data-boundary-id="840">KARIMPUR-II</option>
      <option value="6" data-boundary-id="841">JAMSHERPUR</option>
      <option value="6" data-boundary-id="842">MAGHUGARI</option>
      <option value="6" data-boundary-id="843">HOGALBARIA</option>
      <option value="6" data-boundary-id="844">PIPULBERIA</option>
      <option value="6" data-boundary-id="845">HAREKRISHNAPUR</option>
      <option value="6" data-boundary-id="846">SHIKARPUR</option>
    </select><br>
    <button id="downloadSurveyCsv" style="width:200px;">⬇ Download Survey CSV</button>
    <button id="downloadKml" style="width:200px;margin-top:5px;">⬇ Download KML</button>

    <div id="progressBar" style="width: 100%; background: #eee; display: none; margin-top: 5px; position: relative; height: 20px; border-radius: 4px; overflow: hidden;">
      <div id="progressFill" style="height: 100%; width: 0%; background: #28a745;"></div>
      <div id="progressCount" style="position: absolute; left: 8px; top: 0; height: 100%; display: flex; align-items: center; font-size: 12px; color: #000;"></div>
      <div id="progressTotal" style="position: absolute; right: 8px; top: 0; height: 100%; display: flex; align-items: center; font-size: 12px; color: #000;"></div>
    </div>
  `;
  document.body.appendChild(container);

  document.getElementById("downloadSurveyCsv").addEventListener("click", function () {

const pageSelect = document.querySelector(".boundaryidpicker2#gppicker"); // পেজে আগে থাকা select
const extensionSelect = document.getElementById("gppicker_ext"); // এক্সটেনশনের select

const pageValue = pageSelect.value;
const pageBoundaryId = pageSelect.options[pageSelect.selectedIndex].getAttribute("data-boundary-id");

const extValue = extensionSelect.value;
const extBoundaryId = extensionSelect.options[extensionSelect.selectedIndex].getAttribute("data-boundary-id");

if (pageValue !== extValue || pageBoundaryId !== extBoundaryId) {
  alert("⛔ দুইটি GP সিলেকশন মেলেনি! অনুগ্রহ করে একই GP নির্বাচন করুন।");
  return; // ✅ ডাউনলোড বন্ধ
}




    const gpSelect = document.getElementById("gppicker");
    const selectedOption = gpSelect.options[gpSelect.selectedIndex];
    const boundaryID = selectedOption.getAttribute("data-boundary-id");
    const boundaryLevelID = selectedOption.value;
    const button = this;



    if (!boundaryID || !boundaryLevelID || boundaryID === "0") {
      alert("❗ অনুগ্রহ করে একটি GP নির্বাচন করুন");
      return;
    }

    // ✅ Check password before download
    const correctPassword = gpPasswords[boundaryID];
    if (correctPassword) {
      const input = prompt("🔒 পাসওয়ার্ড দিন:");
      if (input !== correctPassword) {
        alert("❌ ভুল পাসওয়ার্ড");
        return;
      }
    }

    const progressBar = document.getElementById("progressBar");
    const progressFill = document.getElementById("progressFill");

    progressBar.style.display = "block";
    progressFill.style.width = "0%";
    button.textContent = "⬇ Downloading...";

    const url = `https://prdvbdrs.in/getGeoJsonDetails?BoundaryID=${boundaryID}&BoundaryLevelID=${boundaryLevelID}`;

    fetch(url, {
      headers: { "x-requested-with": "XMLHttpRequest" }
    })
      .then(res => {
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        return res.json();
      })
      .then(data => {
        const jsonObject = JSON.parse(data.geoJson);
        const allFeatures = jsonObject.features;

        window.allFeaturesForKML = allFeatures; // ✅ KML ডেটা রেডি রাখো

        const csrfHeader = document.querySelector("meta[name='_csrf_header']")?.content;
        const csrfToken = document.querySelector("meta[name='_csrf']")?.content;
        const contextPath = document.getElementById("contextPath")?.value || "";

        const headers = [
          "survey_id", "survey_type_id", "district_name", "block_name", "gram_panchayet_name",
          "gram_sansad_name", "para_name", "survey_date","family_head_name", "family_head_guardian_name", "hh_contact_no", "total_family_member", "is_mosquito_larvae_found", "latitude", "longitude", "surveyor_name", "surveyor_contact_no", "Map"
        ];
        const csvRows = [headers.join(",")];

        let completed = 0;

        const promises = allFeatures.map(f => {
          const survey_id = f.properties?.survey_id;
          const survey_type_id = f.properties?.survey_type_id;

          return fetch(contextPath + "/getSurveytypeInfo", {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
              ...(csrfHeader && csrfToken ? { [csrfHeader]: csrfToken } : {})
            },
            body: new URLSearchParams({
              survey_id,
              survey_type_id
            })
          })
            .then(res => res.json())
            .then(detail => {
              f.detail = detail;
              const latitude = detail.house?.latitude || "";
  const longitude = detail.house?.longitude || "";
  const mapLink = (latitude && longitude) 
  ? `"=HYPERLINK(""https://www.google.com/maps?q=${latitude},${longitude}"", ""View Map"")"`
  : "";

  

  
             const row = [
  survey_id,
  survey_type_id,
  detail.house?.district_name || "",
  detail.house?.block_name || "",
  detail.house?.gram_panchayet_name || "",
  detail.house?.gram_sansad_name || "",
  detail.house?.para_name || "",
  detail.house?.house_survey_date || "",
  detail.house?.family_head_name || "",
  detail.house?.family_head_guardian_name || "",
  detail.house?.hh_contact_no || "",
  detail.house?.total_family_member || "",
  detail.house?.is_mosquito_larvae_found || "",
  detail.house?.latitude || "",
  detail.house?.longitude || "",
  detail.house?.surveyor_name || "",
  detail.house?.surveyor_contact_no || "",
  mapLink
];

              csvRows.push(row.join(","));
            })
            .catch(() => {})
            .finally(() => {
              completed++;
              const percent = ((completed / allFeatures.length) * 100).toFixed(1);
              progressFill.style.width = percent + "%";
              document.getElementById("progressCount").textContent = completed;
              document.getElementById("progressTotal").textContent = allFeatures.length;
            });
        });

        Promise.all(promises).then(() => {
          const csvContent = csvRows.join("\n");
          const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
          const url = URL.createObjectURL(blob);

          const a = document.createElement("a");
          a.href = url;
          const gpName = selectedOption.textContent.trim().replace(/\s+/g, "_");
          a.download = `survey_details_gp_${gpName}_${boundaryID}.csv`;
          a.click();

          setTimeout(() => {
            progressBar.style.display = "none";
            progressFill.style.width = "0%";
            button.textContent = "⬇ Download Survey CSV";
          }, 1000);
        });
      })
      .catch(() => {
        progressBar.style.display = "none";
        button.textContent = "⬇ Download Survey CSV";
      });
  });

document.getElementById("downloadKml").addEventListener("click", function () {
  if (!window.allFeaturesForKML || window.allFeaturesForKML.length === 0) {
    alert("⛔ দয়া করে প্রথমে Survey CSV ডাউনলোড করুন। তারপর KML ডাউনলোড করুন।");
    return;
  }

  const placemarks = window.allFeaturesForKML.map((f, i) => {
    const lat = f?.geometry?.coordinates?.[1];
    const lng = f?.geometry?.coordinates?.[0];
    const p = f.detail?.house || {};  // ✅ Use actual detailed data loaded during CSV fetch

    if (!lat || !lng) return "";

    const familyHead = p.family_head_name || "Unknown";
    const surveyorFirstName = (p.surveyor_name || "Unknown").split(" ")[0];
    const labelName = `${familyHead} : ${surveyorFirstName}`;

    const description = `
      <b>Gram Sansad:</b> ${p.gram_sansad_name || ""}<br/>
      <b>Para Name:</b> ${p.para_name || ""}<br/>
      <b>Survey Date:</b> ${p.house_survey_date || ""}<br/>
      <b>Family Head:</b> ${p.family_head_name || ""}<br/>
      <b>Guardian Name:</b> ${p.family_head_guardian_name || ""}<br/>
      <b>Contact No:</b> ${p.hh_contact_no || ""}<br/>
      <b>Total Members:</b> ${p.total_family_member || ""}<br/>
      <b>Larvae Found:</b> ${p.is_mosquito_larvae_found || ""}<br/>
      <b>Latitude:</b> ${lat}<br/>
      <b>Longitude:</b> ${lng}<br/>
      <b>Surveyor:</b> ${p.surveyor_name || ""}<br/>
      <b>Surveyor Contact:</b> ${p.surveyor_contact_no || ""}
    `.trim();

    return `
      <Placemark>
        <name>${labelName}</name>
        <description><![CDATA[${description}]]></description>
        <Point>
          <coordinates>${lng},${lat},0</coordinates>
        </Point>
      </Placemark>`;
  }).join("\n");

  const kmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>Survey Locations</name>
    ${placemarks}
  </Document>
</kml>`;

  const blob = new Blob([kmlContent], { type: 'application/vnd.google-earth.kml+xml' });
  const url = URL.createObjectURL(blob);

  const gpName = document.getElementById("gppicker")?.selectedOptions[0]?.textContent.trim().replace(/\s+/g, "_") || "GP";
  const a = document.createElement("a");
  a.href = url;
  a.download = `survey_locations_${gpName}.kml`;
  a.click();
});


})();


