(async () => {
  if (window.__stInspectorLoaded || document.getElementById('st-inspector-panel')) return;
  window.__stInspectorLoaded = true;
  const state = { minimized:false, classes:new Set(), originalDisplay:new WeakMap(), expanded:new Set(), search:'' };
  const panel = document.createElement('section');
  panel.id = 'st-inspector-panel';
  panel.setAttribute('aria-label', 'ScienceTips HTML Inspector');
  panel.innerHTML = `
    <header class="st-head"><div class="st-head-brand"><div class="st-head-title-row"><strong>HTML Inspector</strong><button id="st-open-url-list" class="st-url-list-icon" type="button" title="Paste or edit preset URL list" aria-label="Paste or edit preset URL list">☷</button></div><span id="st-head-filename" title="Current output file name">—.html</span></div><div class="st-head-tools"><button id="st-head-previous" class="st-head-icon" type="button" title="Previous number" aria-label="Previous number" disabled>‹</button><button id="st-head-next" class="st-head-icon" type="button" title="Next number" aria-label="Next number" disabled>›</button><button id="st-head-download" class="st-head-icon" type="button" title="Download current HTML" aria-label="Download current HTML">⇩</button><label id="st-min-preview-toggle" title="Show preview while minimized"><input id="st-min-preview" type="checkbox" checked> Preview</label><button id="st-min" title="Minimize" aria-label="Minimize">−</button><button id="st-close" title="Close" aria-label="Close">×</button></div></header>
    <div id="st-url-list-modal" class="st-url-list-modal st-hidden" role="dialog" aria-modal="true" aria-labelledby="st-url-list-modal-title">
      <div class="st-url-list-dialog">
        <div class="st-url-list-dialog-head"><strong id="st-url-list-modal-title">Preset URL list</strong><button id="st-url-list-modal-close" type="button" title="Close" aria-label="Close">×</button></div>
        <p>প্রতি লাইনে শিরোনাম ও লিংক দিন: <code>কষে দেখি 1.1, /wbbse-solutions/class-7/math/koshe-dekhi-1.1/</code>। Next/Previous তালিকার ক্রম অনুসরণ করবে এবং শিরোনাম ডাউনলোড ফাইলের নামে ব্যবহার হবে।</p>
        <textarea id="st-url-list-modal-text" rows="9" spellcheck="false" placeholder="Title 1, /path/to/page/&#10;Title 2, /path/to/next-page/"></textarea>
        <div class="st-url-list-dialog-actions"><button id="st-url-list-modal-cancel" type="button">Cancel</button><button id="st-url-list-modal-save" type="button" class="st-primary">Save list</button></div>
      </div>
    </div>
    <div id="st-body">
      <nav class="st-tabs"><button data-tab="scripts" class="active">External JS</button><button data-tab="classes">Classes / HTML</button></nav>
      <section class="st-section" id="st-scripts"><p class="st-help">External script URLs found on this page. Select scripts to block them before the next reload.</p><div class="st-actions st-script-actions"><button id="st-script-all" type="button">Select all</button><button id="st-script-none" type="button">Deselect all</button></div><div id="st-script-list"></div><button id="st-reload" class="st-primary">Reload page with selected scripts blocked</button></section>
      <section class="st-section st-hidden" id="st-classes"><p class="st-help">Class frequency is shown beside each name. Expand a parent to see child classes repeated inside it. The preview uses the page's CSS; copied output contains HTML only.</p><input id="st-search" type="search" placeholder="Search classes…"><div class="st-actions"><button id="st-all">Select all</button><button id="st-none">Clear all</button><button id="st-reset">Reset visibility</button></div><div id="st-class-list"></div><div class="st-copybar"><span id="st-count"></span><button id="st-copy" class="st-primary">Copy selected HTML</button></div><div class="st-preview-tabs"><button id="st-show-preview" class="active">HTML Preview</button><button id="st-show-source">HTML Source</button><button id="st-show-css">CSS Section</button></div><div class="st-export-options"><strong>Output options</strong><label><input id="st-convert-align" type="checkbox" checked> Convert align/align* to one array display block</label><label><input type="radio" name="st-copy-mode" value="html" checked> Copy HTML only</label><label><input type="radio" name="st-copy-mode" value="both"> Copy CSS + HTML</label><label><input id="st-copy-mathjax" type="checkbox"> Include MathJax setup in copied code</label><hr><label><input id="st-download-css" type="checkbox" checked> Include CSS in downloaded HTML</label><label><input id="st-download-mathjax" type="checkbox" checked> Include MathJax 2.7.2 in downloaded HTML</label><label class="st-filename-label">File name <input id="st-filename" type="text" spellcheck="false" autocomplete="off" placeholder="newname"></label><label class="st-filename-label">Manual file name prefix (optional) <input id="st-prefix" type="text" spellcheck="false" autocomplete="off" placeholder="demo_"></label><div class="st-url-prefix-box"><div class="st-url-prefix-heading">Auto prefix from URL (wrap the required part in *)</div><div class="st-url-prefix-row"><input id="st-url-pattern" type="text" spellcheck="false" autocomplete="off" aria-label="URL pattern" placeholder="https://example.com/*2026*/english/"><input id="st-url-separator" type="text" spellcheck="false" autocomplete="off" aria-label="Separator after extracted URL text" placeholder="_" value="_" title="Text to add after the extracted URL part"></div><div class="st-url-prefix-actions"><button id="st-url-current" type="button">Use current URL</button><button id="st-url-apply" type="button" class="st-primary">Apply</button></div><label class="st-code-label st-url-list-label">Preset URL list (Title, URL — one item per line)<textarea id="st-url-list" rows=4 spellcheck="false" placeholder="কষে দেখি 1.1, /wbbse-solutions/class-7/math/koshe-dekhi-1.1/&#10;কষে দেখি 1.2, /wbbse-solutions/class-7/math/koshe-dekhi-1.2/&#10;নিজে করি 1.1, /wbbse-solutions/class-7/math/nije-kori-1.1/"></textarea></label><div class="st-url-numeric-nav"><span id="st-url-current-number" class="st-url-current-number">Number: —</span><button id="st-url-previous" type="button" disabled>‹ Previous</button><button id="st-url-next" type="button" disabled>Next ›</button></div><div id="st-url-prefix-preview" class="st-url-prefix-preview">Generated prefix: —</div></div><div id="st-filename-preview" class="st-filename-preview">Output file: —</div><label class="st-code-label">Extra code inside &lt;head&gt; <textarea id="st-head-extra" rows="3" spellcheck="false" placeholder="Optional script/link tags"></textarea></label><label class="st-code-label">Extra code before &lt;/body&gt; <textarea id="st-body-extra" rows="4" spellcheck="false" placeholder="<script src=&quot;https://cdn.jsdelivr.net/gh/aslamkd/MadhyamikGanitprabha@main/koshe-dekhi-tools.js&quot; charset=&quot;utf-8&quot;></script>"></textarea><button id="st-body-extra-default" type="button" class="st-body-extra-default">Restore default script</button></label><label class="st-code-label">Additional CSS (applied to every downloaded HTML file) <textarea id="st-additional-css" rows="3" spellcheck="false" placeholder="body{font-family:system-ui,-apple-system,&quot;Noto Serif Bengali&quot;,&quot;Segoe UI&quot;,sans-serif;}"></textarea></label><button id="st-download" class="st-primary">Download HTML file</button></div><p class="st-help">Options are applied when copying or downloading. MathJax 2.7.2 is loaded immediately (not on scroll). MathJax rendering requires internet access.</p><iframe id="st-preview" title="HTML preview" sandbox="allow-scripts allow-same-origin"></iframe><textarea id="st-output" placeholder="HTML source will appear here…" spellcheck="false"></textarea><textarea id="st-css-output" class="st-hidden" placeholder="Relevant CSS (minified) will appear here…" spellcheck="false"></textarea></section>
      <footer id="st-status" aria-live="polite">Ready</footer>
    </div>`;
  // Mount inside <body> so the inspector, its textareas, and preview live in the
  // normal document tree. Fall back temporarily to <html> only until <body> exists.
  const mountPanel = () => {
    const target = document.body || document.documentElement;
    if (!target) {
      document.addEventListener('DOMContentLoaded', mountPanel, { once: true });
      return false;
    }
    if (!panel.isConnected || panel.parentElement !== target) target.appendChild(panel);
    panel.style.setProperty('display', 'flex', 'important');
    panel.classList.remove('st-panel-hidden');
    return true;
  };
  mountPanel();
  // Clicking the extension toolbar icon opens its popup; the popup sends these
  // messages so users can show/hide the inspector on the current ScienceTips page.
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === 'ST_INSPECTOR_SHOW') {
      mountPanel();
      sendResponse({ ok: true, visible: true });
    } else if (message?.type === 'ST_INSPECTOR_TOGGLE') {
      if (!panel.isConnected) {
        mountPanel();
        sendResponse({ ok: true, visible: true });
      } else {
        const hidden = panel.style.display === 'none' || panel.classList.contains('st-panel-hidden');
        if (hidden) mountPanel();
        else { panel.style.display = 'none'; panel.classList.add('st-panel-hidden'); }
        sendResponse({ ok: true, visible: hidden });
      }
    }
    return true;
  });
  const $ = s => panel.querySelector(s);
  const status = msg => { $('#st-status').textContent = msg; };
  const allElements = [...document.querySelectorAll('body *')].filter(el => el !== panel && !panel.contains(el) && !el.closest('#st-inspector-panel'));
  const classNames = [...new Set(allElements.flatMap(el => [...el.classList]).filter(Boolean))];
  const frequency = new Map(classNames.map(c => [c, allElements.filter(el => el.classList.contains(c)).length]));
  // Store class choices by origin, not by pathname, so the same choices follow
  // the user between year-specific pages such as /2026/english/ and /2020/english/.
  const preferenceKey = 'stClassChoices:' + location.origin;
  const legacyPreferenceKey = 'stClasses:' + location.origin + location.pathname;
  const [savedPreferences, exportSettingsResult] = await Promise.all([
    chrome.storage.local.get(null),
    chrome.storage.local.get('stExportSettings:v1')
  ]);
  const savedChoices = savedPreferences[preferenceKey];
  const legacyClassKeys = Object.keys(savedPreferences).filter(key => key.startsWith('stClasses:' + location.origin));
  const exportSettingsKey = 'stExportSettings:v1';
  const DEFAULT_BODY_EXTRA = '<script src="https://cdn.jsdelivr.net/gh/aslamkd/MadhyamikGanitprabha@main/koshe-dekhi-tools.js" charset="utf-8"></script>';
  // Keep the script editable in the Extra code before </body> textarea. An intentionally empty saved value is respected.
  const DEFAULT_ADDITIONAL_CSS = 'body{font-family:"Noto Serif Bengali",serif;}';
  const exportSettings = exportSettingsResult[exportSettingsKey] || { prefix: '', filename: '', headExtra: '', bodyExtra: DEFAULT_BODY_EXTRA, additionalCss: DEFAULT_ADDITIONAL_CSS, urlPattern: location.href, urlSeparator: '_', urlList: '' };
  if (typeof exportSettings.bodyExtra !== 'string') exportSettings.bodyExtra = DEFAULT_BODY_EXTRA;
  if (typeof exportSettings.additionalCss !== 'string') exportSettings.additionalCss = DEFAULT_ADDITIONAL_CSS;
  if (typeof exportSettings.urlPattern !== 'string') exportSettings.urlPattern = location.href;
  if (typeof exportSettings.urlSeparator !== 'string') exportSettings.urlSeparator = '_';
  if (typeof exportSettings.urlList !== 'string') exportSettings.urlList = '';

  // Keep the user's starred dynamic position(s) as a reusable URL template.
  // First try an exact structural match. If other URL parts changed too, fall
  // back to the same path-segment position(s) on the same site.
  function syncPatternWithCurrentUrl(pattern, currentUrl) {
    // Always seed the box with the actual page URL. If a starred template was
    // saved earlier, the matching/fallback logic below carries its starred
    // position(s) onto this URL; without a saved marker there is no preference
    // to infer, so show the current URL unmarked for the user to mark once.
    if (typeof pattern !== 'string' || !pattern.includes('*')) return currentUrl;
    const chunks = pattern.split('*');
    if (chunks.length < 3 || chunks.length % 2 === 0) return pattern;
    const escaped = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    let source = '^';
    for (let i = 0; i < chunks.length; i++) {
      source += i % 2 === 0 ? escaped(chunks[i]) : '([^/?#&]+)';
    }
    source += '$';
    try {
      const match = currentUrl.match(new RegExp(source));
      if (match) {
        let updated = chunks[0];
        for (let i = 1; i < chunks.length; i += 2) updated += '*' + (match[(i + 1) / 2] || chunks[i]) + '*' + chunks[i + 1];
        return updated;
      }
    } catch { /* Try path-position fallback below. */ }

    // Fallback: preserve the marked path segment index, e.g. /.../*2026*/english/
    // becomes /.../*2020*/english/ even if another unmarked URL segment changed.
    try {
      const oldUrl = new URL(pattern.replace(/\*([^*]+)\*/g, '$1'));
      const newUrl = new URL(currentUrl);
      if (oldUrl.origin !== newUrl.origin) return pattern;
      const oldParts = oldUrl.pathname.split('/');
      const newParts = newUrl.pathname.split('/');
      if (oldParts.length !== newParts.length) return pattern;
      const marked = [...pattern.matchAll(/\*([^*]+)\*/g)];
      if (!marked.length) return pattern;
      let updatedUrl = currentUrl;
      // Only path-contained markers are remapped by segment index. Process from
      // right to left so replacing a marker cannot shift later string offsets.
      const replacements = [];
      for (const marker of marked) {
        const before = pattern.slice(0, marker.index);
        const prefixUrl = new URL(before.replace(/\*([^*]+)\*/g, '$1') + marker[1] + pattern.slice(marker.index + marker[0].length).replace(/\*([^*]+)\*/g, '$1'));
        const oldPathBefore = before.split(oldUrl.origin)[1] || before;
        const segmentIndex = oldParts.findIndex((part, idx) => {
          const segmentStart = oldParts.slice(0, idx).join('/').length + (idx ? 1 : 0);
          return marker.index >= pattern.indexOf(oldUrl.pathname) + segmentStart && marker.index <= pattern.indexOf(oldUrl.pathname) + segmentStart + part.length;
        });
        if (segmentIndex < 0 || !newParts[segmentIndex]) continue;
        const pathStart = updatedUrl.indexOf(newUrl.pathname);
        const targetPart = newParts[segmentIndex];
        const targetStart = newUrl.pathname.split('/').slice(0, segmentIndex).join('/').length + (segmentIndex ? 1 : 0);
        replacements.push({ start: pathStart + targetStart, end: pathStart + targetStart + targetPart.length, value: targetPart });
      }
      replacements.sort((a, b) => b.start - a.start).forEach(r => { updatedUrl = updatedUrl.slice(0, r.start) + '*' + r.value + '*' + updatedUrl.slice(r.end); });
      return replacements.length ? updatedUrl : pattern;
    } catch { return pattern; }
  }
  const syncedPattern = syncPatternWithCurrentUrl(exportSettings.urlPattern, location.href);
  if (syncedPattern !== exportSettings.urlPattern) exportSettings.urlPattern = syncedPattern;

  // Migrate the previous pathname-specific list once, then preserve a boolean
  // per class name. Known unchecked classes stay unchecked on every new page.
  let classChoices = savedChoices && typeof savedChoices === 'object' && !Array.isArray(savedChoices) ? { ...savedChoices } : null;
  if (!classChoices) {
    classChoices = {};
    if (legacyClassKeys.length) {
      // Older versions stored only selected class names per pathname. Union
      // them across visited pages so any previously selected class is retained.
      const previouslySelected = new Set(legacyClassKeys.flatMap(key => Array.isArray(savedPreferences[key]) ? savedPreferences[key] : []));
      classNames.forEach(c => { classChoices[c] = previouslySelected.has(c); });
    } else {
      // First run: preserve the old default of selecting all classes.
      classNames.forEach(c => { classChoices[c] = true; });
    }
    await chrome.storage.local.set({ [preferenceKey]: classChoices });
  }
  classNames.forEach(c => {
    // Previously known choices always win. New classes default to unchecked.
    if (Object.prototype.hasOwnProperty.call(classChoices, c) && classChoices[c]) state.classes.add(c);
  });
  const saveClassPreferences = () => {
    const updated = { ...classChoices };
    classNames.forEach(c => { updated[c] = state.classes.has(c); });
    classChoices = updated;
    chrome.storage.local.set({ [preferenceKey]: updated });
    updateFilenamePreview();
  };
  const blockedResult = await chrome.runtime.sendMessage({ type: 'GET_BLOCKED_URLS' }).catch(() => ({ urls: [] }));
  const blockedUrls = new Set(blockedResult?.urls || []);
  const scriptUrls = [...new Set([
    ...[...document.scripts].map(s => s.src).filter(src => { try { return src && new URL(src).origin !== location.origin; } catch { return false; } }),
    ...blockedUrls
  ])].sort();
  const scriptList = $('#st-script-list');
  if (!scriptUrls.length) scriptList.innerHTML = '<p class="st-empty">No external script URLs found in the live DOM and no saved block rules.</p>';
  scriptUrls.forEach(url => {
    const row = document.createElement('label'); row.className = 'st-script-row';
    const cb = document.createElement('input'); cb.type='checkbox'; cb.dataset.url=url; cb.checked=blockedUrls.has(url);
    const details = document.createElement('span'); details.className='st-url'; details.textContent=url; details.title=url;
    const copy = document.createElement('button'); copy.type='button'; copy.textContent='Copy link'; copy.className='st-small';
    copy.addEventListener('click', async e => { e.preventDefault(); try { await navigator.clipboard.writeText(url); status('Script URL copied'); } catch { status('Clipboard permission unavailable'); } });
    cb.addEventListener('change', async () => {
      const res = await chrome.runtime.sendMessage({type:'TOGGLE_BLOCK', url, block:cb.checked});
      if (!res?.ok) { cb.checked=!cb.checked; status('Could not update block rule: ' + (res?.error || 'unknown error')); }
      else status(cb.checked ? 'Block saved; reload to prevent the script loading' : 'Block removed; reload to allow the script');
    });
    row.append(cb, details, copy); scriptList.appendChild(row);
  });
  async function setAllScriptBlocks(shouldBlock) {
    const checkboxes = [...scriptList.querySelectorAll('input[type="checkbox"][data-url]')];
    const button = shouldBlock ? $('#st-script-all') : $('#st-script-none');
    button.disabled = true;
    let changed = 0;
    for (const cb of checkboxes) {
      if (cb.checked === shouldBlock) continue;
      const res = await chrome.runtime.sendMessage({ type: 'TOGGLE_BLOCK', url: cb.dataset.url, block: shouldBlock }).catch(() => null);
      if (res?.ok) { cb.checked = shouldBlock; changed++; }
    }
    button.disabled = false;
    status(`${shouldBlock ? 'Selected and blocked' : 'Deselected and unblocked'} ${changed} script URL(s). Reload to apply.`);
  }
  $('#st-script-all').addEventListener('click', () => setAllScriptBlocks(true));
  $('#st-script-none').addEventListener('click', () => setAllScriptBlocks(false));

  // Associate each class with its most common nearest ancestor class when that relationship repeats.
  const parentVotes = new Map(classNames.map(c => [c, new Map()]));
  allElements.forEach(el => {
    if (!el.classList.length) return;
    let ancestor = el.parentElement;
    while (ancestor && !panel.contains(ancestor)) {
      if (ancestor.classList?.length) {
        for (const childClass of el.classList) {
          for (const parentClass of ancestor.classList) {
            if (childClass === parentClass) continue;
            // Defensive guard: a class may be introduced/changed while the page is being scanned.
            // Never call .set() on an absent vote map.
            let votes = parentVotes.get(childClass);
            if (!votes) {
              votes = new Map();
              parentVotes.set(childClass, votes);
            }
            votes.set(parentClass, (votes.get(parentClass) || 0) + 1);
          }
        }
        break;
      }
      ancestor = ancestor.parentElement;
    }
  });
  const parentOf = new Map();
  for (const child of classNames) {
    const votes = [...(parentVotes.get(child) || new Map()).entries()].sort((a,b)=>b[1]-a[1] || (frequency.get(b[0])||0)-(frequency.get(a[0])||0));
    const best = votes.find(([p,n]) => n >= 2 && (frequency.get(p)||0) >= 1);
    if (best) parentOf.set(child, best[0]);
  }
  // Break possible parent cycles deterministically.
  for (const c of classNames) {
    const seen = new Set([c]); let p = parentOf.get(c);
    while (p) { if (seen.has(p)) { parentOf.delete(c); break; } seen.add(p); p = parentOf.get(p); }
  }
  const children = new Map(classNames.map(c => [c, []]));
  classNames.forEach(c => { const p=parentOf.get(c); if (p && children.has(p)) children.get(p).push(c); });
  const sortClasses = arr => arr.sort((a,b)=>(frequency.get(b)||0)-(frequency.get(a)||0) || a.localeCompare(b));
  children.forEach(sortClasses);
  const roots = sortClasses(classNames.filter(c => !parentOf.has(c) && (children.get(c) || []).length > 0));
  // CSS frequency bands: high-frequency classes are vivid; counts remain explicit for clarity.
  function frequencyBand(c) { const n=frequency.get(c)||0; const max=Math.max(1,...frequency.values()); const ratio=n/max; return ratio>.55?'freq-high':ratio>.2?'freq-mid':'freq-low'; }
  const classList = $('#st-class-list');
  function renderClassTree() {
    classList.replaceChildren();
    const query = state.search.toLowerCase();
    const visible = new Set();
    if (!query) classNames.forEach(c=>visible.add(c));
    else {
      classNames.filter(c=>c.toLowerCase().includes(query)).forEach(c=>{ visible.add(c); let p=parentOf.get(c); while(p){visible.add(p);p=parentOf.get(p);} });
    }
    function node(c, depth=0) {
      if (!visible.has(c)) return;
      const row=document.createElement('div'); row.className='st-tree-row '+frequencyBand(c); row.style.setProperty('--depth',depth);
      const kids=(children.get(c)||[]).filter(x=>visible.has(x));
      if(kids.length){ const exp=document.createElement('button'); exp.className='st-expand'; exp.textContent=state.expanded.has(c)||query?'▾':'▸'; exp.title='Expand/collapse child classes'; exp.addEventListener('click',()=>{if(state.expanded.has(c))state.expanded.delete(c);else state.expanded.add(c);renderClassTree();}); row.appendChild(exp); }
      else { const spacer=document.createElement('span'); spacer.className='st-expand-space'; row.appendChild(spacer); }
      const cb=document.createElement('input'); cb.type='checkbox'; cb.checked=state.classes.has(c); cb.title='Toggle visibility and include class in HTML selection';
      cb.addEventListener('change',()=>{if(cb.checked)state.classes.add(c);else state.classes.delete(c);applyVisibility();updateCount();saveClassPreferences();refreshOutput();});
      const name=document.createElement('button'); name.type='button'; name.className='st-class-name'; name.textContent='.'+c; name.title='Click to select this class alone for HTML output';
      name.addEventListener('click',()=>{state.classes.clear();state.classes.add(c);renderClassTree();applyVisibility();updateCount();saveClassPreferences();refreshOutput();status('Selected class .'+c+' for HTML preview/copy');});
      const count=document.createElement('span'); count.className='st-frequency'; count.textContent=String(frequency.get(c)||0); count.title='Number of elements using this class';
      row.append(cb,name,count); classList.appendChild(row);
      if(kids.length && (state.expanded.has(c)||query)) kids.forEach(child=>node(child,depth+1));
    }
    roots.forEach(c=>node(c));
    $('#st-count').textContent=`${classNames.length} classes · ${state.classes.size} selected`;
  }
  function applyVisibility() {
    allElements.forEach(el => {
      if (!state.originalDisplay.has(el)) state.originalDisplay.set(el, el.style.getPropertyValue('display'));
      const classes = [...el.classList];
      if (classes.length && !classes.some(c => state.classes.has(c))) el.style.setProperty('display','none','important');
      else { const old=state.originalDisplay.get(el); if (old) el.style.setProperty('display',old); else el.style.removeProperty('display'); }
    });
  }
  function updateCount(){ $('#st-count').textContent = `${classNames.length} classes · ${state.classes.size} selected`; }
  function getSelectedElements() {
    const chosen=[...state.classes];
    let els=chosen.length===0?[]:allElements.filter(el=>[...el.classList].some(c=>chosen.includes(c)));
    return els.filter(el=>!els.some(other=>other!==el&&other.contains(el)));
  }
  function cleanHtml(el) {
    const clone=el.cloneNode(true);
    clone.querySelectorAll('script,style,link[rel~="stylesheet"],iframe,object,embed').forEach(n=>n.remove());
    [clone,...clone.querySelectorAll('*')].forEach(n=>{ [...n.attributes].forEach(a=>{ if(a.name.toLowerCase()==='style'||a.name.toLowerCase().startsWith('on')) n.removeAttribute(a.name); }); });
    return clone.outerHTML;
  }
  // Static fallback for the solution-number badge. Literal labels such as '(ii)' are kept as HTML text.
  const SOL_BADGE_CSS = '.sol-badge{display:inline-block;background:#2563eb;color:#fff;padding:4px 14px;border-radius:20px;font-size:.85rem;font-weight:700;letter-spacing:.5px;box-shadow:0 1px 2px rgba(0,0,0,.12);margin-bottom:1rem}';
  function solBadgeCssIfNeeded(roots) {
    const hasBadge = roots.some(root => root.matches?.('.sol-badge') || root.querySelector?.('.sol-badge'));
    return hasBadge ? SOL_BADGE_CSS : '';
  }
  function minifyCss(css) {
    return css.replace(/\/\*[\s\S]*?\*\//g,'').replace(/\s+/g,' ').replace(/\s*([{}:;,>+~])\s*/g,'$1').replace(/;}/g,'}').trim();
  }
  function extractRelevantCss(selectedRoots) {
    const targets=[];
    selectedRoots.forEach(root=>targets.push(root,...root.querySelectorAll('*')));
    const targetSet=[...new Set(targets)];
    const chunks=[];
    const ruleMatches = rule => {
      if (!rule.selectorText) return false;
      try { return targetSet.some(el=>{ try{return el.matches(rule.selectorText)}catch{return false} }); } catch { return false; }
    };
    const walkRules = (rules, prefix='') => {
      for (const rule of [...rules]) {
        if (rule.type === CSSRule.STYLE_RULE && ruleMatches(rule)) chunks.push(prefix + rule.cssText);
        else if (rule.type === CSSRule.MEDIA_RULE || rule.type === CSSRule.SUPPORTS_RULE || rule.type === CSSRule.LAYER_BLOCK_RULE || rule.type === CSSRule.CONTAINER_RULE) {
          const before=chunks.length; walkRules(rule.cssRules, '');
          if (chunks.length>before) { const inner=chunks.splice(before).join(''); const atName = rule.type===CSSRule.MEDIA_RULE?'@media':rule.type===CSSRule.SUPPORTS_RULE?'@supports':rule.type===CSSRule.CONTAINER_RULE?'@container':'@layer'; chunks.push(`${atName} ${rule.conditionText || ''}{${inner}}`); }
        } else if (rule.type === CSSRule.FONT_FACE_RULE) {
          // Keep @font-face declarations when selected rules reference a font family.
          const fontText=rule.cssText;
          if (chunks.some(c=>/font-family/i.test(c)) && /font-family/i.test(fontText)) chunks.push(fontText);
        }
      }
    };
    for (const sheet of [...document.styleSheets]) {
      try { walkRules(sheet.cssRules); } catch { /* Cross-origin stylesheet rules are intentionally skipped. */ }
    }
    // Keep embedded page styles only when they contain rules matching selected elements.
    return minifyCss(chunks.join('\n'));
  }
  function refreshOutput() {
    const roots = getSelectedElements();
    const rawHtml = roots.map(cleanHtml).join('\n\n');
    const html = outputHtml(rawHtml);
    const css = minifyCss(extractRelevantCss(roots) + '\n' + solBadgeCssIfNeeded(roots) + '\n' + MATHJAX_HELPER_CSS);
    $('#st-output').value = html;
    $('#st-css-output').value = css;
    const previewDoc = `<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style>${mathJaxV2Head(true)}</head><body>${html}</body></html>`;
    $('#st-preview').srcdoc = previewDoc.replace('</body>', mathJaxRenderScript() + '</body>');
    if (!$('#st-filename').value.trim()) $('#st-filename').value = defaultFilename();
  }
  function outputHtml(html) {
    return $('#st-convert-align')?.checked ? convertAlignMath(html) : html;
  }
  function mathJaxV2Head(includeConfig = true) {
    if (!includeConfig) return '';
    return String.raw`<script type="text/x-mathjax-config">
MathJax.Hub.Config({
    jax: ["input/TeX", "output/HTML-CSS"],
    extensions: ["tex2jax.js"],
    TeX: { extensions: ["AMSmath.js", "AMSsymbols.js", "noErrors.js", "noUndefined.js", "cancel.js"] },
    tex2jax: { inlineMath: [["$", "$"], ["\\(", "\\)"]], displayMath: [["$$", "$$"], ["\\[", "\\]"]], processEscapes: true, skipTags: ["script", "noscript", "style", "textarea", "pre", "code"] },
    "HTML-CSS": { availableFonts: ["TeX"], preferredFont: "TeX", webFont: "TeX", mtextFontInherit: true, linebreaks: { automatic: false, width: "container" } },
    showMathMenu: false, messageStyle: "none", skipStartupTypeset: true
});
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.2/MathJax.js?config=TeX-AMS-MML_HTMLorMML"></script>`;
  }
  function mathJaxRenderScript() {
    return String.raw`<script>
(function () {
  function renderMathJax() {
    if (!window.MathJax || !MathJax.Hub) return;
    var target = document.querySelector(".solution-container") || document.body;
    MathJax.Hub.Queue(["Typeset", MathJax.Hub, target]);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", renderMathJax, { once: true });
  else renderMathJax();
  window.abvrpMc_rerenderMathJax = renderMathJax;
})();
</script>`;
  }
  const MATHJAX_HELPER_CSS = '.solution-container .MathJax_Display{overflow-x:auto!important;overflow-y:hidden!important;max-width:100%!important;padding-bottom:6px;box-sizing:border-box;line-height:normal}.solution-container{overflow-x:hidden}#MathJax_Message{display:none!important}span.MathJax{pointer-events:none}';
  const SUB_ANSWER_LAYOUT_FIX_CSS = '.solution-container .st-sub-ans{overflow:visible!important;overflow-x:visible!important;overflow-y:visible!important;border-left:3px solid rgb(203,213,225)!important;padding-left:20px!important;padding-right:0!important;max-width:100%!important;min-width:0!important;box-sizing:border-box!important;white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important}.solution-container .st-sub-ans .MathJax_Display{max-width:100%!important;overflow:visible!important;overflow-x:visible!important;overflow-y:visible!important;white-space:normal!important}.solution-container .st-sub-ans .MathJax{max-width:100%!important;white-space:nowrap!important}';
  const RESPONSIVE_TABLE_FIX_CSS = String.raw` .solution-container,.solution-container *{box-sizing:border-box}html,body{max-width:100%}.solution-container{width:100%;max-width:100%;min-width:0}.solution-container p,.solution-container h1,.solution-container h2,.solution-container h3,.solution-container h4,.solution-container h5,.solution-container h6,.solution-container li{overflow-wrap:anywhere}.solution-container .stat-table-wrapper{width:100%;max-width:100%;min-width:0}.solution-container .stat-table{width:100%;max-width:100%;border-collapse:collapse}@media(max-width:900px){.solution-container .stat-table-wrapper{overflow-x:hidden}.solution-container .stat-table.is-overflowing{table-layout:fixed;width:100%!important;font-size:var(--fit-font-size,12px)!important}.solution-container .stat-table.is-overflowing th,.solution-container .stat-table.is-overflowing td{padding:var(--fit-cell-padding,4px)!important;white-space:normal!important;overflow-wrap:anywhere;word-break:normal;min-width:0;line-height:1.4}}.solution-container .MathJax_Display{max-width:100%!important;overflow-x:auto!important;overflow-y:hidden!important;box-sizing:border-box}`;
  const RESPONSIVE_TABLE_FIX_SCRIPT = String.raw`<script>
(function(){'use strict';var root=document.querySelector('.solution-container');if(!root)return;var timer;function fit(){var small=window.matchMedia('(max-width:900px)').matches;root.querySelectorAll('.stat-table').forEach(function(table){table.classList.remove('is-overflowing');table.style.removeProperty('--fit-font-size');table.style.removeProperty('--fit-cell-padding');if(!small)return;var wrapper=table.closest('.stat-table-wrapper');if(!wrapper)return;var oldLayout=table.style.tableLayout,oldWidth=table.style.width;table.style.tableLayout='auto';table.style.width='max-content';var available=wrapper.clientWidth,natural=table.scrollWidth;table.style.tableLayout=oldLayout;table.style.width=oldWidth;if(!available||natural<=available+1)return;table.classList.add('is-overflowing');var cols=1;table.querySelectorAll('tr').forEach(function(row){var count=0;row.querySelectorAll('th,td').forEach(function(cell){count+=Math.max(1,cell.colSpan||1)});cols=Math.max(cols,count)});var font=cols>=10?8:cols>=7?9:cols>=5?10:11;table.style.setProperty('--fit-font-size',font+'px');table.style.setProperty('--fit-cell-padding',cols>=7?'2px':'3px');requestAnimationFrame(function(){var size=font;while(table.scrollWidth>wrapper.clientWidth+1&&size>7){size--;table.style.setProperty('--fit-font-size',size+'px')}})})}function schedule(){clearTimeout(timer);timer=setTimeout(fit,100)}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',fit,{once:true});else fit();window.addEventListener('resize',schedule);window.addEventListener('orientationchange',schedule);if('ResizeObserver'in window){var ro=new ResizeObserver(schedule);ro.observe(root)}if('MutationObserver'in window){var mo=new MutationObserver(schedule);mo.observe(root,{childList:true,subtree:true,characterData:true})}})();
</script>`;
  const SUB_ANSWER_FIT_SCRIPT = String.raw`<script>
(function(){'use strict';var root=document.querySelector('.solution-container');if(!root)return;var timer=0;function fit(){root.querySelectorAll('.st-sub-ans .MathJax').forEach(function(math){var box=math.closest('.st-sub-ans');if(!box)return;var original=parseFloat(math.getAttribute('data-st-fit-original'));if(!original){original=parseFloat(getComputedStyle(math).fontSize)||16;math.setAttribute('data-st-fit-original',String(original))}math.style.fontSize=original+'px';var style=getComputedStyle(box);var available=box.clientWidth-(parseFloat(style.paddingLeft)||0)-(parseFloat(style.paddingRight)||0);if(!available||available<1)return;var width=math.getBoundingClientRect().width;if(width>available+0.5){var scaled=Math.max(5,original*(available/width)*0.96);math.style.fontSize=scaled+'px'}})}function schedule(){if(timer)cancelAnimationFrame(timer);timer=requestAnimationFrame(fit)}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();window.addEventListener('resize',schedule);window.addEventListener('orientationchange',schedule);if('ResizeObserver'in window){var ro=new ResizeObserver(schedule);root.querySelectorAll('.st-sub-ans').forEach(function(el){ro.observe(el)})}if('MutationObserver'in window){var mo=new MutationObserver(schedule);mo.observe(root,{childList:true,subtree:true,characterData:true})}if(window.MathJax&&MathJax.Hub){try{MathJax.Hub.Queue(function(){schedule()})}catch(e){}}})();
</script>`;
  function outputForCopy() {
    const mode = panel.querySelector('input[name="st-copy-mode"]:checked')?.value;
    const html = outputHtml(getSelectedElements().map(cleanHtml).join('\n\n'));
    const css = minifyCss($('#st-css-output').value);
    const parts = [];
    if (mode === 'both') parts.push(`<style>${css}</style>`);
    if ($('#st-copy-mathjax').checked) parts.push(mathJaxV2Head(true));
    parts.push(html);
    if ($('#st-copy-mathjax').checked) parts.push(mathJaxRenderScript());
    return parts.filter(Boolean).join('\n');
  }
  // Convert align/align* environments to one display-math array, preserving equation order and Bengali comments.
  // Removes alignment markers such as &amp;= / &=, but keeps the mathematical equals sign and bracketed text.
  function convertAlignMath(text) {
    let output = String(text);
    const toArray = content => {
      const rows = content
        .split(/\\\\(?:\s*\[[^\]]*\])?\s*(?:\r?\n)?/)
        .map(line => line
          .replace(/&amp;(?=\s*(?:=|<|>|\\(?:leq?|geq?|neq|approx|sim|in|notin)))/g, '')
          .replace(/&(?=\s*(?:=|<|>|\\(?:leq?|geq?|neq|approx|sim|in|notin)))/g, '')
          .trim())
        .filter(Boolean);
      if (!rows.length) return content;
      return '\\[' + '\n' + '\\begin{array}{l}' + '\n' + rows.join(' ' + '\\\\' + '\n') + '\n' + '\\end{array}' + '\n' + '\\]';
    };
    output = output.replace(/\$\$\s*\\begin\{align\*?\}([\s\S]*?)\\end\{align\*?\}\s*\$\$/g,
      (_match, content) => toArray(content));
    output = output.replace(/\\\[\s*\\begin\{align\*?\}([\s\S]*?)\\end\{align\*?\}\s*\\\]/g,
      (_match, content) => toArray(content));
    output = output.replace(/\\begin\{align\*?\}([\s\S]*?)\\end\{align\*?\}/g,
      (_match, content) => toArray(content));
    return output.replace(/(?:\r?\n[ \t]*){3,}/g, '\n\n');
  }
  function selectedHtml() { return convertAlignMath(getSelectedElements().map(cleanHtml).join('\\n\\n')); }
  function defaultFilename() {
    const parts=location.pathname.split('/').filter(Boolean);
    const slug=parts[parts.length-1] || 'sciencetips-page';
    return slug.replace(/[^a-z0-9._-]+/gi,'-').replace(/\.html?$/i,'') || 'sciencetips-page';
  }
  function cleanFilenamePart(value, fallback = '') {
    return String(value || '').trim().replace(/\.html?$/i,'').replace(/[\\/:*?"<>|]+/g,'-').replace(/[\s]+/g,'-').slice(0,120) || fallback;
  }
  function urlPrefixFromPattern() {
    const pattern = String($('#st-url-pattern')?.value || '');
    const marked = [...pattern.matchAll(/\*([^*]+)\*/g)].map(match => match[1].trim()).filter(Boolean);
    if (!marked.length) return '';
    const separator = String($('#st-url-separator')?.value ?? '_');
    return marked.join(separator) + separator;
  }
  function parsePresetItems(text) {
    return String(text || '').split(/\r?\n/).map(line => line.trim()).filter(Boolean).map(line => {
      const comma = line.indexOf(',');
      let title = '';
      let rawUrl = line;
      if (comma >= 0) {
        title = line.slice(0, comma).trim();
        rawUrl = line.slice(comma + 1).trim();
      }
      try {
        const url = new URL(rawUrl, location.href);
        return { title, url: url.href };
      } catch { return null; }
    }).filter(item => item && item.url);
  }
  function currentPresetItem() {
    const current = normalizedUrl(location.href);
    return parsePresetItems($('#st-url-list')?.value || '').find(item => normalizedUrl(item.url) === current) || null;
  }
  function currentFilename() {
    const item = currentPresetItem();
    const rawName = item && item.title ? item.title : ($('#st-filename')?.value || defaultFilename());
    const name = cleanFilenamePart(rawName, defaultFilename());
    const manualPrefix = cleanFilenamePart($('#st-prefix')?.value, '');
    const urlPrefix = urlPrefixFromPattern();
    return (manualPrefix + urlPrefix + name).slice(0,180) || 'sciencetips-page';
  }
  function getNumericMarkedPart() {
    const pattern = String($('#st-url-pattern')?.value || '');
    const matches = [...pattern.matchAll(/\*([^*]+)\*/g)];
    // Navigation is enabled only when exactly one starred segment is numeric.
    const numeric = matches.filter(match => /^\d+$/.test(match[1]));
    if (numeric.length !== 1) return null;
    return { match: numeric[0], number: Number(numeric[0][1]), digits: numeric[0][1] };
  }
  function updateNumericNavigation() {
    const info = getNumericMarkedPart();
    const numberLabel = $('#st-url-current-number');
    const previous = $('#st-url-previous');
    const next = $('#st-url-next');
    if (numberLabel) numberLabel.textContent = info ? 'Current number: ' + info.digits : 'Number: — (star a numeric value)';
    // Keep navigation controls visibly active at all times. If the marked
    // section is not numeric (or is at a numeric boundary), the click handler
    // explains why navigation cannot proceed.
    if (previous) previous.disabled = false;
    if (next) next.disabled = false;
    const headPrevious = $('#st-head-previous');
    const headNext = $('#st-head-next');
    if (headPrevious) headPrevious.disabled = false;
    if (headNext) headNext.disabled = false;
  }
  function normalizedUrl(value) {
    try {
      const url = new URL(String(value).trim());
      url.hash = '';
      if (url.pathname.length > 1) url.pathname = url.pathname.replace(/\/$/, '');
      return url.href;
    } catch { return ''; }
  }
  async function navigateNumericUrl(delta) {
    const presetItems = parsePresetItems($('#st-url-list')?.value || '');
    if (presetItems.length) {
      const current = normalizedUrl(location.href);
      let index = presetItems.findIndex(item => normalizedUrl(item.url) === current);
      // If this page is not in the list, start at the first/last entry according to direction.
      const targetIndex = index < 0
        ? (delta > 0 ? 0 : presetItems.length - 1)
        : (index + delta + presetItems.length) % presetItems.length;
      const targetUrl = presetItems[targetIndex].url;
      const updatedPattern = syncPatternWithCurrentUrl(String($('#st-url-pattern')?.value || ''), targetUrl);
      $('#st-url-pattern').value = updatedPattern;
      const settings = {
        prefix: $('#st-prefix').value, filename: $('#st-filename').value,
        headExtra: $('#st-head-extra').value, bodyExtra: $('#st-body-extra').value, additionalCss: $('#st-additional-css').value,
        urlPattern: updatedPattern, urlSeparator: $('#st-url-separator').value,
        urlList: $('#st-url-list').value
      };
      await chrome.storage.local.set({ [exportSettingsKey]: settings });
      status('Opening ' + (presetItems[targetIndex].title || 'preset URL') + ' (' + (targetIndex + 1) + ' of ' + presetItems.length + ')');
      location.assign(targetUrl);
      return;
    }
    const pattern = String($('#st-url-pattern')?.value || '');
    const info = getNumericMarkedPart();
    if (!info) { status('Add preset URLs above, or wrap one numeric value in *...*'); return; }
    const targetNumber = info.number + delta;
    if (!Number.isSafeInteger(targetNumber) || targetNumber < 0) { status('Cannot navigate beyond this numeric value'); return; }
    const replacement = String(targetNumber).padStart(info.digits.length, '0');
    const updatedPattern = pattern.slice(0, info.match.index) + '*' + replacement + '*' + pattern.slice(info.match.index + info.match[0].length);
    let targetUrl;
    try { targetUrl = updatedPattern.replace(/\*([^*]+)\*/g, '$1'); new URL(targetUrl); }
    catch { status('The generated URL is invalid'); return; }
    $('#st-url-pattern').value = updatedPattern;
    updateFilenamePreview();
    // Save synchronously before navigation so the new marked position survives the page load.
    const settings = {
      prefix: $('#st-prefix').value, filename: $('#st-filename').value,
      headExtra: $('#st-head-extra').value, bodyExtra: $('#st-body-extra').value, additionalCss: $('#st-additional-css').value,
      urlPattern: updatedPattern, urlSeparator: $('#st-url-separator').value,
      urlList: $('#st-url-list').value
    };
    await chrome.storage.local.set({ [exportSettingsKey]: settings });
    status('Opening ' + targetUrl);
    location.assign(targetUrl);
  }
  function updateFilenamePreview() {
    const generated = urlPrefixFromPattern();
    const prefixPreview = $('#st-url-prefix-preview');
    const filePreview = $('#st-filename-preview');
    if (prefixPreview) prefixPreview.textContent = 'Generated URL prefix: ' + (generated || '— (wrap a part in *)');
    if (filePreview) filePreview.textContent = 'Output file: ' + currentFilename() + '.html';
    const headerFilename = $('#st-head-filename');
    const missingSelectedClasses = Object.entries(classChoices || {})
      .filter(([className, selected]) => selected === true && !classNames.includes(className))
      .map(([className]) => className);
    // Missing saved selections must be detected even when none of the saved selected classes exists on this page (state.classes can then be empty).
    const selectionUnavailable = missingSelectedClasses.length > 0;
    panel.classList.toggle('st-output-unavailable', selectionUnavailable);
    if (headerFilename) {
      headerFilename.textContent = currentFilename() + '.html';
      headerFilename.title = selectionUnavailable
        ? 'Selected class(es) not found on this page: ' + missingSelectedClasses.join(', ')
        : 'Current output file: ' + currentFilename() + '.html';
      headerFilename.setAttribute('aria-label', selectionUnavailable
        ? 'Output unavailable. Missing selected classes: ' + missingSelectedClasses.join(', ')
        : 'Current output file: ' + currentFilename() + '.html');
    }
    const downloadHeader = $('#st-head-download');
    const downloadMain = $('#st-download');
    [downloadHeader, downloadMain].forEach(button => {
      if (!button) return;
      button.hidden = false;
      // Downloads must remain available even if a previously selected class is absent.
      // The filename indicator can still warn about missing classes, but must not block export.
      button.disabled = false;
      button.title = button.id === 'st-head-download' ? 'Download current HTML' : 'Download HTML file';
    });
    updateNumericNavigation();
  }
  let exportSaveTimer;
  function saveExportSettings() {
    clearTimeout(exportSaveTimer);
    exportSaveTimer = setTimeout(() => {
      chrome.storage.local.set({ [exportSettingsKey]: {
        prefix: $('#st-prefix').value, filename: $('#st-filename').value,
        headExtra: $('#st-head-extra').value, bodyExtra: $('#st-body-extra').value, additionalCss: $('#st-additional-css').value,
        urlPattern: $('#st-url-pattern').value, urlSeparator: $('#st-url-separator').value,
        urlList: $('#st-url-list').value
      }});
    }, 150);
  }
  function standaloneHtml() {
    const html = outputHtml(getSelectedElements().map(cleanHtml).join('\n\n'));
    const css = $('#st-download-css').checked ? minifyCss($('#st-css-output').value + '\n' + SOL_BADGE_CSS + '\n' + MATHJAX_HELPER_CSS + '\n' + RESPONSIVE_TABLE_FIX_CSS) : '';
    const additionalCss = $('#st-additional-css').value.trim();
    const layoutFixTag = `<style id="st-sub-answer-layout-fix">${SUB_ANSWER_LAYOUT_FIX_CSS}</style>`;
    const styleTag = [css ? `<style>${css}</style>` : '', additionalCss ? `<style id="st-additional-css">${additionalCss}</style>` : '', layoutFixTag].filter(Boolean).join('\n');
    const math = $('#st-download-mathjax').checked ? mathJaxV2Head(true) : '';
    const bodyHtml = /class=[\"'][^\"']*\bsolution-container\b/.test(html) ? html : `<div class=\"solution-container\">${html}</div>`;
    const render = $('#st-download-mathjax').checked ? mathJaxRenderScript() : '';
    const headExtra = $('#st-head-extra').value.trim();
    const bodyExtra = $('#st-body-extra').value.trim();
    return `<!doctype html>\n<html lang="bn">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n<title>${escapeHtmlText(currentFilename())}</title>\n<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n<link href="https://fonts.googleapis.com/css2?family=Noto+Serif+Bengali:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">\n${styleTag}\n${math}\n${headExtra}\n</head>\n<body>\n${bodyHtml}\n${render}\n${RESPONSIVE_TABLE_FIX_SCRIPT}\n${SUB_ANSWER_FIT_SCRIPT}\n${bodyExtra}\n</body>\n</html>`;
  }
  function escapeHtmlText(value) { return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
  $('#st-filename').value = typeof exportSettings.filename === 'string' && exportSettings.filename ? exportSettings.filename : defaultFilename();
  $('#st-prefix').value = typeof exportSettings.prefix === 'string' ? exportSettings.prefix : '';
  $('#st-head-extra').value = typeof exportSettings.headExtra === 'string' ? exportSettings.headExtra : '';
  $('#st-body-extra').placeholder = DEFAULT_BODY_EXTRA;
  $('#st-body-extra').value = typeof exportSettings.bodyExtra === 'string' ? exportSettings.bodyExtra : DEFAULT_BODY_EXTRA;
  $('#st-body-extra-default').addEventListener('click', () => { $('#st-body-extra').value = DEFAULT_BODY_EXTRA; saveExportSettings(); status('Default koshe-dekhi-tools.js script restored'); });
  $('#st-additional-css').value = typeof exportSettings.additionalCss === 'string' ? exportSettings.additionalCss : DEFAULT_ADDITIONAL_CSS;
  $('#st-url-pattern').value = exportSettings.urlPattern;
  $('#st-url-separator').value = exportSettings.urlSeparator;
  $('#st-url-list').value = exportSettings.urlList || '';
  const urlListModal = $('#st-url-list-modal');
  const urlListModalText = $('#st-url-list-modal-text');
  function openUrlListModal() {
    urlListModalText.value = $('#st-url-list').value || '';
    urlListModal.classList.remove('st-hidden');
    urlListModalText.focus();
  }
  function closeUrlListModal() { urlListModal.classList.add('st-hidden'); }
  $('#st-open-url-list').addEventListener('click', openUrlListModal);
  $('#st-url-list-modal-close').addEventListener('click', closeUrlListModal);
  $('#st-url-list-modal-cancel').addEventListener('click', closeUrlListModal);
  $('#st-url-list-modal').addEventListener('click', event => {
    if (event.target === urlListModal) closeUrlListModal();
  });
  urlListModalText.addEventListener('keydown', event => {
    if (event.key === 'Escape') closeUrlListModal();
  });
  $('#st-url-list-modal-save').addEventListener('click', () => {
    const urls = urlListModalText.value.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
    $('#st-url-list').value = urls.join('\n');
    $('#st-url-list').dispatchEvent(new Event('input', { bubbles: true }));
    $('#st-url-list').dispatchEvent(new Event('change', { bubbles: true }));
    closeUrlListModal();
    updateFilenamePreview();
    status('Saved ' + urls.length + ' preset item(s). Titles will be used as download filenames; list persists after refresh.');
  });
  if (syncedPattern !== savedPreferences['stExportSettings:v1']?.urlPattern) {
    chrome.storage.local.set({ [exportSettingsKey]: { ...exportSettings, urlPattern: syncedPattern } });
  }
  ['st-filename','st-prefix','st-head-extra','st-body-extra','st-additional-css','st-url-pattern','st-url-separator','st-url-list'].forEach(id => {
    $('#'+id).addEventListener('input', saveExportSettings);
    $('#'+id).addEventListener('change', () => { saveExportSettings(); status('Export settings saved and will be restored after refresh'); });
    $('#'+id).addEventListener('blur', saveExportSettings);
  });
  ['st-url-pattern','st-url-separator','st-filename','st-prefix','st-url-list'].forEach(id => $('#'+id).addEventListener('input', updateFilenamePreview));
  $('#st-url-current').addEventListener('click', () => { const existingPattern = $('#st-url-pattern').value; $('#st-url-pattern').value = existingPattern.includes('*') ? syncPatternWithCurrentUrl(existingPattern, location.href) : location.href; saveExportSettings(); updateFilenamePreview(); status($('#st-url-pattern').value.includes('*') ? 'Current URL loaded; saved dynamic position(s) preserved' : 'Current page URL loaded into the pattern box'); });
  $('#st-url-apply').addEventListener('click', () => { saveExportSettings(); updateFilenamePreview(); status('URL prefix applied: ' + (urlPrefixFromPattern() || 'no starred section found')); });
  $('#st-url-previous').addEventListener('click', () => navigateNumericUrl(-1));
  $('#st-url-next').addEventListener('click', () => navigateNumericUrl(1));
  $('#st-head-previous').addEventListener('click', () => navigateNumericUrl(-1));
  $('#st-head-next').addEventListener('click', () => navigateNumericUrl(1));
  ['st-convert-align','st-copy-mathjax','st-download-css','st-download-mathjax'].forEach(id => $('#'+id).addEventListener('change', refreshOutput));
  updateFilenamePreview();
  renderClassTree();
  $('#st-search').addEventListener('input',e=>{state.search=e.target.value;renderClassTree();});
  $('#st-all').addEventListener('click',()=>{classNames.forEach(c=>state.classes.add(c));renderClassTree();applyVisibility();updateCount();saveClassPreferences();refreshOutput();status('All classes selected and saved');});
  $('#st-none').addEventListener('click',()=>{state.classes.clear();renderClassTree();applyVisibility();updateCount();saveClassPreferences();refreshOutput();status('Class selection cleared and saved');});
  $('#st-reset').addEventListener('click',()=>{state.classes=new Set(classNames);renderClassTree();applyVisibility();updateCount();saveClassPreferences();refreshOutput();status('All classes restored and saved');});
  $('#st-copy').addEventListener('click',async()=>{refreshOutput();const output=outputForCopy();try{await navigator.clipboard.writeText(output);const mode=panel.querySelector('input[name="st-copy-mode"]:checked')?.value;status(`Copied ${mode==='both'?'CSS + HTML':'HTML'}${$('#st-copy-mathjax').checked?' + MathJax':''} · ${getSelectedElements().length} top-level element(s)`);}catch{$('#st-output').focus();$('#st-output').select();status('Clipboard permission unavailable; select source and copy manually');}});
  function downloadHtmlFile(){
    updateFilenamePreview();
    if (panel.classList.contains('st-output-unavailable')) {
      status('Download stopped: one or more previously selected classes were not found on this page.');
      return;
    }
    refreshOutput();const blob=new Blob([standaloneHtml()],{type:'text/html;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=currentFilename()+'.html';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);status('Downloaded '+currentFilename()+'.html · CSS '+($('#st-download-css').checked?'included':'omitted')+' · MathJax '+($('#st-download-mathjax').checked?'included':'omitted'));}
  $('#st-download').addEventListener('click',downloadHtmlFile);
  $('#st-head-download').addEventListener('click',downloadHtmlFile);
  $('#st-show-preview').addEventListener('click',()=>{$('#st-preview').classList.remove('st-hidden');$('#st-output').classList.add('st-hidden');$('#st-show-preview').classList.add('active');$('#st-show-source').classList.remove('active');refreshOutput();});
  $('#st-show-source').addEventListener('click',()=>{$('#st-output').classList.remove('st-hidden');$('#st-css-output').classList.add('st-hidden');$('#st-preview').classList.add('st-hidden');$('#st-show-source').classList.add('active');$('#st-show-preview').classList.remove('active');$('#st-show-css').classList.remove('active');});
  $('#st-show-css').addEventListener('click',()=>{$('#st-css-output').classList.remove('st-hidden');$('#st-output').classList.add('st-hidden');$('#st-preview').classList.add('st-hidden');$('#st-show-css').classList.add('active');$('#st-show-source').classList.remove('active');$('#st-show-preview').classList.remove('active');refreshOutput();});
  $('#st-reload').addEventListener('click',()=>location.reload());
  panel.querySelectorAll('[data-tab]').forEach(btn=>btn.addEventListener('click',()=>{panel.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b===btn));$('#st-scripts').classList.toggle('st-hidden',btn.dataset.tab!=='scripts');$('#st-classes').classList.toggle('st-hidden',btn.dataset.tab!=='classes');if(btn.dataset.tab==='classes')refreshOutput();}));
  const minPreviewCheckbox = $('#st-min-preview');
  minPreviewCheckbox.checked = savedPreferences.stMinimizedPreview !== false;
  panel.classList.toggle('st-min-preview-enabled', minPreviewCheckbox.checked);
  minPreviewCheckbox.addEventListener('change', () => {
    panel.classList.toggle('st-min-preview-enabled', minPreviewCheckbox.checked);
    chrome.storage.local.set({ stMinimizedPreview: minPreviewCheckbox.checked });
    status(minPreviewCheckbox.checked ? 'Preview will remain visible while minimized' : 'Preview will be hidden while minimized');
  });
  $('#st-min').addEventListener('click',()=>{
    state.minimized=!state.minimized;
    panel.classList.toggle('st-minimized', state.minimized);
    $('#st-min').textContent=state.minimized?'+':'−';
    $('#st-min').title=state.minimized?'Restore full inspector':'Minimize inspector';
    $('#st-min').setAttribute('aria-label', state.minimized?'Restore full inspector':'Minimize inspector');
  });
  $('#st-close').addEventListener('click',()=>panel.remove());
  applyVisibility(); refreshOutput();
  status(`Loaded · ${scriptUrls.length} external script URL(s) · ${classNames.length} class name(s) · saved choices restored`);
})();
